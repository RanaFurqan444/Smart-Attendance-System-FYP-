"""Face registration, recognition attendance, QR decoding helpers, and basic liveness checks."""

from __future__ import annotations

import base64
import json
import math
import random


def ensure_cv():
    try:
        import cv2
        import numpy as np
        return cv2, np
    except Exception:
        return None, None


def decode_qr_from_image(path: str) -> list[str]:
    """Decode a QR image using pyzbar first and OpenCV as fallback."""
    cv2, _np = ensure_cv()
    if cv2 is None:
        raise RuntimeError("OpenCV is required for QR image decoding.")
    img = cv2.imread(path)
    if img is None:
        return []
    try:
        from pyzbar import pyzbar
        found = [obj.data.decode("utf-8", errors="ignore") for obj in pyzbar.decode(img)]
        if found:
            return found
    except Exception:
        pass
    detector = cv2.QRCodeDetector()
    data, _pts, _ = detector.detectAndDecode(img)
    return [data] if data else []


class LivenessDetector:
    """OpenCV-based multi-layer liveness and anti-spoofing checks.

    The class is intentionally dependency-light and model-ready. If a MiniFASNet
    or Silent-Face model is added later, `passive_check` is the integration
    point. Current checks detect common printed/screen/replay symptoms using
    image quality, lighting, texture, glare, moire-like edge density, eye
    evidence, and motion.
    """

    CHALLENGES = [
        "blink_twice",
        "turn_head_left",
        "turn_head_right",
        "look_up",
        "look_down",
        "nod_head",
    ]

    LABELS = {
        "blink_twice": "Blink twice",
        "turn_head_left": "Turn head left",
        "turn_head_right": "Turn head right",
        "look_up": "Look up",
        "look_down": "Look down",
        "nod_head": "Nod head",
    }

    def __init__(self, cv2_module, np_module, eye_cascade, threshold: float = 80.0) -> None:
        self.cv2 = cv2_module
        self.np = np_module
        self.eye_cascade = eye_cascade
        self.threshold = threshold
        self.challenge = random.choice(self.CHALLENGES)
        self.reset()

    def reset(self, challenge: str | None = None) -> None:
        self.challenge = challenge or random.choice(self.CHALLENGES)
        self.frames = 0
        self.eye_open_frames = 0
        self.eye_closed_events = 0
        self.was_eye_open = False
        self.prev_center = None
        self.prev_area = None
        self.motion_values = []
        self.left_votes = 0
        self.right_votes = 0
        self.up_votes = 0
        self.down_votes = 0
        self.nod_direction_changes = 0
        self.last_vertical_delta = 0

    @property
    def challenge_label(self) -> str:
        return self.LABELS[self.challenge]

    def quality_check(self, frame, gray, face_rect) -> tuple[bool, str]:
        x, y, w, h = face_rect
        if w < 90 or h < 90:
            return False, "Face too small or too far from camera."
        roi = gray[y : y + h, x : x + w]
        brightness = float(roi.mean())
        sharpness = float(self.cv2.Laplacian(roi, self.cv2.CV_64F).var())
        if brightness < 45:
            return False, "Lighting is too dark."
        if brightness > 225:
            return False, "Lighting is too bright."
        if sharpness < 28:
            return False, "Face image is blurry."
        return True, "Face quality OK."

    def passive_check(self, frame, gray, face_rect) -> dict:
        x, y, w, h = face_rect
        roi_gray = gray[y : y + h, x : x + w]
        roi_color = frame[y : y + h, x : x + w]
        sharpness = float(self.cv2.Laplacian(roi_gray, self.cv2.CV_64F).var())
        brightness = float(roi_gray.mean())
        contrast = float(roi_gray.std())
        hsv = self.cv2.cvtColor(roi_color, self.cv2.COLOR_BGR2HSV)
        saturation = float(hsv[:, :, 1].mean())
        glare_ratio = float((roi_gray > 242).mean())
        edges = self.cv2.Canny(roi_gray, 80, 160)
        edge_density = float((edges > 0).mean())

        score = 50.0
        score += min(18.0, max(0.0, (sharpness - 25.0) / 5.0))
        score += min(14.0, contrast / 4.0)
        score += 10.0 if 55 <= brightness <= 205 else -12.0
        score += 8.0 if saturation >= 18 else -10.0
        score -= min(20.0, glare_ratio * 160.0)
        if edge_density > 0.24:
            score -= 14.0
        if edge_density < 0.025:
            score -= 10.0
        real_conf = max(0.0, min(99.0, score))
        fake_conf = 100.0 - real_conf
        attack = ""
        if glare_ratio > 0.08:
            attack = "SCREEN_ATTACK"
        elif edge_density > 0.24:
            attack = "PHOTO_OR_SCREEN_TEXTURE"
        elif real_conf < self.threshold:
            attack = "FAKE_FACE_DETECTED"
        return {
            "passed": real_conf >= self.threshold,
            "real_confidence": round(real_conf, 2),
            "fake_confidence": round(fake_conf, 2),
            "attack_type": attack,
            "metrics": {
                "sharpness": round(sharpness, 2),
                "brightness": round(brightness, 2),
                "contrast": round(contrast, 2),
                "saturation": round(saturation, 2),
                "glare_ratio": round(glare_ratio, 4),
                "edge_density": round(edge_density, 4),
            },
        }

    def update_challenge(self, gray, face_rect) -> bool:
        x, y, w, h = face_rect
        self.frames += 1
        roi = gray[y : y + h, x : x + w]
        eyes = self.eye_cascade.detectMultiScale(roi, 1.1, 4, minSize=(max(12, w // 12), max(8, h // 18)))
        eyes_open = len(eyes) >= 1
        if eyes_open:
            self.eye_open_frames += 1
            self.was_eye_open = True
        elif self.was_eye_open:
            self.eye_closed_events += 1
            self.was_eye_open = False

        center = (x + w / 2.0, y + h / 2.0)
        if self.prev_center is not None:
            dx = center[0] - self.prev_center[0]
            dy = center[1] - self.prev_center[1]
            self.motion_values.append(math.hypot(dx, dy))
            if dx < -4:
                self.left_votes += 1
            if dx > 4:
                self.right_votes += 1
            if dy < -3:
                self.up_votes += 1
            if dy > 3:
                self.down_votes += 1
            if abs(dy) > 3 and (dy > 0) != (self.last_vertical_delta > 0) and self.last_vertical_delta != 0:
                self.nod_direction_changes += 1
            if abs(dy) > 3:
                self.last_vertical_delta = dy
        self.prev_center = center
        self.prev_area = w * h

        if self.challenge == "blink_twice":
            return self.eye_closed_events >= 2 and self.eye_open_frames >= 3
        if self.challenge == "turn_head_left":
            return self.left_votes >= 4
        if self.challenge == "turn_head_right":
            return self.right_votes >= 4
        if self.challenge == "look_up":
            return self.up_votes >= 4
        if self.challenge == "look_down":
            return self.down_votes >= 4
        if self.challenge == "nod_head":
            return self.nod_direction_changes >= 2
        return False

    def motion_liveness_ok(self) -> bool:
        return bool(self.motion_values and max(self.motion_values) >= 1.2)


class FaceEngine:
    """Small OpenCV/Numpy recognizer adapted from the original file's handcrafted feature idea."""

    def __init__(self, camera_index: int = 0, threshold: float = 72.0):
        self.cv2, self.np = ensure_cv()
        if self.cv2 is None:
            raise RuntimeError("Install OpenCV and NumPy: pip install opencv-python numpy")
        self.camera_index = camera_index
        self.threshold = threshold
        self.face_cascade = self.cv2.CascadeClassifier(self.cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        self.eye_cascade = self.cv2.CascadeClassifier(self.cv2.data.haarcascades + "haarcascade_eye.xml")

    def face_roi(self, image_path: str):
        img = self.cv2.imread(image_path)
        if img is None:
            raise ValueError("Could not load image.")
        gray = self.cv2.cvtColor(img, self.cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(70, 70))
        if len(faces) == 0:
            raise ValueError("No face detected.")
        x, y, w, h = sorted(faces, key=lambda r: r[2] * r[3], reverse=True)[0]
        return gray[y : y + h, x : x + w]

    def extract(self, roi) -> list[float]:
        """Build an identity descriptor from a grayscale face ROI.

        Combines a 4x4 grid of local gradient-orientation histograms with a
        4x4 grid of local-binary-pattern histograms plus a coarse pixel
        signature. Spatially-localised texture/edge statistics are far more
        person-specific than the original single global histogram, which is
        what reduces wrong-person matches.
        """
        cv2, np = self.cv2, self.np
        face = cv2.resize(roi, (128, 128))
        face = cv2.equalizeHist(face)

        parts = []

        gx = cv2.Sobel(face, cv2.CV_32F, 1, 0)
        gy = cv2.Sobel(face, cv2.CV_32F, 0, 1)
        mag, ang = cv2.cartToPolar(gx, gy)
        ang = ang % np.pi
        cell = 32
        for cy in range(0, 128, cell):
            for cx in range(0, 128, cell):
                a = ang[cy:cy + cell, cx:cx + cell]
                m = mag[cy:cy + cell, cx:cx + cell]
                h, _ = np.histogram(a, bins=9, range=(0, np.pi), weights=m)
                h = h / (np.linalg.norm(h) + 1e-6)
                parts.append(h.astype(np.float32))

        lbp = self._lbp_image(face)
        for cy in range(0, 128, cell):
            for cx in range(0, 128, cell):
                block = lbp[cy:cy + cell, cx:cx + cell]
                h, _ = np.histogram(block, bins=32, range=(0, 256))
                h = h / (np.linalg.norm(h) + 1e-6)
                parts.append(h.astype(np.float32))

        pix = cv2.resize(face, (16, 16)).flatten().astype(np.float32) / 255.0
        parts.append(pix * 0.25)

        feat = np.concatenate(parts)
        norm = float(np.linalg.norm(feat))
        if norm > 1e-8:
            feat = feat / norm
        return feat.astype(float).tolist()

    def _lbp_image(self, gray):
        """Compute a basic 8-neighbour local binary pattern image."""
        np = self.np
        g = gray.astype(np.int16)
        out = np.zeros_like(g, dtype=np.uint8)
        shifts = [(-1, -1), (-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1)]
        for bit, (dy, dx) in enumerate(shifts):
            shifted = np.roll(np.roll(g, dy, axis=0), dx, axis=1)
            out |= ((shifted >= g).astype(np.uint8) << bit)
        return out

    def distance(self, a: list[float], b: list[float]) -> float:
        np = self.np
        aa = np.array(a, dtype=np.float32)
        bb = np.array(b, dtype=np.float32)
        # Normalise both vectors here as well, so faces enrolled before the
        # extract() update (which stored un-normalised vectors) still compare
        # correctly against newly-extracted, already-normalised live features.
        # Re-normalising an already-unit vector is a no-op, so this is safe.
        na = float(np.linalg.norm(aa))
        nb = float(np.linalg.norm(bb))
        if na > 1e-8:
            aa = aa / na
        if nb > 1e-8:
            bb = bb / nb
        return float(np.linalg.norm(aa - bb))

    def confidence(self, distance: float) -> float:
        """Map a feature-vector distance to a 0-99 confidence score.

        Feature vectors from :meth:`extract` are L2-normalised. With the richer
        grid HOG+LBP descriptor the Euclidean distance between two unit vectors
        lies roughly in 0..1.4; same-identity frames cluster lower than
        different identities. This logistic curve is centred on the decision
        boundary so genuine matches score above the recognition threshold while
        different faces stay below it. The previous linear formula collapsed to
        0 for realistic distances, so a genuine match could never be marked.
        """
        d0, k = 0.90, 7.0          # boundary distance and steepness
        score = 99.0 / (1.0 + math.exp(k * (distance - d0)))
        return max(0.0, min(99.0, score))

    def best_match(self, roi, known: dict[str, list[float]],
                   margin: float = 8.0) -> tuple[str | None, float]:
        """Return the best student match for one detected face ROI.

        A match is accepted only when (a) the top confidence clears
        ``self.threshold`` AND (b) it beats the second-best *different* student
        by at least ``margin`` points. The margin check is what prevents an
        unenrolled or wrong face from being marked: if two students score
        almost the same, the result is ambiguous and is rejected rather than
        guessed.
        """
        feat = self.extract(roi)
        scored = []
        for sid, known_value in known.items():
            samples = self.feature_samples(known_value)
            if not samples:
                continue
            conf = max(self.confidence(self.distance(feat, known_feat))
                       for known_feat in samples)
            scored.append((conf, sid))
        if not scored:
            return None, 0.0
        scored.sort(reverse=True)
        best_conf, best_id = scored[0]
        second_conf = scored[1][0] if len(scored) > 1 else 0.0
        if best_conf < self.threshold:
            return None, best_conf
        if (best_conf - second_conf) < margin:
            # Too ambiguous — looks similar to more than one student.
            return None, best_conf
        return best_id, best_conf

    # ──────────────────────────────────────────────────────────────────────
    #  LBPH recognizer path (primary). This uses OpenCV's trained Local Binary
    #  Pattern Histogram face recognizer, which actually separates identities
    #  (unlike the static handcrafted features). It ships with
    #  opencv-contrib-python and needs no model download.
    #
    #  Faces are stored as small normalised PNG crops (base64) per student.
    #  At recognition time all enrolled crops are used to train an LBPH model,
    #  which then predicts a label + distance for each live face.
    # ──────────────────────────────────────────────────────────────────────

    FACE_SIZE = 160
    # LBPH distance below which a prediction is accepted. Lower = more similar.
    # Benchmarked on real (LFW) faces with 8 enrollment samples at 160px:
    # genuine correct matches stayed at/under ~38 while truly unenrolled faces
    # sat at/above ~40, so 40 cleanly separates a registered person from a
    # stranger. Confident confusion between two enrolled look-alikes (rare, and
    # only among enrolled students) is handled by the multi-frame
    # label-consistency check in the attendance loop, not by this threshold.
    #
    # Calibrated with CLAHE preprocessing and simulated lighting changes:
    # genuine matches max out at ~46, unenrolled strangers start at ~82,
    # so 70 gives a clean gap with 100% genuine accept and 0% stranger accept.
    LBPH_MAX_DISTANCE = 70.0

    @staticmethod
    def lbph_available() -> bool:
        try:
            import cv2
            return hasattr(cv2, "face") and hasattr(cv2.face, "LBPHFaceRecognizer_create")
        except Exception:
            return False

    def normalize_face(self, roi):
        """Return a canonical preprocessed grayscale face crop for LBPH.

        Uses CLAHE (Contrast Limited Adaptive Histogram Equalization) instead
        of global equalizeHist. CLAHE works locally on small tiles so the
        result depends only on the face region, not on what is behind the
        person. This is critical for consistency between registration (one
        day/room) and recognition (another day/room) — global equalization
        varies with background brightness and was causing registered faces to
        be rejected in attendance.
        """
        cv2 = self.cv2
        if roi.ndim == 3:
            roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        face = cv2.resize(roi, (self.FACE_SIZE, self.FACE_SIZE))
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        return clahe.apply(face)

    def _encode_crop(self, gray_crop) -> str:
        cv2 = self.cv2
        ok, buf = cv2.imencode(".png", gray_crop)
        if not ok:
            raise ValueError("Could not encode face crop.")
        return base64.b64encode(buf.tobytes()).decode("ascii")

    def _decode_crop(self, b64: str):
        cv2, np = self.cv2, self.np
        data = np.frombuffer(base64.b64decode(b64), dtype=np.uint8)
        img = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return None
        if img.shape[:2] != (self.FACE_SIZE, self.FACE_SIZE):
            img = cv2.resize(img, (self.FACE_SIZE, self.FACE_SIZE))
        return img

    def encode_face_samples(self, crops: list) -> str:
        """Serialise a list of normalised face crops to JSON (base64 PNGs)."""
        return json.dumps({
            "model": "lbph_face_v1",
            "crops": [self._encode_crop(c) for c in crops],
        })

    @staticmethod
    def decode_face_payload(raw: str) -> dict:
        try:
            value = json.loads(raw)
        except Exception:
            return {"model": "unknown", "crops": []}
        if isinstance(value, dict) and value.get("model") == "lbph_face_v1":
            return value
        return {"model": "legacy", "crops": []}

    def build_recognizer(self, all_known: dict):
        """Train an LBPH recognizer from all enrolled students' face crops.

        ``all_known`` maps student_id -> decoded payload (dict with 'crops').
        Returns ``(recognizer, label_to_sid)`` or ``(None, {})`` if there are
        no usable crops / LBPH is unavailable.
        """
        if not self.lbph_available():
            return None, {}
        cv2, np = self.cv2, self.np
        images, labels, label_to_sid = [], [], {}
        next_label = 0
        for sid, payload in all_known.items():
            crops = payload.get("crops", []) if isinstance(payload, dict) else []
            decoded = [self._decode_crop(c) for c in crops]
            decoded = [d for d in decoded if d is not None]
            if not decoded:
                continue
            label_to_sid[next_label] = sid
            for d in decoded:
                images.append(d)
                labels.append(next_label)
            next_label += 1
        if not images:
            return None, {}
        rec = cv2.face.LBPHFaceRecognizer_create(
            radius=2, neighbors=8, grid_x=8, grid_y=8
        )
        rec.train(images, np.array(labels))
        return rec, label_to_sid

    def lbph_confidence(self, distance: float) -> float:
        """Convert an LBPH distance to a 0-99 confidence (lower dist = higher)."""
        # Map distance 0 -> ~99, distance == LBPH_MAX_DISTANCE -> ~50.
        d0 = self.LBPH_MAX_DISTANCE
        score = 99.0 * (1.0 - min(1.0, distance / (d0 * 2.0)))
        return max(0.0, min(99.0, score))

    def recognize(self, roi, recognizer, label_to_sid: dict):
        """Predict (student_id, lbph_distance, confidence) for a live face ROI.

        Returns ``(None, distance, confidence)`` when the prediction's distance
        exceeds ``LBPH_MAX_DISTANCE`` (i.e. no confident match — an unenrolled
        or wrong face).
        """
        if recognizer is None or not label_to_sid:
            return None, 999.0, 0.0
        crop = self.normalize_face(roi)
        label, distance = recognizer.predict(crop)
        conf = self.lbph_confidence(distance)
        if distance > self.LBPH_MAX_DISTANCE:
            return None, distance, conf
        return label_to_sid.get(label), distance, conf

    @staticmethod
    def feature_samples(value) -> list[list[float]]:
        """Accept both old single-vector storage and new multi-sample storage."""
        if isinstance(value, dict):
            return value.get("samples", [])
        if isinstance(value, list) and value and isinstance(value[0], list):
            return value
        if isinstance(value, list):
            return [value]
        return []

    @staticmethod
    def encode_samples(samples: list[list[float]]) -> str:
        return json.dumps({"model": "opencv_handcrafted_multi", "samples": samples})

    @staticmethod
    def decode_feature_json(raw: str):
        value = json.loads(raw)
        if isinstance(value, dict) and "samples" in value:
            return value
        return {"model": "legacy_single", "samples": FaceEngine.feature_samples(value)}

    def detect_faces(self, gray) -> list:
        """Return list of (x,y,w,h) tuples — never a raw numpy array."""
        result = self.face_cascade.detectMultiScale(gray, 1.08, 5, minSize=(70, 70))
        # detectMultiScale returns () when empty, or a numpy array when faces found
        # Convert to a plain Python list of tuples to avoid numpy boolean ambiguity
        if result is None or (hasattr(result, '__len__') and len(result) == 0):
            return []
        return [tuple(map(int, face)) for face in result]
