"""Application modules for Smart University Attendance Management System."""

