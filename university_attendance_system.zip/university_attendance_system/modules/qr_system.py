"""Dynamic QR attendance — teacher side (generate) and student side (scan/paste)."""

from __future__ import annotations

import socket
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# Must match app.py port exactly.
ATTENDANCE_SERVER_PORT = 5000
ATTENDANCE_PROTOCOL   = "http"   # plain HTTP — camera uses file-input, not getUserMedia


def get_lan_ip() -> str:
    """Best-effort LAN IP for the QR URL."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def get_server_base_url() -> str:
    """Return the base URL of the running Flask attendance server."""
    return f"{ATTENDANCE_PROTOCOL}://{get_lan_ip()}:{ATTENDANCE_SERVER_PORT}"


def build_scan_url(session_id: str) -> str:
    """URL encoded in the QR code.
    
    Encoding only the short session id (not the full signed token) keeps the
    QR at version 3 — easy for any phone camera to scan.  The Flask server
    looks up the session by that id.
    """
    from urllib.parse import quote
    base = get_server_base_url()
    return f"{base}/?sid={quote(session_id, safe='')}"


def ensure_qr():
    try:
        import qrcode
        from PIL import ImageTk
        return qrcode, ImageTk
    except Exception:
        return None, None


class QRSystemFrame(tk.Frame):
    """Teacher generates QR sessions; students scan or paste token."""

    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db          = db
        self.user        = user
        self.theme       = theme
        self.current_token   = None
        self.current_payload = None
        self.scan_url        = None
        self.qr_photo        = None
        self.timer_job       = None
        self.seconds_left    = 0
        self._expiry         = 300     # default; overwritten from settings
        self.build()

    # ── Build UI ──────────────────────────────────────────────────────────────
    def build(self):
        th = self.theme

        # Try to read expiry from settings
        try:
            v = self.db.scalar("SELECT value FROM settings WHERE key='qr_expiry_seconds'")
            if v: self._expiry = max(30, int(v))
        except Exception:
            pass

        tk.Label(self, text="Dynamic QR Attendance",
                 bg=th["bg"], fg=th["text"],
                 font=("Segoe UI", 22, "bold")).pack(anchor="w")

        # Server URL banner ─────────────────────────────────────────────────
        url_bar = tk.Frame(self, bg="#1e3a5f", padx=14, pady=8)
        url_bar.pack(fill="x", pady=(0, 10))
        tk.Label(url_bar,
                 text="Students open this URL on their phone (same WiFi):",
                 bg="#1e3a5f", fg="#93c5fd",
                 font=("Segoe UI", 9)).pack(anchor="w")
        self._url_bar_lbl = tk.Label(
            url_bar, text=get_server_base_url(),
            bg="#1e3a5f", fg="#ffffff",
            font=("Segoe UI", 13, "bold"),
        )
        self._url_bar_lbl.pack(anchor="w")
        tk.Label(url_bar,
                 text="Or scan the QR code — it opens this page automatically.",
                 bg="#1e3a5f", fg="#64748b",
                 font=("Segoe UI", 8)).pack(anchor="w")

        body = tk.Frame(self, bg=th["bg"])
        body.pack(fill="both", expand=True, pady=8)

        # ── LEFT: teacher / QR generation ──────────────────────────────────
        left = tk.Frame(body, bg=th["card"], padx=16, pady=14)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))

        tk.Label(left, text="Teacher — Generate QR Session",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")

        self.course = ttk.Combobox(
            left, state="readonly",
            values=[f"{r['course_id']} - {r['subject_name']}"
                    for r in self.db.query(
                        "SELECT course_id, subject_name FROM courses ORDER BY subject_name")],
            width=44,
        )
        self.course.pack(fill="x", pady=(8, 4))

        tk.Button(left, text="▶  Generate / Refresh QR",
                  bg=th["primary"], fg="white", relief="flat",
                  font=("Segoe UI", 10, "bold"),
                  command=self.generate).pack(fill="x", pady=6)

        # QR image
        self.qr_label = tk.Label(left, bg="white", width=32, height=16)
        self.qr_label.pack(pady=(10, 6))

        # Info (session details + countdown)
        self.info = tk.Label(left, text="No active session.",
                             bg=th["card"], fg=th["muted"],
                             justify="left", font=("Segoe UI", 9))
        self.info.pack(anchor="w")

        # Scan URL shown to teacher
        self._scan_url_lbl = tk.Label(
            left, text="",
            bg=th["card"], fg="#38bdf8",
            font=("Segoe UI", 9), justify="left", wraplength=380,
        )
        self._scan_url_lbl.pack(anchor="w", pady=(6, 0))

        # Token (for manual entry / debug)
        tk.Label(left, text="QR Token (students can paste this manually):",
                 bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(10, 2))
        self.app_token_text = tk.Text(
            left, height=2, bg=th["panel"], fg=th["text"],
            insertbackground=th["text"], relief="flat",
            wrap="char", font=("Consolas", 8),
        )
        self.app_token_text.pack(fill="x")

        # ── RIGHT: student / paste or scan image ───────────────────────────
        right = tk.Frame(body, bg=th["card"], padx=16, pady=14)
        right.pack(side="left", fill="both", expand=True)

        tk.Label(right, text="Student — Submit Token",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")

        tk.Label(right, text="Select student:", bg=th["card"], fg=th["muted"]).pack(anchor="w", pady=(8, 2))
        self.student_id = ttk.Combobox(
            right,
            values=[f"{r['student_id']} - {r['name']}"
                    for r in self.db.query(
                        "SELECT student_id, name FROM students ORDER BY name LIMIT 700")],
        )
        self.student_id.pack(fill="x", pady=(0, 6))

        tk.Label(right, text="Paste token or decode QR image:",
                 bg=th["card"], fg=th["muted"]).pack(anchor="w")
        self.token_text = tk.Text(
            right, height=7,
            bg=th["panel"], fg=th["text"],
            insertbackground=th["text"], relief="flat",
        )
        self.token_text.pack(fill="x", pady=6)

        tk.Button(right, text="📷  Scan QR Image File",
                  bg=th["accent"], fg="white", relief="flat",
                  command=self.scan_image).pack(fill="x", pady=3)
        tk.Button(right, text="✔  Mark QR Attendance",
                  bg=th["primary"], fg="white", relief="flat",
                  font=("Segoe UI", 11, "bold"),
                  command=self.submit).pack(fill="x", pady=3)

    # ── Generate QR ───────────────────────────────────────────────────────────
    def generate(self):
        qrcode, ImageTk = ensure_qr()
        if qrcode is None:
            messagebox.showerror("Missing Dependency",
                                 "Install: pip install qrcode[pil] Pillow")
            return
        if not self.course.get():
            messagebox.showerror("Select Course", "Please select a course first.")
            return

        course_id  = self.course.get().split(" - ")[0]
        teacher_id = (self.user.get("linked_id") if isinstance(self.user, dict)
                      else self.user["linked_id"]) or "ADMIN"

        # Cancel previous timer
        if self.timer_job:
            try: self.after_cancel(self.timer_job)
            except tk.TclError: pass

        # Create session with configurable expiry
        try:
            expiry = max(30, int(
                self.db.scalar("SELECT value FROM settings WHERE key='qr_expiry_seconds'") or 300))
        except Exception:
            expiry = 300

        self.current_token, payload = self.db.create_qr_session(
            course_id, teacher_id, expiry)
        self.current_payload = payload
        self._expiry = expiry

        # Build scan URL (short, low-density QR)
        sid = payload.get("session_id", "")
        self.scan_url = build_scan_url(sid)

        # Save QR image
        qr_dir = Path(__file__).resolve().parents[1] / "assets" / "qr_codes"
        qr_dir.mkdir(parents=True, exist_ok=True)
        qr_img = qrcode.make(self.scan_url).resize((280, 280))
        qr_img.save(qr_dir / f"qr_{course_id}.png")
        self.qr_photo = ImageTk.PhotoImage(qr_img)
        self.qr_label.configure(image=self.qr_photo, bg="white")

        # Update labels
        self._scan_url_lbl.configure(
            text=f"Scan URL: {self.scan_url}\nSession ID: {sid}")
        self.app_token_text.delete("1.0", "end")
        self.app_token_text.insert("1.0", self.current_token)
        self.token_text.delete("1.0", "end")
        self.token_text.insert("1.0", self.current_token)

        # Also keep server URL bar fresh
        self._url_bar_lbl.configure(text=get_server_base_url())

        self.seconds_left = expiry
        self._tick(payload)

    # ── Countdown tick ────────────────────────────────────────────────────────
    def _tick(self, payload):
        if self.seconds_left > 0:
            bar = "█" * int(self.seconds_left / self._expiry * 20) + \
                  "░" * (20 - int(self.seconds_left / self._expiry * 20))
            self.info.configure(
                text=f"Session: {payload.get('session_id')}  |  "
                     f"{payload['subject']}  "
                     f"Sem {payload['semester']} Sec {payload['section']}\n"
                     f"Expires in: {self.seconds_left}s  {bar}",
                fg=("#34d399" if self.seconds_left > 20 else "#fbbf24"),
            )
            self.seconds_left -= 1
            self.timer_job = self.after(1000, lambda: self._tick(payload))
        else:
            self.info.configure(
                text="⚠  QR Expired — click 'Generate / Refresh QR' for a new one.",
                fg="#fb7185",
            )
            self.qr_label.configure(
                image="", text="QR\nExpired",
                bg="#1e293b", fg="#fb7185",
                font=("Segoe UI", 14, "bold"),
            )

    # ── Scan QR from image file ───────────────────────────────────────────────
    def scan_image(self):
        path = filedialog.askopenfilename(
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif")])
        if not path:
            return
        from modules.face_system import decode_qr_from_image
        try:
            results = decode_qr_from_image(path)
            if results:
                self.token_text.delete("1.0", "end")
                self.token_text.insert("1.0", results[0])
                messagebox.showinfo("QR Decoded", f"Token extracted:\n{results[0][:80]}…")
            else:
                messagebox.showwarning("Not Found", "No QR code found in that image.")
        except Exception as exc:
            messagebox.showerror("Scan Error", str(exc))

    # ── Desktop submit (student pastes / scans token) ─────────────────────────
    def submit(self):
        raw = self.token_text.get("1.0", "end").strip()
        if not raw:
            messagebox.showerror("No Token", "Paste or scan the QR token first.")
            return
        sel = self.student_id.get().strip()
        if not sel:
            messagebox.showerror("No Student", "Select the student from the dropdown.")
            return
        student_id = sel.split(" - ")[0].strip()

        # Detect whether raw is a URL with ?sid=, a bare session id, or a signed token
        session_id = None
        token_val  = None
        if "sid=" in raw:
            from urllib.parse import urlparse, parse_qs
            try:
                qs = parse_qs(urlparse(raw).query)
                session_id = qs.get("sid", [None])[0]
            except Exception:
                pass
        if session_id:
            ok, msg, course_id = self.db.validate_qr_by_session_id(session_id, student_id)
        else:
            token_val = raw
            ok, msg, course_id = self.db.validate_qr_session(token_val, student_id)

        if not ok:
            messagebox.showerror("QR Invalid", msg)
            return

        marked, mark_msg = self.db.mark_attendance(
            student_id, course_id, "Present", "QR",
            token=token_val, session_id=session_id,
        )
        if marked or "marked" in mark_msg.lower():
            messagebox.showinfo("Attendance Marked",
                                f"✅ Attendance recorded for {student_id}!")
        elif "already" in mark_msg.lower() or "exists" in mark_msg.lower():
            messagebox.showinfo("Already Marked",
                                f"Attendance was already recorded for {student_id}.")
        else:
            messagebox.showerror("Error", mark_msg)
