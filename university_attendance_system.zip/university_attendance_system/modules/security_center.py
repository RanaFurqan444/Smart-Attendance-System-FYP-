"""Security Center for liveness, spoofing, and anti-fraud monitoring."""

from __future__ import annotations

import csv
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


class SecurityCenterFrame(tk.Frame):
    """Admin-facing security dashboard for anti-spoofing and liveness logs."""

    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.user = user
        self.theme = theme
        self.build()

    def build(self) -> None:
        tk.Label(self, text="Security Center", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 24, "bold")).pack(anchor="w")
        tk.Label(self, text="Live security monitor, spoofing logs, analytics, reports, and settings.", bg=self.theme["bg"], fg=self.theme["muted"]).pack(anchor="w")
        self.cards()
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, pady=12)
        for title, builder in [
            ("Live Monitor", self.live_monitor),
            ("Spoofing Logs", self.spoofing_logs),
            ("Security Analytics", self.analytics),
            ("Security Reports", self.reports),
            ("Security Settings", self.settings),
        ]:
            frame = tk.Frame(notebook, bg=self.theme["card"], padx=12, pady=12)
            notebook.add(frame, text=title)
            builder(frame)

    def cards(self) -> None:
        row = tk.Frame(self, bg=self.theme["bg"])
        row.pack(fill="x", pady=12)
        stats = [
            ("Total Attempts", self.db.scalar("SELECT COUNT(*) FROM liveness_logs") or 0, "#60a5fa"),
            ("Successful", self.db.scalar("SELECT COUNT(*) FROM liveness_logs WHERE final_decision LIKE 'APPROVED%'") or 0, "#34d399"),
            ("Failed", self.db.scalar("SELECT COUNT(*) FROM liveness_logs WHERE final_decision='BLOCKED'") or 0, "#fb7185"),
            ("Spoofing", self.db.scalar("SELECT COUNT(*) FROM spoofing_logs") or 0, "#f59e0b"),
            ("Events", self.db.scalar("SELECT COUNT(*) FROM security_events") or 0, "#a78bfa"),
        ]
        for label, value, color in stats:
            card = tk.Frame(row, bg=self.theme["card"], padx=14, pady=10)
            card.pack(side="left", fill="x", expand=True, padx=4)
            tk.Label(card, text=label, bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w")
            tk.Label(card, text=value, bg=self.theme["card"], fg=color, font=("Segoe UI", 18, "bold")).pack(anchor="w")

    def live_monitor(self, parent):
        self.table(parent, "Recent Security Events", self.db.query(
            """
            SELECT created_at, event_type, student_id, course_id, session_id, failure_reason
            FROM security_events ORDER BY created_at DESC LIMIT 200
            """
        ))

    def spoofing_logs(self, parent):
        self.table(parent, "Spoofing Attempts", self.db.query(
            """
            SELECT created_at, student_id, student_name, course_id, session_id, real_confidence,
            fake_confidence, attack_type, screenshot_path
            FROM spoofing_logs ORDER BY created_at DESC LIMIT 200
            """
        ))

    def analytics(self, parent):
        try:
            import pandas as pd
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            with self.db.connect() as conn:
                df = pd.read_sql_query("SELECT * FROM liveness_logs", conn)
            if df.empty:
                tk.Label(parent, text="No security analytics yet.", bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w")
                return
            df["created_at"] = pd.to_datetime(df["created_at"])
            fig, axes = plt.subplots(1, 2, figsize=(10, 4), facecolor="#1f2937")
            for ax in axes:
                ax.set_facecolor("#111827")
                ax.tick_params(colors="#e5e7eb")
                for spine in ax.spines.values():
                    spine.set_color("#334155")
            df["final_decision"].value_counts().plot(kind="bar", ax=axes[0], color="#60a5fa")
            axes[0].set_title("Verification Decisions", color="#e5e7eb")
            df.set_index("created_at").resample("ME").size().plot(ax=axes[1], color="#34d399", marker="o")
            axes[1].set_title("Monthly Security Trends", color="#e5e7eb")
            fig.tight_layout()
            canvas = FigureCanvasTkAgg(fig, master=parent)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)
        except Exception as exc:
            tk.Label(parent, text=f"Analytics unavailable: {exc}", bg=self.theme["card"], fg=self.theme["danger"]).pack(anchor="w")

    def reports(self, parent):
        tk.Button(parent, text="Export Security Events CSV", bg=self.theme["primary"], fg="white", relief="flat", command=self.export_events).pack(anchor="w", pady=6)
        tk.Button(parent, text="Export Liveness Logs CSV", bg=self.theme["accent"], fg="white", relief="flat", command=self.export_liveness).pack(anchor="w", pady=6)

    def settings(self, parent):
        threshold = tk.StringVar(value=str(self.db.scalar("SELECT value FROM settings WHERE key='passive_liveness_threshold'") or 80))
        tk.Label(parent, text="Passive Liveness Threshold", bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w")
        tk.Entry(parent, textvariable=threshold, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat").pack(fill="x", ipady=8, pady=6)

        def save():
            try:
                value = float(threshold.get())
                if not 50 <= value <= 99:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Validation", "Threshold must be between 50 and 99.")
                return
            self.db.execute("INSERT INTO settings(key,value) VALUES('passive_liveness_threshold',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(value),))
            messagebox.showinfo("Saved", "Security setting saved.")

        tk.Button(parent, text="Save Security Settings", bg=self.theme["primary"], fg="white", relief="flat", command=save).pack(anchor="w", pady=6)

    def table(self, parent, title, rows):
        tk.Label(parent, text=title, bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 14, "bold")).pack(anchor="w")
        if not rows:
            tk.Label(parent, text="No records found.", bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w", pady=8)
            return
        cols = list(rows[0].keys())
        tree = ttk.Treeview(parent, columns=cols, show="headings")
        for col in cols:
            tree.heading(col, text=col.replace("_", " ").title())
            tree.column(col, width=130)
        ybar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ybar.set)
        tree.pack(side="left", fill="both", expand=True, pady=8)
        ybar.pack(side="right", fill="y", pady=8)
        for row in rows:
            tree.insert("", "end", values=[row[col] for col in cols])

    def export_query(self, sql, default_name):
        path = filedialog.asksaveasfilename(initialfile=default_name, defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not path:
            return
        rows = self.db.query(sql)
        if not rows:
            messagebox.showwarning("Export", "No records to export.")
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(rows[0].keys())
            for row in rows:
                writer.writerow([row[k] for k in row.keys()])
        messagebox.showinfo("Exported", path)

    def export_events(self):
        self.export_query("SELECT * FROM security_events ORDER BY created_at DESC", "security_events.csv")

    def export_liveness(self):
        self.export_query("SELECT * FROM liveness_logs ORDER BY created_at DESC", "liveness_logs.csv")
