"""Separated analytics dashboard with one graph or table per tab."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

try:
    import numpy as _np          # used by forecasting_graph and ai_insights
except ImportError:              # graceful fallback if numpy missing
    _np = None


class AnalyticsFrame(tk.Frame):
    """Professional analytics module using Pandas and Matplotlib in Tkinter."""

    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db        = db
        self.theme     = theme
        self.df        = None
        self._notebook = None
        self._error    = ""
        # Filter StringVars initialized here — safe to access from load_dataframe()
        self.f_program  = tk.StringVar(value="All")
        self.f_semester = tk.StringVar(value="All")
        self.f_course   = tk.StringVar(value="All")
        self.f_section  = tk.StringVar(value="All")
        self.f_from     = tk.StringVar(value="")
        self.f_to       = tk.StringVar(value="")
        self.build()

    def build(self) -> None:
        th = self.theme
        tk.Label(self, text="Attendance Analytics",
                 bg=th["bg"], fg=th["text"],
                 font=("Segoe UI", 22, "bold")).pack(anchor="w")
        tk.Label(self, text="Filter by program, semester, course, section, or date range — then click Apply.",
                 bg=th["bg"], fg=th["muted"]).pack(anchor="w")

        # ── Filter bar ────────────────────────────────────────────────────────
        fbar = tk.Frame(self, bg=th["card"], padx=14, pady=10)
        fbar.pack(fill="x", pady=(8, 0))

        programs = ["All"] + [r["name"] for r in
                              self.db.query("SELECT name FROM departments ORDER BY name")]
        courses = ["All"] + [f"{r['course_id']} — {r['subject_name']}"
                             for r in self.db.query(
            "SELECT course_id, subject_name FROM courses ORDER BY course_id")]

        labels = ["Program", "Semester", "Course", "Section", "From (YYYY-MM-DD)", "To (YYYY-MM-DD)"]
        # Reuse StringVars already initialized in __init__
        self.f_program.set("All");  self.f_semester.set("All")
        self.f_course.set("All");   self.f_section.set("All")
        self.f_from.set("");        self.f_to.set("")

        prog_cb = ttk.Combobox(fbar, textvariable=self.f_program,
                               values=programs, state="readonly", width=22)
        sem_cb = ttk.Combobox(fbar, textvariable=self.f_semester,
                              values=["All", "2", "4", "6", "8"], state="readonly", width=8)
        crs_cb = ttk.Combobox(fbar, textvariable=self.f_course,
                              values=courses, state="readonly", width=30)
        sec_cb = ttk.Combobox(fbar, textvariable=self.f_section,
                              values=["All", "A", "B"], state="readonly", width=6)
        from_e = tk.Entry(fbar, textvariable=self.f_from,
                          bg=th["panel"], fg=th["text"], insertbackground=th["text"],
                          relief="flat", width=12)
        to_e = tk.Entry(fbar, textvariable=self.f_to,
                        bg=th["panel"], fg=th["text"], insertbackground=th["text"],
                        relief="flat", width=12)

        widgets = [prog_cb, sem_cb, crs_cb, sec_cb, from_e, to_e]
        for i, (lbl_text, widget) in enumerate(zip(labels, widgets)):
            tk.Label(fbar, text=lbl_text, bg=th["card"], fg=th["muted"],
                     font=("Segoe UI", 8, "bold")).grid(row=0, column=i, sticky="w", padx=6)
            widget.grid(row=1, column=i, sticky="ew", padx=6, pady=(2, 0), ipady=3)
            fbar.grid_columnconfigure(i, weight=1 if i in (0, 2) else 0)

        apply_btn = tk.Button(fbar, text="▶  Apply Filters",
                              bg=th["primary"], fg="white",
                              font=("Segoe UI", 10, "bold"), relief="flat",
                              padx=16, pady=6, command=self._apply_filters)
        apply_btn.grid(row=1, column=len(widgets), padx=(10, 0), pady=(2, 0))
        tk.Button(fbar, text="✕ Reset",
                  bg=th["panel"], fg=th["text"], relief="flat",
                  padx=10, pady=6,
                  command=self._reset_filters).grid(row=1, column=len(widgets) + 1, padx=4, pady=(2, 0))

        # ── Notebook (rebuilt on each Apply) ──────────────────────────────────
        self._nb_frame = tk.Frame(self, bg=th["bg"])
        self._nb_frame.pack(fill="both", expand=True, pady=8)
        self._apply_filters()

    def _reset_filters(self):
        self.f_program.set("All")
        self.f_semester.set("All")
        self.f_course.set("All")
        self.f_section.set("All")
        self.f_from.set("")
        self.f_to.set("")
        self._apply_filters()

    def _apply_filters(self):
        """Rebuild all tabs with currently selected filters."""
        for w in self._nb_frame.winfo_children():
            w.destroy()
        self.df = self.load_dataframe()
        if self.df is None:
            self.error(self._nb_frame,
                       "pandas / matplotlib not installed.\n\nRun:  pip install pandas matplotlib numpy")
            return
        if self.df.empty:
            frame = tk.Frame(self._nb_frame, bg=self.theme["card"], padx=24, pady=24)
            frame.pack(fill="both", expand=True)
            tk.Label(frame, text="No attendance data matches the selected filters.",
                     bg=self.theme["card"], fg="#fb7185",
                     font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 8))
            tk.Label(frame,
                     text="Tips:\n"
                     "  1. Click \u2715 Reset to clear all filters, then Apply\n"
                     "  2. Check Dashboard — if Total Records = 0, data not seeded yet\n"
                     "  3. Delete database\\university.db and restart to regenerate 6-month sample data",
                     bg=self.theme["card"], fg=self.theme["muted"],
                     font=("Segoe UI", 10), justify="left").pack(anchor="w")
            return
        # Show applied filter summary
        prog = self.f_program.get() if self.f_program else "All"
        sem  = self.f_semester.get() if self.f_semester else "All"
        crs  = (self.f_course.get() or "All")[:35]
        info = f"Showing: Program={prog}  Sem={sem}  Course={crs}  |  {len(self.df):,} records"
        tk.Label(self._nb_frame, text=info,
                 bg=self.theme["bg"], fg=self.theme["muted"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 2))
        self._notebook = ttk.Notebook(self._nb_frame)
        self._notebook.pack(fill="both", expand=True)
        sections = [
            ("Daily Trend", self.daily_graph),
            ("Weekly", self.weekly_graph),
            ("Monthly", self.monthly_graph),
            ("Programs", self.department_graph),
            ("Semesters", self.semester_graph),
            ("Courses", self.subject_graph),
            ("Top Absent", self.top_absent),
            ("Defaulters", self.risk_prediction),
            ("90-Day Trend", self.trend_graph),
            ("Forecasting", self.forecasting_graph),
            ("AI Insights", self.ai_insights),
        ]
        for title, builder in sections:
            tab = self.scrollable_tab(self._notebook, title)
            builder(tab)

    def scrollable_tab(self, notebook: ttk.Notebook, title: str) -> tk.Frame:
        outer = tk.Frame(notebook, bg=self.theme["bg"])
        notebook.add(outer, text=title)
        canvas = tk.Canvas(outer, bg=self.theme["bg"], highlightthickness=0)
        ybar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=self.theme["bg"], padx=12, pady=12)
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))
        canvas.configure(yscrollcommand=ybar.set)
        canvas.pack(side="left", fill="both", expand=True)
        ybar.pack(side="right", fill="y")
        return inner

    def load_dataframe(self):
        try:
            import pandas as pd
            where_parts, params = [], []

            # Program filter
            prog = self.f_program.get() if self.f_program else "All"
            if prog and prog != "All":
                where_parts.append("d.name = ?")
                params.append(prog)

            # Semester filter
            sem = self.f_semester.get() if self.f_semester else "All"
            if sem and sem != "All":
                where_parts.append("s.semester = ?")
                params.append(int(sem))

            # Course filter
            crs_raw = self.f_course.get() if self.f_course else "All"
            if crs_raw and crs_raw != "All":
                crs_id = crs_raw.split(" — ")[0].strip()
                where_parts.append("a.course_id = ?")
                params.append(crs_id)

            # Section filter
            sec = self.f_section.get() if self.f_section else "All"
            if sec and sec != "All":
                where_parts.append("s.section = ?")
                params.append(sec)

            # Date range filters
            d_from = (self.f_from.get() or "").strip() if self.f_from else ""
            d_to = (self.f_to.get() or "").strip() if self.f_to else ""
            if d_from:
                where_parts.append("a.date >= ?")
                params.append(d_from)
            if d_to:
                where_parts.append("a.date <= ?")
                params.append(d_to)

            where_sql = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""

            with self.db.connect() as conn:
                df = pd.read_sql_query(
                    f"""
                    SELECT a.student_id, a.course_id, a.date, a.time,
                           a.status, a.method, a.confidence,
                           s.name student_name, s.semester, s.section,
                           d.name department, c.subject_name
                    FROM attendance a
                    JOIN students    s ON s.student_id   = a.student_id
                    JOIN departments d ON d.id            = s.department_id
                    JOIN courses     c ON c.course_id     = a.course_id
                    {where_sql}
                    """,
                    conn,
                    params=tuple(params) if params else None,
                )
            if df.empty:
                return df
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
            df = df.dropna(subset=["date"])
            df["present"] = (df["status"] == "Present").astype(int)
            df["month"] = df["date"].dt.to_period("M").astype(str)
            df["weekday"] = df["date"].dt.day_name().str[:3]
            return df
        except Exception as exc:
            self._error = str(exc)
            return None

    def plot(self, parent, title: str, draw_func) -> None:
        if self.df is None or self.df.empty:
            self.error(parent, "No attendance records available for analytics.")
            return
        try:
            import matplotlib
            matplotlib.use("TkAgg")
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            fig, ax = plt.subplots(figsize=(10.5, 5.6), facecolor="#0f172a")
            self.style_axis(ax, title)
            draw_func(ax)
            fig.tight_layout(pad=2.0)
            canvas = FigureCanvasTkAgg(fig, master=parent)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, pady=8)
            plt.close(fig)   # free memory; Tkinter canvas keeps its own rendered copy
        except Exception as exc:
            self.error(parent, str(exc))

    @staticmethod
    def style_axis(ax, title: str) -> None:
        ax.set_facecolor("#111827")
        ax.set_title(title, color="#e5e7eb", fontsize=14, pad=12)
        ax.tick_params(colors="#e5e7eb", labelsize=9)
        ax.xaxis.label.set_color("#e5e7eb")
        ax.yaxis.label.set_color("#e5e7eb")
        for spine in ax.spines.values():
            spine.set_color("#334155")
        ax.grid(True, alpha=0.18)

    def daily_graph(self, parent):
        def draw(ax):
            daily = self.df.groupby("date")["present"].mean().mul(100).tail(45)
            if daily.empty:
                ax.text(0.5, 0.5, "No attendance data", transform=ax.transAxes,
                        ha="center", color="#94a3b8")
                return
            xs = list(range(len(daily)))
            ys = daily.values.tolist()
            ax.fill_between(xs, ys, color="#38bdf8", alpha=0.18)
            ax.plot(xs, ys, color="#38bdf8", marker="o", markersize=3,
                    linewidth=2, label="Daily")
            if len(daily) >= 7:
                roll = daily.rolling(7, min_periods=1).mean().values.tolist()
                ax.plot(xs, roll, color="#fbbf24", linewidth=2, linestyle="--",
                        label="7-day avg")
            ax.axhline(75, color="#fb7185", lw=1, ls=":", alpha=0.7)
            step = max(1, len(xs) // 8)
            ax.set_xticks(xs[::step])
            ax.set_xticklabels([str(daily.index[i])[:10] for i in xs[::step]],
                               rotation=30, ha="right", fontsize=7)
            ax.set_ylabel("Attendance %"); ax.set_ylim(0, 105)
            ax.legend(facecolor="#111827", labelcolor="#e5e7eb", fontsize=8)
        self.plot(parent, "Daily Attendance Trend (Last 45 Days)", draw)

    def monthly_graph(self, parent):
        def draw(ax):
            monthly = self.df.groupby("month")["present"].mean().mul(100)
            if monthly.empty:
                ax.text(0.5, 0.5, "No data", transform=ax.transAxes,
                        ha="center", color="#94a3b8")
                return
            xs = list(range(len(monthly)))
            bars = ax.bar(xs, monthly.values, color="#34d399", width=0.65, zorder=3)
            ax.set_xticks(xs)
            ax.set_xticklabels(list(monthly.index), rotation=40, ha="right", fontsize=8)
            ax.set_ylabel("Attendance %"); ax.set_ylim(0, 105)
            ax.axhline(75, color="#fb7185", lw=1, ls="--", alpha=0.7)
            for bar, val in zip(bars, monthly.values):
                ax.text(bar.get_x() + bar.get_width() / 2, val + 0.5,
                        f"{val:.0f}%", ha="center", va="bottom",
                        color="#e5e7eb", fontsize=7)
        self.plot(parent, "Monthly Attendance Trend", draw)

    def weekly_graph(self, parent):
        def draw(ax):
            day_order = ["Mon", "Tue", "Wed", "Thu", "Fri"]
            if "weekday" not in self.df.columns:
                ax.text(0.5, 0.5, "No weekday data", transform=ax.transAxes,
                        ha="center", color="#94a3b8")
                return
            wkday = (self.df[self.df["weekday"].isin(day_order)]
                     .groupby("weekday")["present"].mean()
                     .mul(100).reindex(day_order).fillna(0))
            colors = ["#60a5fa", "#34d399", "#fbbf24", "#a78bfa", "#fb7185"]
            bars = ax.bar(day_order, wkday.values, color=colors, width=0.6, zorder=3)
            ax.set_ylabel("Attendance %"); ax.set_ylim(0, 105)
            ax.axhline(75, color="#fb7185", lw=1, ls="--", alpha=0.7)
            for bar, val in zip(bars, wkday.values):
                ax.text(bar.get_x() + bar.get_width() / 2, val + 0.5,
                        f"{val:.0f}%", ha="center", va="bottom",
                        color="#e5e7eb", fontsize=7)
        self.plot(parent, "Weekly Attendance Pattern (Mon–Fri)", draw)

    def department_graph(self, parent):
        def draw(ax):
            dept = self.df.groupby("department")["present"].mean().mul(100).sort_values(ascending=False)
            colors = ["#38bdf8", "#34d399", "#f472b6", "#fbbf24", "#a78bfa"]
            ax.bar(range(len(dept)), dept.values, color=colors[:len(dept)], width=0.6)
            ax.set_xticks(range(len(dept)))
            ax.set_xticklabels(dept.index, rotation=15, ha="right")
            ax.set_ylabel("Attendance %")
            ax.axhline(75, color="#fb7185", linewidth=1, linestyle="--", alpha=0.7)
        self.plot(parent, "Program Attendance Comparison", draw)

    def semester_graph(self, parent):
        def draw(ax):
            sem = self.df.groupby("semester")["present"].mean().mul(100).sort_index()
            colors = ["#60a5fa", "#34d399", "#fbbf24", "#fb7185"]
            ax.bar([str(s) for s in sem.index], sem.values, color=colors[:len(sem)], width=0.6)
            ax.set_ylabel("Attendance %")
            ax.set_xlabel("Semester")
            ax.axhline(75, color="#fb7185", linewidth=1, linestyle="--", alpha=0.7)
            for i, v in enumerate(sem.values):
                ax.text(i, v + 0.5, f"{v:.1f}%", ha="center", va="bottom", color="#e5e7eb", fontsize=9)
        self.plot(parent, "Semester-Wise Attendance Comparison", draw)

    def subject_graph(self, parent):
        def draw(ax):
            subject = self.df.groupby("subject_name")["present"].mean().mul(100).sort_values()
            bars = ax.barh(range(len(subject)), subject.values, color="#a78bfa", height=0.7)
            ax.set_yticks(range(len(subject)))
            ax.set_yticklabels(subject.index, fontsize=8)
            ax.set_xlabel("Attendance %")
            ax.axvline(75, color="#fb7185", linewidth=1, linestyle="--", alpha=0.7)
        self.plot(parent, "Course Attendance Analysis", draw)

    def forecasting_graph(self, parent):
        def draw(ax):
            np = _np
            if np is None:
                import numpy as np  # fallback
            daily = self.df.groupby("date")["present"].mean().mul(100).reset_index()
            daily.columns = ["date", "present"]
            daily["date_ord"] = (daily["date"] - daily["date"].min()).dt.days
            if len(daily) < 14:
                ax.text(0.5, 0.5, "Need at least 14 days of data",
                        transform=ax.transAxes, ha="center", color="#94a3b8")
                return
            x = daily["date_ord"].values.astype(float)
            y = daily["present"].values.astype(float)
            coeffs = np.polyfit(x, y, 1)
            trend_fn = np.poly1d(coeffs)
            future_x = np.arange(x[-1] + 1, x[-1] + 31)
            ax.plot(daily["date"], y, color="#60a5fa", lw=1.5, alpha=0.7, label="Actual")
            rolling = daily["present"].rolling(7, min_periods=1).mean()
            ax.plot(daily["date"], rolling.values, color="#34d399", lw=2, label="7-day avg")
            from datetime import timedelta as _td
            last_date = daily["date"].max()
            future_dates = [last_date + _td(days=int(k)) for k in range(1, 31)]
            future_vals = np.clip(trend_fn(future_x), 0, 100)
            ax.plot(future_dates, future_vals, color="#fbbf24", lw=2, ls="--", label="30-day forecast")
            ax.axhline(75, color="#fb7185", lw=1, ls=":", alpha=0.7, label="75% threshold")
            ax.legend(facecolor="#111827", labelcolor="#e5e7eb", fontsize=8)
            ax.set_ylabel("Attendance %")
        self.plot(parent, "Attendance Forecasting (30-Day Projection)", draw)

    def trend_graph(self, parent):
        def draw(ax):
            daily = self.df.groupby("date")["present"].mean().mul(100).tail(90)
            if daily.empty:
                ax.text(0.5, 0.5, "No data", transform=ax.transAxes,
                        ha="center", color="#94a3b8")
                return
            xs = list(range(len(daily)))
            ys = daily.values.tolist()
            ax.fill_between(xs, ys, color="#14b8a6", alpha=0.2)
            ax.plot(xs, ys, color="#2dd4bf", linewidth=2, label="Daily")
            if len(daily) > 6:
                roll = daily.rolling(7, min_periods=1).mean().values.tolist()
                ax.plot(xs, roll, color="#fbbf24", linewidth=2,
                        linestyle="--", label="7-day avg")
            ax.axhline(75, color="#fb7185", lw=1, ls="--", alpha=0.7)
            step = max(1, len(xs) // 10)
            ax.set_xticks(xs[::step])
            ax.set_xticklabels([str(daily.index[i])[:10] for i in xs[::step]],
                               rotation=30, ha="right", fontsize=7)
            ax.set_ylabel("Attendance %"); ax.set_ylim(0, 105)
            ax.legend(facecolor="#111827", labelcolor="#e5e7eb", fontsize=8)
        self.plot(parent, "90-Day Attendance Trend", draw)

    def top_absent(self, parent):
        self.table(parent, "Most Absent Students (Intervention Required)", self.top_rows(best=False), ("Student", "Program", "Attendance %", "Records"))

    def risk_prediction(self, parent):
        self.table(parent, "Defaulter List — At Risk for Exam (Below 75%)", self.risk_rows(), ("Student", "Program", "Semester", "Attendance %", "Risk Level"))

    def ai_insights(self, parent):
        box = tk.Text(parent, bg=self.theme["card"], fg=self.theme["text"], relief="flat",
                      font=("Courier New", 10), padx=18, pady=16, height=24, wrap="word")
        box.pack(fill="both", expand=True)
        if self.df is None or self.df.empty:
            box.insert("end", "No attendance data available.\n")
            box.configure(state="disabled")
            return

        try:
            np = _np
            if np is None:
                import numpy as np   # fallback in-function import
            df = self.df.copy()
            # ── Core metrics
            overall = df["present"].mean() * 100
            dept_rates = df.groupby("department")["present"].mean().mul(100)
            sem_rates = df.groupby("semester")["present"].mean().mul(100)
            month_rates = df.groupby("month")["present"].mean().mul(100)
            course_rates = df.groupby("subject_name")["present"].mean().mul(100)
            # Risk students
            stu_rates = df.groupby("student_id")["present"].mean().mul(100)
            below_75 = (stu_rates < 75).sum()
            below_60 = (stu_rates < 60).sum()
            at_risk_pct = below_75 / max(len(stu_rates), 1) * 100
            # Trend direction (last 3 months vs first 3 months)
            if len(month_rates) >= 6:
                trend_delta = month_rates.iloc[-3:].mean() - month_rates.iloc[:3].mean()
                trend_dir = f"↑ improving by {abs(trend_delta):.1f}%" if trend_delta > 0 else f"↓ declining by {abs(trend_delta):.1f}%"
            elif len(month_rates) >= 2:
                trend_delta = month_rates.iloc[-1] - month_rates.iloc[0]
                trend_dir = f"↑ improving" if trend_delta > 0 else f"↓ declining"
            else:
                trend_dir = "stable (insufficient history)"
            # Best/worst day
            day_order = ["Mon", "Tue", "Wed", "Thu", "Fri"]
            if "weekday" in df.columns:
                wkday = df[df["weekday"].isin(day_order)].groupby("weekday")["present"].mean().mul(100).reindex(day_order).dropna()
                best_day = wkday.idxmax() if not wkday.empty else "N/A"
                worst_day = wkday.idxmin() if not wkday.empty else "N/A"
            else:
                best_day = worst_day = "N/A"
            # Simple linear forecast
            daily = df.groupby("date")["present"].mean().mul(100)
            if len(daily) >= 7:
                x = np.arange(len(daily))
                coeffs = np.polyfit(x, daily.values, 1)
                forecast_30 = np.clip(np.poly1d(coeffs)(len(daily) + 30), 0, 100)
            else:
                forecast_30 = overall

            lines = [
                "=" * 58,
                "  CS DEPARTMENT — AI ATTENDANCE INSIGHTS REPORT",
                "=" * 58,
                "",
                f"  OVERALL PERFORMANCE",
                f"  Overall Attendance Rate : {overall:.1f}%",
                f"  Attendance Trend        : {trend_dir}",
                f"  30-Day Forecast         : {forecast_30:.1f}% (linear projection)",
                f"  Best attendance day     : {best_day}",
                f"  Worst attendance day    : {worst_day}",
                "",
                f"  PROGRAM PERFORMANCE",
            ]
            for prog, rate in dept_rates.sort_values(ascending=False).items():
                flag = "  ✓" if rate >= 80 else ("  ⚠" if rate >= 70 else "  ✗")
                lines.append(f"  {flag}  {prog:<40} {rate:.1f}%")

            lines += [
                "",
                f"  SEMESTER ANALYSIS",
            ]
            for sem, rate in sem_rates.sort_index().items():
                flag = "✓" if rate >= 80 else ("⚠" if rate >= 70 else "✗")
                lines.append(f"    Semester {sem}:  {rate:.1f}%  {flag}")

            worst_course = course_rates.idxmin() if not course_rates.empty else "N/A"
            best_course = course_rates.idxmax() if not course_rates.empty else "N/A"
            lines += [
                "",
                f"  COURSE HIGHLIGHTS",
                f"  Highest attendance: {best_course}  ({course_rates.max():.1f}%)",
                f"  Needs attention  : {worst_course}  ({course_rates.min():.1f}%)",
                "",
                f"  DEFAULTER RISK ANALYSIS",
                f"  Students below 75% (exam risk) : {below_75}  ({at_risk_pct:.1f}% of student body)",
                f"  Students below 60% (critical)  : {below_60}",
                "",
                "  ACTIONABLE RECOMMENDATIONS",
            ]
            if below_75 > 0:
                lines.append(f"  1. Issue warning letters to {below_75} students below 75% immediately.")
            if below_60 > 0:
                lines.append(f"  2. Schedule one-on-one counselling for {below_60} critical-risk students.")
            worst_dept = dept_rates.idxmin() if not dept_rates.empty else ""
            if worst_dept and dept_rates.min() < 75:
                lines.append(f"  3. Investigate attendance issues in {worst_dept} program.")
            if worst_day != "N/A":
                lines.append(f"  4. Address {worst_day} attendance drop — consider timetable review.")
            if forecast_30 < 75:
                lines.append(f"  5. ALERT: Forecast predicts attendance will fall to {forecast_30:.1f}% — take corrective action now.")
            elif forecast_30 >= 85:
                lines.append(f"  5. Attendance forecast looks healthy at {forecast_30:.1f}% — maintain current engagement.")
            lines += [
                "",
                "  All metrics computed from live database. No external AI — pure data science.",
                "=" * 58,
            ]
            box.insert("end", "\n".join(lines))
        except Exception as exc:
            box.insert("end", f"Insight engine error: {exc}")
        box.configure(state="disabled")

    def table(self, parent, title: str, rows: list[tuple], columns: tuple[str, ...]) -> None:
        panel = tk.Frame(parent, bg=self.theme["card"], padx=12, pady=12)
        panel.pack(fill="both", expand=True, pady=8)
        tk.Label(panel, text=title, bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tree = ttk.Treeview(panel, columns=columns, show="headings", height=18)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        ybar = ttk.Scrollbar(panel, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ybar.set)
        tree.pack(side="left", fill="both", expand=True, pady=8)
        ybar.pack(side="right", fill="y", pady=8)
        for row in rows:
            tree.insert("", "end", values=row)

    def top_rows(self, best: bool) -> list[tuple]:
        grp_col = "department" if "department" in self.df.columns else "student_id"
        grouped = (
            self.df
            .groupby(["student_id", "student_name", grp_col])
            .agg(pct=("present", "mean"), records=("present", "count"))
            .reset_index()
        )
        grouped["pct"] = grouped["pct"].mul(100)
        grouped = grouped.sort_values("pct", ascending=not best).head(40)
        return [
            (r.student_name, getattr(r, grp_col), f"{r.pct:.1f}%", int(r.records))
            for r in grouped.itertuples()
        ]

    def risk_rows(self) -> list[tuple]:
        grp_col = "department" if "department" in self.df.columns else "student_id"
        grouped = (
            self.df
            .groupby(["student_id", "student_name", grp_col, "semester"])
            .agg(pct=("present", "mean"))
            .reset_index()
        )
        grouped["pct"] = grouped["pct"].mul(100)
        grouped = grouped[grouped["pct"] < 75].sort_values("pct").head(200)
        rows = []
        for r in grouped.itertuples():
            risk_level = "Critical (<60%)" if r.pct < 60 else "High Risk (<75%)"
            rows.append((r.student_name, getattr(r, grp_col), r.semester, f"{r.pct:.1f}%", risk_level))
        return rows

    def error(self, parent, message: str) -> None:
        tk.Label(parent, text=f"Analytics unavailable: {message}", bg=self.theme["bg"], fg=self.theme["danger"], wraplength=780, justify="left").pack(anchor="w", padx=16, pady=16)
