"""Login and authentication UI."""

from __future__ import annotations

import json
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

from modules.face_system import FaceEngine


class LoginFrame(tk.Frame):
    """Password login with remember-me session handling."""

    def __init__(self, parent, db, on_success, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.on_success = on_success
        self.theme = theme
        self.remember_path = Path(__file__).resolve().parents[1] / "database" / "remember.json"
        self.build()
        self.after(100, self.try_remembered_login)

    def build(self) -> None:
        card = tk.Frame(self, bg=self.theme["card"], padx=42, pady=36)
        card.place(relx=0.5, rely=0.5, anchor="center", width=470)
        tk.Label(card, text="University Attendance", bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 26, "bold")).pack(anchor="w")
        tk.Label(card, text="Management System", bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 14)).pack(anchor="w", pady=(0, 25))
        self.username = self.entry(card, "Username")
        self.password = self.entry(card, "Password", show="*")
        self.remember = tk.BooleanVar(value=True)
        tk.Checkbutton(card, text="Remember me", variable=self.remember, bg=self.theme["card"], fg=self.theme["muted"], activebackground=self.theme["card"], selectcolor=self.theme["panel"]).pack(anchor="w", pady=(4, 18))
        tk.Button(card, text="Login", bg=self.theme["primary"], fg="white", relief="flat", font=("Segoe UI", 12, "bold"), pady=10, command=self.login).pack(fill="x")
        tk.Label(card, text="Login as Admin (admin / admin123) or Teacher (teacher / teacher123)", bg=self.theme["card"], fg=self.theme["muted"], wraplength=380, justify="left").pack(anchor="w", pady=(18, 0))
        self.password.bind("<Return>", lambda _e: self.login())

    def entry(self, parent, label: str, show: str | None = None) -> tk.Entry:
        tk.Label(parent, text=label, bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ent = tk.Entry(parent, show=show, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat", font=("Segoe UI", 12))
        ent.pack(fill="x", ipady=9, pady=(4, 14))
        return ent

    def login(self) -> None:
        user = self.db.authenticate(self.username.get(), self.password.get())
        if not user:
            messagebox.showerror("Login Failed", "Invalid username or password.")
            return
        if self.remember.get():
            token = self.db.remember_user(user["id"])
            self.remember_path.write_text(json.dumps({"token": token}), encoding="utf-8")
        self.on_success(user)

    def try_remembered_login(self) -> None:
        try:
            token = json.loads(self.remember_path.read_text(encoding="utf-8")).get("token")
            user = self.db.get_remembered_user(token)
            if user:
                self.on_success(user)
        except Exception:
            pass

    def face_login(self) -> None:
        try:
            rows = self.db.query("SELECT owner_id, feature_json FROM face_data WHERE owner_type='Student'")
            if not rows:
                messagebox.showwarning("Face Login", "No registered student faces found. Login with password first and register a face in Attendance.")
                return
            known = {r["owner_id"]: json.loads(r["feature_json"]) for r in rows}
            camera = int(self.db.scalar("SELECT value FROM settings WHERE key='camera_index'") or 0)
            threshold = float(self.db.scalar("SELECT value FROM settings WHERE key='face_threshold'") or 72)
            sid, confidence, reason = FaceEngine(camera_index=camera, threshold=threshold).live_recognize(known, seconds=6)
            if not sid:
                messagebox.showerror("Face Login Failed", reason)
                return
            user_rows = self.db.query("SELECT * FROM users WHERE linked_id = ? AND role = 'Student'", (sid,))
            if not user_rows:
                messagebox.showerror("Face Login Failed", "Face matched, but no student login account is linked.")
                return
            messagebox.showinfo("Face Login", f"Welcome. Confidence: {confidence:.1f}%")
            self.on_success(user_rows[0])
        except Exception as exc:
            messagebox.showerror("Face Login Failed", str(exc))
