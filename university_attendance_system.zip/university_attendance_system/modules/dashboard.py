"""University Attendance System — Dashboard with live clock, auto-refresh stats, and real-time activity."""

from __future__ import annotations
import tkinter as tk
from tkinter import ttk


class DashboardFrame(tk.Frame):
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.user = user
        self.theme = theme
        self._alive = True
        self._stat_vals = {}   # key → StringVar (live-updatable)
        self._activity_tree = None
        self.bind("<Destroy>", lambda _e: self._stop())
        self.build()

    def _stop(self):
        self._alive = False

    # ── Master build ──────────────────────────────────────────────────────────
    def build(self):
        # Header row
        hdr = tk.Frame(self, bg=self.theme["bg"])
        hdr.pack(fill="x", pady=(0, 2))

        # Show the configured university name (falls back to a generic title).
        try:
            uni_name = self.db.scalar(
                "SELECT value FROM settings WHERE key='university_name'"
            ) or "University Attendance System"
        except Exception:
            uni_name = "University Attendance System"

        tk.Label(hdr, text=uni_name,
                 bg=self.theme["bg"], fg=self.theme["text"],
                 font=("Segoe UI", 16, "bold")).pack(side="left")

        # Logout button
        logout_cb = (self.user.get("_logout") if isinstance(self.user, dict) else None)
        if logout_cb:
            tk.Button(hdr, text="⏻  Logout",
                      bg=self.theme["danger"], fg="white",
                      relief="flat", font=("Segoe UI", 9, "bold"),
                      padx=10, pady=4,
                      command=logout_cb).pack(side="right")

        # Clock
        clk = tk.Frame(hdr, bg=self.theme["card"], padx=12, pady=6)
        clk.pack(side="right", padx=(0, 10))
        self._date_lbl = tk.Label(clk, text="", bg=self.theme["card"],
                                  fg=self.theme["muted"], font=("Segoe UI", 8))
        self._date_lbl.pack(anchor="e")
        self._time_lbl = tk.Label(clk, text="", bg=self.theme["card"],
                                  fg=self.theme["text"], font=("Segoe UI", 12, "bold"))
        self._time_lbl.pack(anchor="e")
        self._tick_clock()

        # Role tag
        try:
            role = self.user["role"] if self.user else ""
            name = self.user.get("full_name", role) if isinstance(self.user, dict) else self.user["full_name"]
        except Exception:
            role = name = ""
        rc = "#2563eb" if role == "Admin" else "#059669"
        tk.Label(self, text=f"Logged in as: {name}  [{role}]",
                 bg=self.theme["bg"], fg=rc, font=("Segoe UI", 10)).pack(anchor="w")

        # ── KPI cards (with live-update refs)
        stats_data = self._fetch_stats()
        grid = tk.Frame(self, bg=self.theme["bg"])
        grid.pack(fill="x", pady=(8, 10))
        for i, (key, value, color) in enumerate(stats_data):
            card = tk.Frame(grid, bg=self.theme["card"], padx=8, pady=8)
            card.grid(row=0, column=i, sticky="nsew", padx=4)
            grid.grid_columnconfigure(i, weight=1)
            tk.Label(card, text=key, bg=self.theme["card"],
                     fg=self.theme["muted"], font=("Segoe UI", 7, "bold")).pack(anchor="w")
            sv = tk.StringVar(value=str(value))
            self._stat_vals[key] = sv
            tk.Label(card, textvariable=sv, bg=self.theme["card"],
                     fg=color, font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(2, 0))

        # ── Two-column body: chart | summary table
        body = tk.Frame(self, bg=self.theme["bg"])
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=self.theme["card"], padx=10, pady=10)
        right = tk.Frame(body, bg=self.theme["card"], padx=10, pady=10)
        left.pack(side="left", fill="both", expand=True, padx=(0, 6))
        right.pack(side="left", fill="both", expand=True, padx=(6, 0))
        self._build_chart(left)
        self._build_summary(right)

        # start live refresh loop
        self._refresh_loop()

    # ── Live clock (1-second tick) ─────────────────────────────────────────────
    def _tick_clock(self):
        if not self._alive:
            return
        try:
            from datetime import datetime as _dt
            now = _dt.now()
            self._date_lbl.config(text=now.strftime("%A, %d %B %Y"))
            self._time_lbl.config(text=now.strftime("%H:%M:%S"))
            self.after(1000, self._tick_clock)
        except tk.TclError:
            self._alive = False

    # ── Auto-refresh stats + activity every 5 seconds ─────────────────────────
    def _refresh_loop(self):
        if not self._alive:
            return
        try:
            for key, value, _ in self._fetch_stats():
                if key in self._stat_vals:
                    self._stat_vals[key].set(str(value))
            if hasattr(self, "_summary_tree"):
                self._reload_summary()
            self.after(5000, self._refresh_loop)
        except tk.TclError:
            self._alive = False

    # ── KPI data ──────────────────────────────────────────────────────────────
    def _fetch_stats(self):
        try:
            total_students = self.db.scalar("SELECT COUNT(*) FROM students") or 0
            total_teachers = self.db.scalar("SELECT COUNT(*) FROM teachers") or 0
            total_records = self.db.scalar("SELECT COUNT(*) FROM attendance") or 0
            today_att = self.db.scalar(
                "SELECT COUNT(*) FROM attendance WHERE date = date('now','localtime') AND status='Present'"
            ) or 0
            active_sessions = self.db.scalar(
                "SELECT COUNT(*) FROM qr_sessions WHERE active = 1"
            ) or 0
        except Exception:
            total_students = total_teachers = total_records = 0
            today_att = active_sessions = 0
        return [
            ("Total Students", total_students, "#60a5fa"),
            ("Total Teachers", total_teachers, "#34d399"),
            ("Attendance Records", total_records, "#fbbf24"),
            ("Today's Present", today_att, "#2dd4bf"),
            ("Live Sessions", active_sessions, "#a78bfa"),
        ]

    # ── Program attendance bar chart ──────────────────────────────────────────
    def _build_chart(self, parent):
        tk.Label(parent, text="Program Attendance Overview",
                 bg=self.theme["card"], fg=self.theme["text"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")
        try:
            import matplotlib
            matplotlib.use("TkAgg")
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

            rows = self.db.query(
                """SELECT d.name program,
                    COALESCE(ROUND(
                        100.0 * SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)
                        / NULLIF(COUNT(a.id), 0), 1), 0) pct
                FROM departments d
                LEFT JOIN students   s ON s.department_id = d.id
                LEFT JOIN attendance a ON a.student_id    = s.student_id
                GROUP BY d.id ORDER BY pct DESC"""
            )
            if not rows:
                tk.Label(parent, text="No attendance data yet.",
                         bg=self.theme["card"], fg=self.theme["muted"]).pack(pady=14)
                return

            labels = [r["program"].replace("BS ", "") for r in rows]
            values = [float(r["pct"] or 0) for r in rows]
            colors = ["#38bdf8", "#34d399", "#f472b6", "#fbbf24", "#a78bfa"]

            fig, ax = plt.subplots(figsize=(5.2, 3.4), facecolor="#1f2937")
            ax.set_facecolor("#111827")
            bars = ax.bar(labels, values, color=colors[:len(labels)], width=0.55, zorder=3)
            ax.set_ylim(0, 108)
            ax.axhline(75, color="#fb7185", lw=1.2, ls="--", alpha=0.8, label="75% min")
            ax.set_title("Attendance % by Program", color="#e5e7eb", fontsize=9, pad=6)
            ax.tick_params(colors="#94a3b8", labelsize=7)
            ax.set_ylabel("Attendance %", color="#94a3b8", fontsize=7)
            ax.legend(facecolor="#1f2937", labelcolor="#94a3b8", fontsize=7, loc="lower right")
            for spine in ax.spines.values():
                spine.set_color("#334155")
            for bar, val in zip(bars, values):
                ax.text(bar.get_x() + bar.get_width() / 2, val + 0.8,
                        f"{val:.0f}%", ha="center", va="bottom",
                        color="#e5e7eb", fontsize=7)
            fig.tight_layout(pad=1.2)
            canvas = FigureCanvasTkAgg(fig, master=parent)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, pady=(6, 0))
            plt.close(fig)
        except ImportError:
            tk.Label(parent, text="Install matplotlib:\npip install matplotlib",
                     bg=self.theme["card"], fg=self.theme["muted"],
                     justify="left").pack(pady=10)
        except Exception as exc:
            tk.Label(parent, text=f"Chart error:\n{exc}",
                     bg=self.theme["card"], fg=self.theme["muted"],
                     wraplength=280, justify="left").pack(pady=10)

        # ── Semester breakdown mini-table
        tk.Label(parent, text="Attendance by Semester",
                 bg=self.theme["card"], fg=self.theme["text"],
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(12, 4))
        try:
            sem_rows = self.db.query(
                """SELECT s.semester,
                    COUNT(DISTINCT s.student_id) students,
                    ROUND(100.0 * SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)
                        / NULLIF(COUNT(a.id),0), 1) pct
                FROM students s
                LEFT JOIN attendance a ON a.student_id = s.student_id
                GROUP BY s.semester ORDER BY s.semester"""
            )
            sem_tree = ttk.Treeview(parent,
                                    columns=("sem", "students", "attend"),
                                    show="headings", height=4)
            for col, w, txt in [("sem", 70, "Semester"), ("students", 80, "Students"), ("attend", 100, "Attendance %")]:
                sem_tree.heading(col, text=txt)
                sem_tree.column(col, width=w, anchor="center")
            for r in sem_rows:
                pct = r["pct"] or 0
                flag = "✓" if pct >= 75 else "⚠"
                sem_tree.insert("", "end", values=(f"Sem {r['semester']}", r["students"], f"{pct:.1f}% {flag}"))
            sem_tree.pack(fill="x")
        except Exception:
            pass

    # ── Top-absent summary table ──────────────────────────────────────────────
    def _build_summary(self, parent):
        tk.Label(parent, text="Program Summary",
                 bg=self.theme["card"], fg=self.theme["text"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")
        tk.Label(parent, text="Attendance % per program — auto-refreshes every 5s",
                 bg=self.theme["card"], fg=self.theme["muted"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 8))

        self._summary_tree = ttk.Treeview(
            parent,
            columns=("program", "students", "pct"),
            show="headings", height=6,
        )
        for col, w, txt in [("program", 220, "Program"), ("students", 95, "Students"),
                            ("pct", 110, "Attendance %")]:
            self._summary_tree.heading(col, text=txt)
            self._summary_tree.column(col, width=w, anchor="center")
        self._summary_tree.pack(fill="x", pady=(0, 10))
        self._summary_tree.tag_configure("bad", foreground="#fb7185")
        self._summary_tree.tag_configure("good", foreground="#34d399")

        # Recent method breakdown
        tk.Label(parent, text="Attendance by Method (All Time)",
                 bg=self.theme["card"], fg=self.theme["text"],
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(4, 6))
        self._method_tree = ttk.Treeview(
            parent,
            columns=("method", "count", "pct"),
            show="headings", height=4,
        )
        for col, w, txt in [("method", 120, "Method"), ("count", 100, "Records"),
                            ("pct", 100, "Share %")]:
            self._method_tree.heading(col, text=txt)
            self._method_tree.column(col, width=w, anchor="center")
        self._method_tree.pack(fill="x")

        # Quick info label
        self._info_lbl = tk.Label(
            parent, text="",
            bg=self.theme["card"], fg=self.theme["muted"],
            font=("Segoe UI", 9), justify="left",
        )
        self._info_lbl.pack(anchor="w", pady=(10, 0))
        self._reload_summary()

    def _reload_summary(self):
        if not self._alive:
            return
        try:
            # Program breakdown
            self._summary_tree.delete(*self._summary_tree.get_children())
            rows = self.db.query(
                """SELECT d.name program,
                       COUNT(DISTINCT s.student_id) students,
                       ROUND(100.0 * SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)
                           / NULLIF(COUNT(a.id), 0), 1) pct
                FROM departments d
                LEFT JOIN students s ON s.department_id = d.id
                LEFT JOIN attendance a ON a.student_id = s.student_id
                GROUP BY d.id ORDER BY pct DESC"""
            )
            for r in rows:
                pct = float(r["pct"] or 0)
                tag = "bad" if pct < 75 else "good"
                self._summary_tree.insert("", "end",
                                          values=(r["program"], r["students"],
                                                  f"{pct:.1f}%"),
                                          tags=(tag,))

            # Method breakdown
            self._method_tree.delete(*self._method_tree.get_children())
            total = self.db.scalar("SELECT COUNT(*) FROM attendance") or 1
            for method in ("Face", "QR", "Manual", "Hybrid"):
                cnt = self.db.scalar(
                    "SELECT COUNT(*) FROM attendance WHERE method=?", (method,)
                ) or 0
                pct = round(cnt / total * 100, 1) if total else 0.0
                self._method_tree.insert("", "end",
                                         values=(method, cnt, f"{pct:.1f}%"))

            # Info line
            today = self.db.scalar(
                "SELECT COUNT(*) FROM attendance WHERE date = date('now','localtime')"
            ) or 0
            self._info_lbl.config(text=f"Today's records: {today}  |  "
                                  f"Total records: {total}  (refreshes every 5s)")
        except Exception:
            pass
