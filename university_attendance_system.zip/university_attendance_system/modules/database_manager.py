"""SQLite data layer for the University Attendance System."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import random
import re
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
import threading
from typing import Any, Iterable


ROOT_DIR = Path(__file__).resolve().parents[1]
DB_PATH = ROOT_DIR / "database" / "university.db"


DEPARTMENTS = [
    ("CS", "BS Computer Science"),
    ("DS", "BS Data Science"),
    ("IT", "BS Information Technology"),
    ("AI", "BS Artificial Intelligence"),
    ("CSEC", "BS Cyber Security"),
]

COURSES = [
    ("CS-101", "Programming Fundamentals", 4, "CS"),
    ("CS-204", "Data Structures & Algorithms", 4, "CS"),
    ("CS-306", "Operating Systems", 3, "CS"),
    ("CS-408", "Software Engineering", 3, "CS"),
    ("DS-201", "Statistics for Data Science", 3, "DS"),
    ("DS-302", "Machine Learning", 3, "DS"),
    ("DS-404", "Deep Learning", 3, "DS"),
    ("DS-406", "Big Data Analytics", 3, "DS"),
    ("IT-202", "Network Administration", 3, "IT"),
    ("IT-304", "Cloud Computing", 3, "IT"),
    ("IT-406", "Database Management Systems", 3, "IT"),
    ("AI-301", "Artificial Intelligence", 3, "AI"),
    ("AI-402", "Computer Vision", 3, "AI"),
    ("AI-504", "Natural Language Processing", 3, "AI"),
    ("CSEC-201", "Cyber Security Fundamentals", 3, "CSEC"),
    ("CSEC-303", "Ethical Hacking", 3, "CSEC"),
    ("CSEC-405", "Network Security", 3, "CSEC"),
    ("CSEC-507", "Digital Forensics", 3, "CSEC"),
]

SCHEMA_VERSION = "v3"


class DatabaseManager:
    """Owns schema creation, authentication, sample data, and safe queries."""

    def __init__(self, db_path: Path | str = DB_PATH) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = self._load_or_create_secret()
        self.initialize()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _load_or_create_secret(self) -> str:
        path = ROOT_DIR / "database" / ".secret"
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            return path.read_text(encoding="utf-8").strip()
        secret = secrets.token_urlsafe(48)
        path.write_text(secret, encoding="utf-8")
        return secret

    def initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('Admin','Teacher','Student')),
                    linked_id TEXT,
                    full_name TEXT NOT NULL,
                    remember_token TEXT,
                    face_registered INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS departments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT UNIQUE NOT NULL,
                    name TEXT UNIQUE NOT NULL
                );

                CREATE TABLE IF NOT EXISTS students (
                    student_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    father_name TEXT,
                    department_id INTEGER NOT NULL REFERENCES departments(id),
                    program TEXT,
                    semester INTEGER NOT NULL CHECK(semester IN (2,4,6,8)),
                    session TEXT,
                    roll_number INTEGER,
                    section TEXT NOT NULL,
                    phone TEXT,
                    email TEXT UNIQUE,
                    address TEXT,
                    photo_path TEXT,
                    qr_code_path TEXT,
                    attendance_percentage REAL DEFAULT 0.0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS teachers (
                    teacher_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    department_id INTEGER REFERENCES departments(id),
                    course_code TEXT,
                    program TEXT,
                    phone TEXT,
                    email TEXT UNIQUE,
                    designation TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS courses (
                    course_id TEXT PRIMARY KEY,
                    subject_name TEXT NOT NULL,
                    department_id INTEGER REFERENCES departments(id),
                    semester INTEGER NOT NULL CHECK(semester BETWEEN 1 AND 8),
                    section TEXT NOT NULL,
                    credit_hours INTEGER NOT NULL,
                    teacher_id TEXT REFERENCES teachers(teacher_id)
                );

                CREATE TABLE IF NOT EXISTS subjects (
                    subject_id TEXT PRIMARY KEY,
                    subject_name TEXT NOT NULL,
                    department_id INTEGER REFERENCES departments(id),
                    credit_hours INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS timetable (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    course_id TEXT REFERENCES courses(course_id),
                    teacher_id TEXT REFERENCES teachers(teacher_id),
                    weekday TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT NOT NULL,
                    room TEXT
                );

                CREATE TABLE IF NOT EXISTS attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL REFERENCES students(student_id),
                    course_id TEXT NOT NULL REFERENCES courses(course_id),
                    date TEXT NOT NULL,
                    time TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late','Excused')),
                    method TEXT NOT NULL CHECK(method IN ('QR','Face','Manual','Hybrid')),
                    session_token TEXT,
                    confidence REAL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(student_id, course_id, date)
                );

                CREATE TABLE IF NOT EXISTS qr_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE,
                    course_id TEXT NOT NULL REFERENCES courses(course_id),
                    teacher_id TEXT REFERENCES teachers(teacher_id),
                    semester INTEGER NOT NULL,
                    section TEXT NOT NULL,
                    token_hash TEXT UNIQUE NOT NULL,
                    payload TEXT NOT NULL,
                    starts_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    active INTEGER DEFAULT 1
                );

                CREATE TABLE IF NOT EXISTS face_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    owner_type TEXT NOT NULL,
                    owner_id TEXT NOT NULL,
                    feature_json TEXT NOT NULL,
                    image_path TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(owner_type, owner_id)
                );

                CREATE TABLE IF NOT EXISTS face_attempts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT,
                    course_id TEXT,
                    matched INTEGER NOT NULL,
                    confidence REAL,
                    reason TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS mobile_devices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL REFERENCES students(student_id),
                    student_name TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    ip_address TEXT,
                    user_agent TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(student_id, device_id)
                );

                CREATE TABLE IF NOT EXISTS spoofing_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT,
                    student_name TEXT,
                    course_id TEXT,
                    session_id TEXT,
                    camera_source TEXT,
                    real_confidence REAL,
                    fake_confidence REAL,
                    attack_type TEXT,
                    screenshot_path TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS liveness_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT,
                    student_name TEXT,
                    course_id TEXT,
                    session_id TEXT,
                    camera_source TEXT,
                    real_confidence REAL,
                    fake_confidence REAL,
                    challenge_type TEXT,
                    challenge_result TEXT,
                    recognition_confidence REAL,
                    final_decision TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS security_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    student_id TEXT,
                    course_id TEXT,
                    session_id TEXT,
                    failure_reason TEXT,
                    screenshot_path TEXT,
                    camera_source TEXT,
                    device_info TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                """
            )
        self.migrate()
        # Run heavy data seeding in background so UI stays responsive
        t = threading.Thread(target=self.ensure_demo_data, daemon=True)
        t.start()

    def migrate(self) -> None:
        """Apply lightweight migrations for databases created by earlier builds."""
        with self.connect() as conn:
            existing = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "settings" not in existing:
                conn.execute("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            if "subjects" not in existing:
                conn.execute(
                    """
                    CREATE TABLE subjects (
                        subject_id TEXT PRIMARY KEY,
                        subject_name TEXT NOT NULL,
                        department_id INTEGER REFERENCES departments(id),
                        credit_hours INTEGER NOT NULL
                    )
                    """
                )
            # attendance columns
            columns = {r["name"] for r in conn.execute("PRAGMA table_info(attendance)")}
            for col_def in [
                ("student_name", "TEXT"),
                ("course_name", "TEXT"),
                ("session_id", "TEXT"),
                ("department", "TEXT"),
                ("semester", "INTEGER"),
                ("subject", "TEXT"),
            ]:
                if col_def[0] not in columns:
                    conn.execute(f"ALTER TABLE attendance ADD COLUMN {col_def[0]} {col_def[1]}")

            # students new columns
            s_cols = {r["name"] for r in conn.execute("PRAGMA table_info(students)")}
            for col, typ in [("program", "TEXT"), ("session", "TEXT"), ("roll_number", "INTEGER"), ("attendance_percentage", "REAL DEFAULT 0.0")]:
                if col not in s_cols:
                    conn.execute(f"ALTER TABLE students ADD COLUMN {col} {typ}")

            # teachers new columns
            t_cols = {r["name"] for r in conn.execute("PRAGMA table_info(teachers)")}
            for col, typ in [("course_code", "TEXT"), ("program", "TEXT")]:
                if col not in t_cols:
                    conn.execute(f"ALTER TABLE teachers ADD COLUMN {col} {typ}")

            # qr_sessions session_id
            qr_columns = {r["name"] for r in conn.execute("PRAGMA table_info(qr_sessions)")}
            if "session_id" not in qr_columns:
                conn.execute("ALTER TABLE qr_sessions ADD COLUMN session_id TEXT")
                conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_qr_sessions_session_id ON qr_sessions(session_id)")

            # default settings
            defaults = [
                ("university_name", "University Attendance System"),
                ("theme", "dark"),
                ("camera_index", "0"),
                ("qr_expiry_seconds", "300"),
                ("face_threshold", "72"),
                ("passive_liveness_threshold", "80"),
                ("admin_full_name", "System Administrator"),
                ("schema_version", ""),
            ]
            for k, v in defaults:
                conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v))

            # update departments to BS programs
            for code, name in DEPARTMENTS:
                conn.execute("INSERT OR IGNORE INTO departments(code, name) VALUES (?, ?)", (code, name))
                conn.execute("UPDATE departments SET name=? WHERE code=?", (name, code))

            dept_ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM departments")}
            for cid, subject, credits, code in COURSES:
                if code in dept_ids:
                    conn.execute(
                        "INSERT OR IGNORE INTO subjects(subject_id, subject_name, department_id, credit_hours) VALUES (?, ?, ?, ?)",
                        (cid, subject, dept_ids[code], credits),
                    )

            # ensure only admin + teacher accounts (no student logins)
            conn.execute("DELETE FROM users WHERE role='Student'")
            conn.execute(
                "INSERT OR IGNORE INTO users(username, password_hash, role, linked_id, full_name) VALUES (?, ?, 'Admin', NULL, ?)",
                ("admin", self.hash_password("admin123"), "System Administrator"),
            )
            conn.execute(
                "INSERT OR IGNORE INTO users(username, password_hash, role, linked_id, full_name) VALUES (?, ?, 'Teacher', NULL, ?)",
                ("teacher", self.hash_password("teacher123"), "Teacher Account"),
            )

    @staticmethod
    def hash_password(password: str, salt: str | None = None) -> str:
        salt = salt or secrets.token_hex(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
        return f"pbkdf2_sha256${salt}${digest.hex()}"

    @classmethod
    def verify_password(cls, password: str, stored: str) -> bool:
        try:
            _, salt, digest = stored.split("$", 2)
        except ValueError:
            return False
        return hmac.compare_digest(cls.hash_password(password, salt), stored)

    def sign_payload(self, payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
        sig = hmac.new(self.secret.encode(), raw, hashlib.sha256).digest()
        envelope = {
            "payload": base64.urlsafe_b64encode(raw).decode(),
            "sig": base64.urlsafe_b64encode(sig).decode(),
        }
        return base64.urlsafe_b64encode(json.dumps(envelope, separators=(",", ":")).encode()).decode()

    def verify_payload(self, token: str) -> dict[str, Any]:
        envelope = json.loads(base64.urlsafe_b64decode(token.encode()).decode())
        payload_raw = base64.urlsafe_b64decode(envelope["payload"].encode())
        sig = base64.urlsafe_b64decode(envelope["sig"].encode())
        expected = hmac.new(self.secret.encode(), payload_raw, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, expected):
            raise ValueError("QR signature is invalid.")
        return json.loads(payload_raw.decode())

    def token_hash(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return conn.execute(sql, tuple(params)).fetchall()

    def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        with self.connect() as conn:
            cur = conn.execute(sql, tuple(params))
            return cur.lastrowid

    def scalar(self, sql: str, params: Iterable[Any] = ()) -> Any:
        rows = self.query(sql, params)
        return rows[0][0] if rows else None

    def delete_teacher(self, teacher_id: str) -> dict[str, int]:
        """Delete a single teacher and all data belonging to that individual.

        Removes the teacher's QR sessions and timetable rows, clears the
        teacher reference on any courses they owned (so the courses and their
        attendance history survive but are no longer attributed to the deleted
        teacher), removes the linked Teacher login account, and finally the
        teacher record itself. Returns a count of what was removed so the UI
        can report it. All steps run in one transaction.
        """
        removed = {"qr_sessions": 0, "timetable": 0, "courses_unlinked": 0,
                   "user_accounts": 0, "teacher": 0}
        with self.connect() as conn:
            removed["qr_sessions"] = conn.execute(
                "DELETE FROM qr_sessions WHERE teacher_id=?", (teacher_id,)
            ).rowcount
            removed["timetable"] = conn.execute(
                "DELETE FROM timetable WHERE teacher_id=?", (teacher_id,)
            ).rowcount
            removed["courses_unlinked"] = conn.execute(
                "UPDATE courses SET teacher_id=NULL WHERE teacher_id=?", (teacher_id,)
            ).rowcount
            removed["user_accounts"] = conn.execute(
                "DELETE FROM users WHERE role='Teacher' AND linked_id=?", (teacher_id,)
            ).rowcount
            removed["teacher"] = conn.execute(
                "DELETE FROM teachers WHERE teacher_id=?", (teacher_id,)
            ).rowcount
        return removed

    def authenticate(self, username: str, password: str) -> sqlite3.Row | None:
        rows = self.query("SELECT * FROM users WHERE username = ?", (username.strip(),))
        if rows and self.verify_password(password, rows[0]["password_hash"]):
            return rows[0]
        return None

    def remember_user(self, user_id: int) -> str:
        token = secrets.token_urlsafe(32)
        self.execute("UPDATE users SET remember_token = ? WHERE id = ?", (token, user_id))
        return token

    def get_remembered_user(self, token: str) -> sqlite3.Row | None:
        rows = self.query("SELECT * FROM users WHERE remember_token = ?", (token,))
        return rows[0] if rows else None

    def next_student_id(self, department_code: str) -> str:
        year = datetime.now().year
        prefix = f"{department_code.upper()}-{year}-"
        n = (self.scalar("SELECT COUNT(*) FROM students WHERE student_id LIKE ?", (prefix + "%",)) or 0) + 1
        return f"{prefix}{n:04d}"

    def add_student(self, data: dict[str, Any], update: bool = False) -> tuple[bool, str]:
        """Create or update a student with validation and duplicate protection."""
        required = ["student_id", "name", "department_id", "semester", "section"]
        missing = [field for field in required if not str(data.get(field, "")).strip()]
        if missing:
            return False, f"Missing required fields: {', '.join(missing)}"
        sid = data["student_id"].strip().upper()
        if not re.fullmatch(r"[A-Z0-9-]{4,30}", sid):
            return False, "Student ID may contain only letters, numbers, and hyphens."
        email = data.get("email", "").strip()
        if email and ("@" not in email or "." not in email.rsplit("@", 1)[-1]):
            return False, "Enter a valid email address."
        phone = data.get("phone", "").strip()
        if phone and not re.fullmatch(r"[0-9+\-\s]{7,18}", phone):
            return False, "Enter a valid phone number."
        semester = int(data["semester"])
        if semester not in (2, 4, 6, 8):
            return False, "Semester must be 2, 4, 6, or 8."
        exists = self.scalar("SELECT COUNT(*) FROM students WHERE student_id = ?", (sid,)) or 0
        if exists and not update:
            return False, f"Student ID {sid} already exists."
        if update and not exists:
            return False, f"Student ID {sid} was not found for update."
        email_owner = self.scalar("SELECT student_id FROM students WHERE email = ? AND email <> ''", (email,)) if email else None
        if email_owner and email_owner != sid:
            return False, f"Email is already used by {email_owner}."
        roll = data.get("roll_number", None)
        try:
            roll = int(roll) if roll else None
        except (ValueError, TypeError):
            roll = None
        try:
            if update:
                self.execute(
                    """
                    UPDATE students SET name=?, father_name=?, department_id=?, program=?, semester=?, session=?,
                    roll_number=?, section=?, phone=?, email=?, address=?, photo_path=?, qr_code_path=? WHERE student_id=?
                    """,
                    (
                        data["name"].strip(),
                        data.get("father_name", "").strip(),
                        int(data["department_id"]),
                        data.get("program", "").strip(),
                        semester,
                        data.get("session", "").strip(),
                        roll,
                        data["section"].strip().upper(),
                        phone,
                        email,
                        data.get("address", "").strip(),
                        data.get("photo_path", "").strip(),
                        data.get("qr_code_path", "").strip(),
                        sid,
                    ),
                )
                return True, f"Student {sid} updated successfully."
            self.execute(
                """
                INSERT INTO students(student_id, name, father_name, department_id, program, semester, session,
                roll_number, section, phone, email, address, photo_path, qr_code_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sid,
                    data["name"].strip(),
                    data.get("father_name", "").strip(),
                    int(data["department_id"]),
                    data.get("program", "").strip(),
                    semester,
                    data.get("session", "").strip(),
                    roll,
                    data["section"].strip().upper(),
                    phone,
                    email,
                    data.get("address", "").strip(),
                    data.get("photo_path", "").strip(),
                    data.get("qr_code_path", "").strip(),
                ),
            )
            return True, f"Student {sid} added successfully."
        except sqlite3.IntegrityError as exc:
            return False, f"Database rejected duplicate or invalid data: {exc}"

    def mark_attendance(
        self,
        student_id: str,
        course_id: str,
        status: str = "Present",
        method: str = "Manual",
        token: str | None = None,
        confidence: float | None = None,
        session_id: str | None = None,
        date: str | None = None,
    ) -> tuple[bool, str]:
        """Insert or update an attendance record.

        ``date`` defaults to today when omitted. Always pass the UI-selected
        date for manual attendance so past/future records save correctly.
        Catches both IntegrityError (duplicate) and OperationalError (schema
        issues on legacy DBs that pre-date the extra columns) so callers
        always receive a (bool, str) tuple rather than an uncaught exception.
        """
        now = datetime.now()
        record_date = date if date else now.date().isoformat()
        record_time = now.strftime("%H:%M:%S")
        try:
            info = self.query(
                """
                SELECT s.name student_name, s.semester, d.name department, c.subject_name course_name
                FROM students s
                LEFT JOIN departments d ON d.id=s.department_id
                LEFT JOIN courses c ON c.course_id=?
                WHERE s.student_id=?
                """,
                (course_id, student_id),
            )
            student_name = info[0]["student_name"] if info else ""
            course_name  = info[0]["course_name"]  if info else ""
            department   = info[0]["department"]   if info else ""
            semester     = info[0]["semester"]     if info else None
        except Exception:
            student_name = course_name = department = ""
            semester = None
        # Use an UPSERT so repeated saves (e.g. re-clicking Save) update the
        # status rather than failing on the UNIQUE(student_id, course_id, date)
        # constraint.  This replaces the old DELETE + INSERT pattern that had a
        # race window and broke when extra columns were absent.
        try:
            self.execute(
                """
                INSERT INTO attendance(
                    student_id, course_id, date, time, status, method,
                    session_token, confidence,
                    student_name, course_name, session_id,
                    department, semester, subject
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(student_id, course_id, date)
                DO UPDATE SET
                    status=excluded.status,
                    time=excluded.time,
                    method=excluded.method,
                    session_token=COALESCE(excluded.session_token, session_token),
                    confidence=COALESCE(excluded.confidence, confidence),
                    student_name=COALESCE(excluded.student_name, student_name),
                    course_name=COALESCE(excluded.course_name, course_name),
                    session_id=COALESCE(excluded.session_id, session_id),
                    department=COALESCE(excluded.department, department),
                    semester=COALESCE(excluded.semester, semester),
                    subject=COALESCE(excluded.subject, subject)
                """,
                (
                    student_id, course_id, record_date, record_time,
                    status, method, token, confidence,
                    student_name, course_name, session_id,
                    department, semester, course_name,
                ),
            )
            return True, "Attendance marked."
        except sqlite3.OperationalError as exc:
            # Likely a legacy DB missing the extra columns — fall back to a
            # minimal insert that only uses the base schema columns.
            try:
                self.execute(
                    """
                    INSERT INTO attendance(student_id, course_id, date, time, status, method,
                                          session_token, confidence)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(student_id, course_id, date)
                    DO UPDATE SET status=excluded.status, time=excluded.time,
                                  method=excluded.method
                    """,
                    (student_id, course_id, record_date, record_time,
                     status, method, token, confidence),
                )
                return True, "Attendance marked (legacy schema)."
            except sqlite3.IntegrityError:
                return False, "Attendance already exists for this student, course, and date."
            except Exception as exc2:
                return False, str(exc2)
        except sqlite3.IntegrityError:
            return False, "Attendance already exists for this student, course, and date."
        except Exception as exc:
            return False, str(exc)

    def log_liveness(
        self,
        student_id: str | None,
        course_id: str | None,
        session_id: str | None,
        camera_source: str,
        real_confidence: float,
        fake_confidence: float,
        challenge_type: str,
        challenge_result: str,
        recognition_confidence: float | None,
        final_decision: str,
    ) -> None:
        student_name = self.scalar("SELECT name FROM students WHERE student_id=?", (student_id,)) if student_id else None
        self.execute(
            """
            INSERT INTO liveness_logs(student_id, student_name, course_id, session_id, camera_source, real_confidence,
            fake_confidence, challenge_type, challenge_result, recognition_confidence, final_decision)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (student_id, student_name, course_id, session_id, camera_source, real_confidence, fake_confidence, challenge_type, challenge_result, recognition_confidence, final_decision),
        )

    def log_security_event(
        self,
        event_type: str,
        student_id: str | None = None,
        course_id: str | None = None,
        session_id: str | None = None,
        failure_reason: str = "",
        screenshot_path: str = "",
        camera_source: str = "webcam",
        device_info: str = "",
        real_confidence: float | None = None,
        fake_confidence: float | None = None,
    ) -> None:
        self.execute(
            """
            INSERT INTO security_events(event_type, student_id, course_id, session_id, failure_reason, screenshot_path, camera_source, device_info)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (event_type, student_id, course_id, session_id, failure_reason, screenshot_path, camera_source, device_info),
        )
        if event_type in {"PHOTO_ATTACK", "VIDEO_REPLAY_ATTACK", "FAKE_FACE_DETECTED", "SCREEN_ATTACK"}:
            student_name = self.scalar("SELECT name FROM students WHERE student_id=?", (student_id,)) if student_id else None
            self.execute(
                """
                INSERT INTO spoofing_logs(student_id, student_name, course_id, session_id, camera_source, real_confidence, fake_confidence, attack_type, screenshot_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (student_id, student_name, course_id, session_id, camera_source, real_confidence, fake_confidence, event_type, screenshot_path),
            )

    def create_qr_session(self, course_id: str, teacher_id: str, expiry_seconds: int = 30) -> tuple[str, dict[str, Any]]:
        db_teacher_id = teacher_id if self.scalar("SELECT COUNT(*) FROM teachers WHERE teacher_id = ?", (teacher_id,)) else None
        course = self.query(
            """
            SELECT c.*, t.name teacher_name FROM courses c
            LEFT JOIN teachers t ON t.teacher_id = c.teacher_id
            WHERE c.course_id = ?
            """,
            (course_id,),
        )[0]
        now = datetime.now()
        nonce = secrets.token_urlsafe(18)
        public_session_id = secrets.token_urlsafe(6).replace("-", "").replace("_", "")[:10].upper()
        payload = {
            "session_id": public_session_id,
            "course": course["course_id"],
            "course_id": course["course_id"],
            "subject": course["subject_name"],
            "teacher": course["teacher_name"] or teacher_id,
            "teacher_id": db_teacher_id or teacher_id,
            "semester": course["semester"],
            "section": course["section"],
            "timestamp": now.isoformat(timespec="seconds"),
            "expiry": expiry_seconds,
            "token": nonce,
        }
        signed = self.sign_payload(payload)
        self.execute("UPDATE qr_sessions SET active = 0 WHERE course_id = ? AND active = 1", (course_id,))
        self.execute(
            """
            INSERT INTO qr_sessions(session_id, course_id, teacher_id, semester, section, token_hash, payload, starts_at, expires_at, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            """,
            (
                public_session_id,
                course_id,
                db_teacher_id,
                course["semester"],
                course["section"],
                self.token_hash(signed),
                json.dumps(payload),
                now.isoformat(timespec="seconds"),
                (now + timedelta(seconds=expiry_seconds)).isoformat(timespec="seconds"),
            ),
        )
        return signed, payload

    def create_student_qr_verification(
        self,
        student_id: str,
        course_id: str,
        session_id: str,
        expiry_seconds: int = 30,
    ) -> tuple[str, dict[str, Any]]:
        student = self.query("SELECT name FROM students WHERE student_id=?", (student_id,))
        course = self.query("SELECT subject_name FROM courses WHERE course_id=?", (course_id,))
        if not student or not course:
            raise ValueError("Student or course not found.")
        now = datetime.now()
        payload = {
            "type": "student_face_qr_verification",
            "student_id": student_id,
            "student_name": student[0]["name"],
            "course_id": course_id,
            "subject": course[0]["subject_name"],
            "session_id": session_id,
            "timestamp": now.isoformat(timespec="seconds"),
            "expiry": expiry_seconds,
            "token": secrets.token_urlsafe(18),
        }
        return self.sign_payload(payload), payload

    def validate_qr_session(self, signed_token: str, student_id: str) -> tuple[bool, str, str | None]:
        try:
            payload = self.verify_payload(signed_token)
        except Exception as exc:
            return False, str(exc), None
        rows = self.query("SELECT * FROM qr_sessions WHERE token_hash = ? AND active = 1", (self.token_hash(signed_token),))
        if not rows:
            return False, "QR session is not active.", None
        session = rows[0]
        if datetime.fromisoformat(session["expires_at"]) < datetime.now():
            self.execute("UPDATE qr_sessions SET active = 0 WHERE id = ?", (session["id"],))
            return False, "QR code expired.", None
        student = self.query("SELECT semester, section FROM students WHERE student_id = ?", (student_id,))
        if not student:
            return False, "Student ID was not found.", None
        if student[0]["semester"] != payload["semester"] or student[0]["section"] != payload["section"]:
            return False, "This QR is for another semester or section.", None
        return True, "QR verified.", payload["course"]

    def validate_qr_by_session_id(self, session_id: str, student_id: str) -> tuple[bool, str, str | None]:
        """Validate attendance using the short public session_id encoded in the QR.

        Only checks that the session exists, is active, and has not expired.
        The strict semester/section equality check was removed because it
        frequently blocked legitimate students when course or student records
        were slightly out of sync (e.g. the student is enrolled but their
        semester field doesn't exactly match the course's semester value).
        Security is maintained by requiring the student to be physically
        present to scan the QR shown by the teacher.
        """
        session_id = (session_id or "").strip()
        student_id = (student_id or "").strip().upper()
        rows = self.query(
            "SELECT * FROM qr_sessions WHERE session_id = ? AND active = 1",
            (session_id,),
        )
        if not rows:
            return False, "QR session not found. Make sure you scan the QR your teacher is showing right now.", None
        session = rows[0]
        if datetime.fromisoformat(session["expires_at"]) < datetime.now():
            self.execute("UPDATE qr_sessions SET active = 0 WHERE id = ?", (session["id"],))
            return False, "QR code has expired. Ask your teacher to generate a new one.", None
        student = self.query(
            "SELECT student_id FROM students WHERE student_id = ?",
            (student_id,),
        )
        if not student:
            return False, f"Student ID '{student_id}' not found in the system. Check your Roll Number.", None
        return True, "QR verified.", session["course_id"]

    def register_mobile_device(self, student_id: str, name: str, device_id: str, ip_address: str, user_agent: str) -> tuple[bool, str]:
        student = self.query("SELECT name FROM students WHERE student_id = ?", (student_id.strip().upper(),))
        if not student:
            return False, "Student ID was not found."
        if name.strip() and name.strip().lower() not in student[0]["name"].lower():
            return False, "Student name does not match university records."
        self.execute(
            """
            INSERT INTO mobile_devices(student_id, student_name, device_id, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(student_id, device_id) DO UPDATE SET ip_address=excluded.ip_address, user_agent=excluded.user_agent
            """,
            (student_id.strip().upper(), student[0]["name"], device_id, ip_address, user_agent[:300]),
        )
        return True, f"Registered {student[0]['name']}."

    def mark_mobile_qr_attendance(self, student_id: str, signed_token: str, device_id: str, ip_address: str) -> tuple[bool, str]:
        if not self.query("SELECT 1 FROM mobile_devices WHERE student_id=? AND device_id=?", (student_id.strip().upper(), device_id)):
            return False, "Mobile device is not registered for this student."
        try:
            payload = self.verify_payload(signed_token)
            if payload.get("type") == "student_face_qr_verification":
                if payload.get("student_id") != student_id.strip().upper():
                    return False, "This QR belongs to another student."
                created = datetime.fromisoformat(payload["timestamp"])
                if created + timedelta(seconds=int(payload.get("expiry", 30))) < datetime.now():
                    return False, "Student verification QR expired."
                marked, mark_msg = self.mark_attendance(
                    student_id.strip().upper(),
                    payload["course_id"],
                    "Present",
                    "Hybrid",
                    token=signed_token,
                    session_id=payload.get("session_id"),
                )
                return (True, f"{mark_msg} Course: {payload['course_id']}. IP: {ip_address}") if marked else (False, mark_msg)
        except Exception:
            pass
        ok, msg, course_id = self.validate_qr_session(signed_token, student_id.strip().upper())
        if not ok or not course_id:
            return False, msg
        payload = self.verify_payload(signed_token)
        marked, mark_msg = self.mark_attendance(
            student_id.strip().upper(),
            course_id,
            "Present",
            "QR",
            token=signed_token,
            session_id=payload.get("session_id"),
        )
        if marked:
            return True, f"{mark_msg} Course: {course_id}. IP: {ip_address}"
        return False, mark_msg

    def ensure_demo_data(self) -> None:
        """Seed database with 1000 students, 50 teachers, 6-month attendance. Re-seeds when schema version changes."""
        current_ver = self.scalar("SELECT value FROM settings WHERE key='schema_version'") or ""
        student_cnt = self.scalar("SELECT COUNT(*) FROM students") or 0
        teacher_cnt = self.scalar("SELECT COUNT(*) FROM teachers") or 0
        if current_ver == SCHEMA_VERSION and student_cnt >= 1000 and teacher_cnt >= 50:
            return

        with self.connect() as conn:
            # clear old data
            for tbl in ["attendance", "students", "teachers", "courses", "timetable",
                        "qr_sessions", "face_data"]:
                conn.execute(f"DELETE FROM {tbl}")
            conn.execute("DELETE FROM users WHERE role IN ('Teacher','Student')")

            for code, prog in DEPARTMENTS:
                conn.execute("INSERT OR IGNORE INTO departments(code, name) VALUES (?, ?)", (code, prog))
                conn.execute("UPDATE departments SET name=? WHERE code=?", (prog, code))

            dept_ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM departments")}
            prog_names = {r["code"]: r["name"] for r in conn.execute("SELECT id, code, name FROM departments")}

            # 50 teachers
            first_n = ["Ali", "Ayesha", "Hassan", "Fatima", "Usman", "Sana", "Zain", "Mariam", "Bilal", "Hira",
                       "Kamran", "Nadia", "Tariq", "Samina", "Asad", "Razia", "Naveed", "Aroha", "Irfan", "Shabana"]
            last_n = ["Khan", "Malik", "Sheikh", "Raza", "Ahmed", "Iqbal", "Butt", "Qureshi", "Nawaz", "Akhtar"]
            desigs = ["Lecturer", "Assistant Professor", "Associate Professor", "Professor"]
            teachers = []
            dept_codes = [c for c, _ in DEPARTMENTS]
            for idx in range(1, 51):
                code = dept_codes[(idx - 1) % len(dept_codes)]
                tid = f"T-{code}-{idx:03d}"
                teachers.append(tid)
                full = f"Dr. {first_n[idx % len(first_n)]} {last_n[idx % len(last_n)]}"
                prog = prog_names.get(code, code)
                dept_crs = [cid for cid, _, _, dc in COURSES if dc == code]
                ccod = dept_crs[(idx - 1) % max(1, len(dept_crs))] if dept_crs else ""
                conn.execute(
                    "INSERT OR IGNORE INTO teachers(teacher_id,name,department_id,course_code,program,phone,email,designation) VALUES (?,?,?,?,?,?,?,?)",
                    (tid, full, dept_ids[code], ccod, prog, f"030{idx:09d}",
                     f"teacher{idx}.{code.lower()}@cs.edu.pk", desigs[idx % len(desigs)]),
                )
                conn.execute(
                    "INSERT OR IGNORE INTO users(username,password_hash,role,linked_id,full_name) VALUES (?,?,'Teacher',?,?)",
                    (f"teacher{idx}", self.hash_password("teacher123"), tid, full),
                )

            # courses – semesters 2/4/6/8 only
            valid_sems = [2, 4, 6, 8]
            for i, (cid, subject, credits, code) in enumerate(COURSES):
                if code in dept_ids:
                    sem = valid_sems[i % len(valid_sems)]
                    conn.execute(
                        "INSERT OR IGNORE INTO courses(course_id,subject_name,department_id,semester,section,credit_hours,teacher_id) VALUES (?,?,?,?,?,?,?)",
                        (cid, subject, dept_ids[code], sem, ["A", "B"][i % 2], credits,
                         self._existing_teacher_id(conn, teachers[i % max(1, len(teachers))])),
                    )
                    conn.execute(
                        "INSERT OR IGNORE INTO timetable(course_id,teacher_id,weekday,start_time,end_time,room) VALUES (?,?,?,?,?,?)",
                        (cid, self._existing_teacher_id(conn, teachers[i % max(1, len(teachers))]),
                         ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"][i % 5],
                         f"{8 + (i % 5):02d}:00", f"{9 + (i % 5):02d}:00", f"CS-{100 + i}"),
                    )

            conn.execute(
                "INSERT OR IGNORE INTO users(username,password_hash,role,linked_id,full_name) VALUES (?,?,'Admin',NULL,?)",
                ("admin", self.hash_password("admin123"), "System Administrator"),
            )
            t0 = self._existing_teacher_id(conn, teachers[0]) if teachers else None
            conn.execute(
                "INSERT OR IGNORE INTO users(username,password_hash,role,linked_id,full_name) VALUES (?,?,'Teacher',?,?)",
                ("teacher", self.hash_password("teacher123"), t0, "Teacher Account"),
            )

        self.generate_students(1000)
        self.generate_attendance_sample()
        self.execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('schema_version',?)", (SCHEMA_VERSION,))

    @staticmethod
    def _existing_teacher_id(conn: sqlite3.Connection, preferred: str) -> str | None:
        row = conn.execute("SELECT teacher_id FROM teachers WHERE teacher_id = ?", (preferred,)).fetchone()
        if row:
            return row["teacher_id"]
        row = conn.execute("SELECT teacher_id FROM teachers ORDER BY teacher_id LIMIT 1").fetchone()
        return row["teacher_id"] if row else None

    def generate_students(self, count: int = 1000) -> None:
        """Generate realistic CS department students with semesters 2/4/6/8 only."""
        first = ["Ayesha", "Ali", "Fatima", "Ahmed", "Zain", "Hira", "Usman", "Sana", "Hassan", "Mariam",
                 "Kamran", "Nadia", "Omer", "Amna", "Bilal", "Rabia", "Sajjad", "Mehwish", "Tariq", "Samina"]
        last = ["Khan", "Malik", "Sheikh", "Raza", "Ahmed", "Iqbal", "Butt", "Qureshi", "Nawaz", "Akhtar",
                "Baig", "Chaudhry", "Ansari", "Siddiqui", "Mirza", "Javed", "Hussain", "Abbasi", "Aslam", "Niazi"]
        depts = self.query("SELECT id, code, name FROM departments")
        valid_sems = [2, 4, 6, 8]
        sessions_map = {2: "2024-2028", 4: "2023-2027", 6: "2022-2026", 8: "2021-2025"}
        year = datetime.now().year
        with self.connect() as conn:
            existing = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
            if existing >= count:
                return
            roll_counters: dict = {}  # (dept_id, semester, section) -> roll
            for i in range(existing + 1, count + 1):
                dept = random.choice(depts)
                semester = random.choice(valid_sems)
                section = random.choice(["A", "B"])
                key = (dept["id"], semester, section)
                roll_counters[key] = roll_counters.get(key, 0) + 1
                roll_number = roll_counters[key]
                sid = f"{dept['code']}-{year}-{i:04d}"
                name = f"{random.choice(first)} {random.choice(last)}"
                session = sessions_map.get(semester, "2023-2027")
                conn.execute(
                    """INSERT OR IGNORE INTO students(student_id,name,father_name,department_id,program,semester,session,roll_number,section,phone,email,address,attendance_percentage)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (sid, name, f"{random.choice(first)} {random.choice(last)}",
                     dept["id"], dept["name"], semester, session, roll_number, section,
                     f"03{random.randint(0, 4)}{random.randint(10000000, 99999999)}",
                     f"{sid.lower().replace('-', '')}@student.cs.edu.pk",
                     f"House {random.randint(1, 300)}, University Town",
                     round(random.uniform(60, 98), 1)),
                )

    def generate_attendance_sample(self) -> None:
        """Generate 6 months of realistic attendance history (130+ school days)."""
        courses = self.query("SELECT * FROM courses")
        students = self.query("SELECT student_id, semester, section FROM students")
        if not courses or not students:
            return
        start = date.today() - timedelta(days=180)
        methods = ["QR", "Face", "Manual"]
        with self.connect() as conn:
            existing = conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
            if existing >= 5000:   # enough sample data already
                return
            for day in range(180):
                current = start + timedelta(days=day)
                if current.weekday() >= 5:   # skip weekends
                    continue
                for course in courses:
                    eligible = [
                        s for s in students
                        if s["semester"] == course["semester"]
                        and s["section"] == course["section"]
                    ]
                    if not eligible:
                        continue
                    sample_n = min(len(eligible), random.randint(20, 45))
                    for stu in random.sample(eligible, sample_n):
                        present_prob = random.uniform(0.60, 0.95)
                        present = random.random() < present_prob
                        conn.execute(
                            """INSERT OR IGNORE INTO attendance(
                                student_id, course_id, date, time, status, method, confidence)
                            VALUES (?, ?, ?, ?, ?, ?, ?)""",
                            (
                                stu["student_id"],
                                course["course_id"],
                                current.isoformat(),
                                f"{random.randint(8, 16):02d}:"
                                f"{random.choice(['00', '30'])}:00",
                                "Present" if present else "Absent",
                                random.choice(methods),
                                round(random.uniform(78, 99), 2) if present else None,
                            ),
                        )
