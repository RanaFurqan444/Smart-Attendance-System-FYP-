"""Report Center — filtered attendance preview, CSV, Excel, and PDF exports."""

from __future__ import annotations

import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


class ReportsFrame(tk.Frame):
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db    = db
        self.theme = theme
        self.user  = user
        self.build()

    # ── Layout ──────────────────────────────────────────────────────────────
    def build(self):
        th = self.theme
        tk.Label(self, text="Report Center",
                 bg=th["bg"], fg=th["text"],
                 font=("Segoe UI", 22, "bold")).pack(anchor="w")
        tk.Label(self, text="Preview and export attendance records by program, semester, section, date range, or method.",
                 bg=th["bg"], fg=th["muted"]).pack(anchor="w", pady=(0, 8))

        # ── Filter bar ─────────────────────────────────────────────────────
        fbar = tk.Frame(self, bg=th["card"], padx=14, pady=12)
        fbar.pack(fill="x", pady=(0, 8))

        programs = ["All"] + [r["name"] for r in self.db.query(
            "SELECT name FROM departments ORDER BY name")]
        sessions = ["All"] + sorted({
            r["session"] or "" for r in self.db.query(
                "SELECT DISTINCT session FROM students WHERE session IS NOT NULL")
            if r["session"]
        })

        row0 = tk.Frame(fbar, bg=th["card"]); row0.pack(fill="x")
        row1 = tk.Frame(fbar, bg=th["card"]); row1.pack(fill="x", pady=(6, 0))

        def lbl(p, t): tk.Label(p, text=t, bg=th["card"], fg=th["muted"],
                                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 2))

        def cb(p, vals, w=14):
            v = ttk.Combobox(p, state="readonly", values=vals, width=w)
            v.pack(side="left", padx=(0, 12))
            return v

        def ent(p, hint, w=12):
            e = tk.Entry(p, bg=th["panel"], fg=th["text"],
                         insertbackground=th["text"], relief="flat", width=w)
            e.insert(0, hint); e.pack(side="left", padx=(0, 12))
            return e

        lbl(row0, "Program"); self.f_prog = cb(row0, programs, 22); self.f_prog.set("All")
        lbl(row0, "Semester"); self.f_sem = cb(row0, ["All","1","2","3","4","5","6","7","8"], 6); self.f_sem.set("All")
        lbl(row0, "Section"); self.f_sec = cb(row0, ["All","A","B","C","D"], 6); self.f_sec.set("All")
        lbl(row0, "Session"); self.f_sess = cb(row0, sessions, 12); self.f_sess.set("All")
        lbl(row0, "Method"); self.f_method = cb(row0, ["All","Manual","Face","QR","Hybrid"], 8); self.f_method.set("All")
        lbl(row1, "Date From"); self.f_from = ent(row1, datetime.date.today().replace(day=1).isoformat())
        lbl(row1, "Date To");   self.f_to   = ent(row1, datetime.date.today().isoformat())
        lbl(row1, "Status");    self.f_status = cb(row1, ["All","Present","Absent","Late","Excused"], 10); self.f_status.set("All")

        tk.Button(row1, text="🔍 Preview", bg=th["primary"], fg="white",
                  relief="flat", padx=14, pady=4,
                  command=self._preview).pack(side="left", padx=(4, 0))
        tk.Button(row1, text="Clear Filters", bg=th["panel"], fg=th["muted"],
                  relief="flat", padx=10, pady=4,
                  command=self._clear_filters).pack(side="left", padx=6)

        # ── Live preview table ─────────────────────────────────────────────
        pv = tk.Frame(self, bg=th["card"], padx=10, pady=8)
        pv.pack(fill="both", expand=True, pady=(0, 6))

        hdr = tk.Frame(pv, bg=th["card"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="Attendance Preview", bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 12, "bold")).pack(side="left")
        self.count_lbl = tk.Label(hdr, text="", bg=th["card"], fg=th["muted"],
                                   font=("Segoe UI", 9))
        self.count_lbl.pack(side="left", padx=10)

        cols = ("Date", "Roll", "Student", "Program", "Sem", "Sec", "Course", "Status", "Method")
        self.preview_tree = ttk.Treeview(pv, columns=cols, show="headings", height=10)
        widths = [82, 50, 160, 130, 40, 40, 160, 70, 60]
        for col, w in zip(cols, widths):
            self.preview_tree.heading(col, text=col)
            self.preview_tree.column(col, width=w, anchor="center" if col not in ("Student","Course","Program") else "w")
        ysb = ttk.Scrollbar(pv, orient="vertical", command=self.preview_tree.yview)
        xsb = ttk.Scrollbar(pv, orient="horizontal", command=self.preview_tree.xview)
        self.preview_tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        self.preview_tree.tag_configure("present", foreground="#34d399")
        self.preview_tree.tag_configure("absent",  foreground="#fb7185")
        self.preview_tree.tag_configure("late",    foreground="#fbbf24")
        ysb.pack(side="right", fill="y")
        self.preview_tree.pack(side="left", fill="both", expand=True)
        xsb.pack(side="bottom", fill="x")

        # ── Export buttons ─────────────────────────────────────────────────
        exp = tk.Frame(self, bg=th["card"], padx=10, pady=10)
        exp.pack(fill="x")

        def ebtn(txt, cmd, col, row=0, c=0):
            tk.Button(exp, text=txt, bg=col, fg="white", relief="flat",
                      padx=12, pady=6, command=cmd).grid(row=row, column=c, padx=4, pady=3, sticky="ew")

        ebtn("📄 Attendance CSV",        self.export_attendance_csv,    th["primary"],      0, 0)
        ebtn("📊 Attendance Excel",       self.export_attendance_excel,  "#0891b2",          0, 1)
        ebtn("📑 Attendance PDF",         self.export_attendance_pdf,    "#7c3aed",          0, 2)
        ebtn("⚠️  Defaulters CSV",        self.export_defaulters_csv,    th["danger"],       0, 3)
        ebtn("⚠️  Defaulters PDF",        self.export_defaulters_pdf,    "#991b1b",          0, 4)
        ebtn("👨‍🎓 Students CSV",           self.export_students_csv,      th["accent"],       1, 0)
        ebtn("👨‍🎓 Students Excel",         self.export_students_excel,    "#0d9488",          1, 1)
        ebtn("👨‍🏫 Teachers CSV",           self.export_teachers_csv,      "#6366f1",          1, 2)
        ebtn("📚 Courses CSV",             self.export_courses_csv,       "#9333ea",          1, 3)
        ebtn("📈 Analytics PDF",          self.export_analytics_pdf,     "#b45309",          1, 4)
        for i in range(5): exp.grid_columnconfigure(i, weight=1)

        # Auto-preview on load
        self.after(100, self._preview)

    # ── Filter helpers ───────────────────────────────────────────────────────
    def _clear_filters(self):
        self.f_prog.set("All"); self.f_sem.set("All"); self.f_sec.set("All")
        self.f_sess.set("All"); self.f_method.set("All"); self.f_status.set("All")
        self.f_from.delete(0, "end"); self.f_from.insert(0, datetime.date.today().replace(day=1).isoformat())
        self.f_to.delete(0, "end");   self.f_to.insert(0, datetime.date.today().isoformat())
        self._preview()

    def _filters(self):
        prog    = self.f_prog.get();   sem    = self.f_sem.get()
        sec     = self.f_sec.get();    sess   = self.f_sess.get()
        d_from  = self.f_from.get();   d_to   = self.f_to.get()
        method  = self.f_method.get(); status = self.f_status.get()
        where, params = [], []
        if prog   and prog   != "All": where.append("d.name = ?");       params.append(prog)
        if sem    and sem    != "All": where.append("s.semester = ?");    params.append(int(sem))
        if sec    and sec    != "All": where.append("s.section = ?");     params.append(sec)
        if sess   and sess   != "All": where.append("s.session = ?");     params.append(sess)
        if method and method != "All": where.append("a.method = ?");      params.append(method)
        if status and status != "All": where.append("a.status = ?");      params.append(status)
        if d_from and len(d_from) == 10 and d_from[4] == "-":
            where.append("a.date >= ?"); params.append(d_from)
        if d_to   and len(d_to)   == 10 and d_to[4]   == "-":
            where.append("a.date <= ?"); params.append(d_to)
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        return clause, params

    # ── Preview ──────────────────────────────────────────────────────────────
    def _preview(self):
        self.preview_tree.delete(*self.preview_tree.get_children())
        try:
            rows = self.attendance_rows()
        except Exception as exc:
            self.count_lbl.config(text=f"Query error: {exc}")
            return
        self.count_lbl.config(text=f"{len(rows)} records")
        for r in rows[:500]:   # cap preview at 500 rows for performance
            status = str(r["status"] or "")
            tag    = {"Present": "present", "Absent": "absent", "Late": "late"}.get(status, "")
            self.preview_tree.insert("", "end", values=(
                r["date"], r["roll_number"] or "", r["student_name"],
                r["program"], str(r["semester"] or ""), r["section"] or "",
                r["course"], status, r["method"] or "",
            ), tags=(tag,))

    # ── Data queries ─────────────────────────────────────────────────────────
    def attendance_rows(self):
        clause, params = self._filters()
        # LEFT JOIN courses so attendance records survive even if a course
        # was later renamed or removed.
        return self.db.query(
            f"""
            SELECT a.student_id, s.name student_name,
                   s.roll_number, d.name program,
                   s.semester, s.section, s.session,
                   COALESCE(c.subject_name, a.course_name, a.course_id) course,
                   a.date, a.time, a.status, a.method,
                   ROUND(a.confidence,1) confidence
            FROM attendance a
            LEFT JOIN students    s ON s.student_id  = a.student_id
            LEFT JOIN departments d ON d.id           = s.department_id
            LEFT JOIN courses     c ON c.course_id    = a.course_id
            {clause}
            ORDER BY a.date DESC, a.time DESC
            """,
            params,
        )

    def student_rows(self):
        prog = self.f_prog.get(); sem = self.f_sem.get()
        sec  = self.f_sec.get();  sess = self.f_sess.get()
        where, params = [], []
        if prog and prog != "All": where.append("d.name = ?");    params.append(prog)
        if sem  and sem  != "All": where.append("s.semester = ?"); params.append(int(sem))
        if sec  and sec  != "All": where.append("s.section = ?");  params.append(sec)
        if sess and sess != "All": where.append("s.session = ?");  params.append(sess)
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        return self.db.query(
            f"""
            SELECT s.student_id, s.name, s.father_name, d.name program,
                   s.semester, s.session, s.roll_number, s.section,
                   s.phone, s.email,
                   ROUND(s.attendance_percentage,1) attendance_pct
            FROM students s
            LEFT JOIN departments d ON d.id=s.department_id
            {clause}
            ORDER BY d.name, s.semester, s.section, s.roll_number
            """,
            params,
        )

    def defaulter_rows(self):
        prog = self.f_prog.get(); sem = self.f_sem.get()
        sec  = self.f_sec.get();  sess = self.f_sess.get()
        where, params = [], []
        if prog and prog != "All": where.append("d.name = ?");    params.append(prog)
        if sem  and sem  != "All": where.append("s.semester = ?"); params.append(int(sem))
        if sec  and sec  != "All": where.append("s.section = ?");  params.append(sec)
        if sess and sess != "All": where.append("s.session = ?");  params.append(sess)
        wc = ("WHERE " + " AND ".join(where)) if where else ""
        return self.db.query(
            f"""
            SELECT s.student_id, s.name, d.name program, s.semester,
                   s.section, s.session, s.phone, s.email,
                   ROUND(
                       100.0*SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END)
                       /NULLIF(COUNT(a.id),0), 1
                   ) pct
            FROM students s
            LEFT JOIN departments d ON d.id=s.department_id
            LEFT JOIN attendance  a ON a.student_id=s.student_id
            {wc}
            GROUP BY s.student_id
            HAVING pct IS NOT NULL AND pct < 75
            ORDER BY pct ASC
            """,
            params,
        )

    # ── CSV exports ──────────────────────────────────────────────────────────
    def _export_csv(self, rows, headers, filename_hint):
        import csv
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", initialfile=filename_hint,
            filetypes=[("CSV", "*.csv")])
        if not path: return
        if not rows:
            messagebox.showwarning("No Data", "No records match the current filters."); return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                csv.writer(f).writerow(headers)
                for r in rows:
                    csv.writer(f).writerow([r[k] for k in r.keys()])
            messagebox.showinfo("Exported", f"Saved {len(rows)} records to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def export_attendance_csv(self):
        rows = self.attendance_rows()
        hdrs = ["Student ID","Name","Roll","Program","Semester","Section",
                "Session","Course","Date","Time","Status","Method","Confidence"]
        self._export_csv(rows, hdrs, "attendance_report.csv")

    def export_students_csv(self):
        rows = self.student_rows()
        hdrs = ["Student ID","Name","Father Name","Program","Semester",
                "Session","Roll No","Section","Phone","Email","Attendance %"]
        self._export_csv(rows, hdrs, "students_report.csv")

    def export_teachers_csv(self):
        import csv
        rows = self.db.query(
            "SELECT t.teacher_id, t.name, d.name program, t.course_code, "
            "t.designation, t.phone, t.email "
            "FROM teachers t LEFT JOIN departments d ON d.id=t.department_id ORDER BY t.name")
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             initialfile="teachers.csv",
                                             filetypes=[("CSV","*.csv")])
        if not path: return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["Teacher ID","Name","Program","Course Code","Designation","Phone","Email"])
                for r in rows: w.writerow([r[k] for k in r.keys()])
            messagebox.showinfo("Exported", f"Saved {len(rows)} teachers to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def export_courses_csv(self):
        import csv
        rows = self.db.query(
            "SELECT c.course_id, c.subject_name, d.name program, c.semester, "
            "c.section, c.credit_hours, t.name teacher "
            "FROM courses c "
            "LEFT JOIN departments d ON d.id=c.department_id "
            "LEFT JOIN teachers t ON t.teacher_id=c.teacher_id ORDER BY d.name, c.semester")
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             initialfile="courses.csv",
                                             filetypes=[("CSV","*.csv")])
        if not path: return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["Course ID","Subject","Program","Semester","Section","Credit Hours","Teacher"])
                for r in rows: w.writerow([r[k] for k in r.keys()])
            messagebox.showinfo("Exported", f"Saved {len(rows)} courses to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def export_defaulters_csv(self):
        import csv
        rows = self.defaulter_rows()
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             initialfile="defaulters.csv",
                                             filetypes=[("CSV","*.csv")])
        if not path: return
        if not rows:
            messagebox.showinfo("No Defaulters","No students below 75% with current filters."); return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["Student ID","Name","Program","Semester","Section","Session","Phone","Email","Attendance %"])
                for r in rows: w.writerow([r[k] for k in r.keys()])
            messagebox.showinfo("Exported", f"Saved {len(rows)} defaulters to:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    # ── Excel exports ─────────────────────────────────────────────────────────
    def _export_excel(self, rows, sheet, filename):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                             initialfile=filename,
                                             filetypes=[("Excel","*.xlsx")])
        if not path: return
        if not rows:
            messagebox.showwarning("No Data","No records match the current filters."); return
        try:
            import pandas as pd
            pd.DataFrame([dict(r) for r in rows]).to_excel(path, index=False, sheet_name=sheet)
            messagebox.showinfo("Exported", f"Saved {len(rows)} records to:\n{path}")
        except ImportError:
            messagebox.showerror("Missing Library",
                                 "pandas and openpyxl are required for Excel export.\n"
                                 "Run: pip install pandas openpyxl")
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def export_attendance_excel(self):
        self._export_excel(self.attendance_rows(), "Attendance", "attendance.xlsx")

    def export_students_excel(self):
        self._export_excel(self.student_rows(), "Students", "students.xlsx")

    # ── PDF exports ───────────────────────────────────────────────────────────
    def _pdf_header(self, c, width, height, title, subtitle=""):
        try:
            from reportlab.lib import colors as rc
            uni = self.db.scalar("SELECT value FROM settings WHERE key='university_name'") or "University Attendance System"
            c.setFillColor(rc.HexColor("#0f172a"))
            c.rect(0, height-58, width, 58, fill=True, stroke=False)
            c.setFillColor(rc.white); c.setFont("Helvetica-Bold", 14)
            c.drawString(30, height-28, uni)
            c.setFont("Helvetica", 9); c.drawString(30, height-44, title)
            if subtitle:
                c.setFillColor(rc.HexColor("#94a3b8"))
                c.drawRightString(width-30, height-44, subtitle)
        except Exception:
            pass
        return height - 76

    def export_attendance_pdf(self):
        path = filedialog.asksaveasfilename(defaultextension=".pdf",
                                             initialfile="attendance_report.pdf",
                                             filetypes=[("PDF","*.pdf")])
        if not path: return
        try:
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.pdfgen import canvas as rlc
            from reportlab.lib import colors as rc
            import datetime as _dt2
            rows = self.attendance_rows()
            if not rows:
                messagebox.showwarning("No Data","No records match the current filters."); return
            pg_w, pg_h = landscape(A4)
            c = rlc.Canvas(path, pagesize=landscape(A4))
            cols = [("Date",72),("Roll",46),("Name",130),("Program",120),
                    ("Sem",32),("Sec",32),("Course",120),("Status",56),("Method",52)]
            xs = [28]
            for _, w in cols[:-1]: xs.append(xs[-1]+w)
            now_str = _dt2.datetime.now().strftime("%Y-%m-%d %H:%M")
            y = self._pdf_header(c, pg_w, pg_h, f"Attendance Report  ({len(rows)} records)", now_str)

            def _col_header():
                nonlocal y
                c.setFillColor(rc.HexColor("#1e293b"))
                c.rect(28, y-18, pg_w-56, 18, fill=True, stroke=False)
                c.setFillColor(rc.HexColor("#94a3b8")); c.setFont("Helvetica-Bold", 7)
                for i,(h,_) in enumerate(cols): c.drawString(xs[i]+2, y-13, h)
                y -= 20

            _col_header()
            c.setFont("Helvetica", 7)
            for r in rows:
                if y < 32: c.showPage(); y = self._pdf_header(c, pg_w, pg_h, "Attendance (continued)", now_str); _col_header(); c.setFont("Helvetica",7)
                st = str(r["status"] or ""); fc = rc.HexColor("#22c55e") if st=="Present" else rc.HexColor("#ef4444")
                vals = [r["date"], str(r["roll_number"] or ""), r["student_name"],
                        r["program"], str(r["semester"] or ""), str(r["section"] or ""),
                        r["course"], st, str(r["method"] or "")]
                for i,(v,_) in enumerate(zip(vals, cols)):
                    c.setFillColor(fc if i==7 else rc.HexColor("#e2e8f0"))
                    c.drawString(xs[i]+2, y, str(v)[:20])
                y -= 11
            c.save()
            messagebox.showinfo("PDF Exported", f"Saved {len(rows)} records to:\n{path}")
        except ImportError:
            messagebox.showerror("Missing Library","reportlab is required.\nRun: pip install reportlab")
        except Exception as exc:
            messagebox.showerror("PDF Failed", str(exc))

    def export_defaulters_pdf(self):
        path = filedialog.asksaveasfilename(defaultextension=".pdf",
                                             initialfile="defaulters.pdf",
                                             filetypes=[("PDF","*.pdf")])
        if not path: return
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.pdfgen import canvas as rlc
            from reportlab.lib import colors as rc
            import datetime as _dt2
            rows = self.defaulter_rows()
            if not rows:
                messagebox.showinfo("No Defaulters","No students below 75%."); return
            c = rlc.Canvas(path, pagesize=A4); pg_w, pg_h = A4
            now_str = _dt2.datetime.now().strftime("%Y-%m-%d %H:%M")
            y = self._pdf_header(c, pg_w, pg_h, f"Defaulter List — Below 75%  ({len(rows)} students)", now_str)
            cols = [("Student ID",80),("Name",120),("Program",120),("Sem",36),("Sec",36),("Attend%",60)]
            xs=[25];[xs.append(xs[-1]+w) for _,w in cols[:-1]]
            def _ch():
                nonlocal y
                c.setFillColor(rc.HexColor("#1e293b")); c.rect(25,y-18,pg_w-50,18,fill=True,stroke=False)
                c.setFillColor(rc.HexColor("#94a3b8")); c.setFont("Helvetica-Bold",8)
                for i,(h,_) in enumerate(cols): c.drawString(xs[i]+2,y-13,h); y-=20
            _ch(); c.setFont("Helvetica",8)
            for r in rows:
                if y<32: c.showPage(); y=self._pdf_header(c,pg_w,pg_h,"Defaulters (continued)",now_str); _ch(); c.setFont("Helvetica",8)
                pct=float(r["pct"] or 0); fc=rc.HexColor("#ef4444") if pct<60 else rc.HexColor("#f97316")
                vals=[r["student_id"],r["name"],r["program"],str(r["semester"] or ""),str(r["section"] or ""),f"{pct:.1f}%"]
                for i,v in enumerate(vals):
                    c.setFillColor(fc if i==5 else rc.HexColor("#e2e8f0")); c.drawString(xs[i]+2,y,str(v)[:22]); 
                y-=14
            c.save()
            messagebox.showinfo("PDF Exported", f"Saved {len(rows)} defaulters to:\n{path}")
        except ImportError:
            messagebox.showerror("Missing Library","reportlab is required.\nRun: pip install reportlab")
        except Exception as exc:
            messagebox.showerror("PDF Failed", str(exc))

    def export_analytics_pdf(self):
        path = filedialog.asksaveasfilename(defaultextension=".pdf",
                                             initialfile="analytics_summary.pdf",
                                             filetypes=[("PDF","*.pdf")])
        if not path: return
        try:
            import matplotlib; matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            import matplotlib.backends.backend_pdf as mpdf
            import pandas as pd
            import datetime as _dt2
            with self.db.connect() as conn:
                df = pd.read_sql_query(
                    """SELECT a.student_id, a.date, a.status, s.semester, d.name program, c.subject_name subject_name
                    FROM attendance a
                    LEFT JOIN students s ON s.student_id=a.student_id
                    LEFT JOIN departments d ON d.id=s.department_id
                    LEFT JOIN courses c ON c.course_id=a.course_id""", conn)
            if df.empty:
                messagebox.showwarning("No Data","No attendance records found."); return
            df["present"]  = (df["status"]=="Present").astype(int)
            df["date"]     = pd.to_datetime(df["date"], errors="coerce")
            df["month"]    = df["date"].dt.to_period("M").astype(str)
            uni = self.db.scalar("SELECT value FROM settings WHERE key='university_name'") or "University Attendance System"

            with mpdf.PdfPages(path) as pdf:
                fc="#0f172a"; ac="#1e293b"; tc="#e2e8f0"; mc="#94a3b8"
                fig = plt.figure(figsize=(11.69,8.27)); fig.patch.set_facecolor(fc)
                ax  = fig.add_subplot(111); ax.set_facecolor(fc); ax.axis("off")
                ax.text(0.5,0.72,uni,ha="center",fontsize=26,fontweight="bold",color=tc,transform=ax.transAxes)
                ax.text(0.5,0.58,"Analytics Summary Report",ha="center",fontsize=18,color=mc,transform=ax.transAxes)
                ax.text(0.5,0.45,f"Generated: {_dt2.datetime.now().strftime('%A, %d %B %Y  %H:%M')}",ha="center",fontsize=12,color="#64748b",transform=ax.transAxes)
                overall=df["present"].mean()*100; ts=df["student_id"].nunique(); b75=(df.groupby("student_id")["present"].mean().mul(100)<75).sum()
                ax.text(0.5,0.30,f"Overall Rate: {overall:.1f}%   |   Students: {ts}   |   Defaulters: {b75}",ha="center",fontsize=13,color="#38bdf8",transform=ax.transAxes)
                pdf.savefig(fig,facecolor=fc); plt.close(fig)

                charts=[
                    ("Program Attendance",df.groupby("program")["present"].mean().mul(100).sort_values(ascending=False),["#38bdf8","#34d399","#f472b6","#fbbf24","#a78bfa"],"bar"),
                    ("Semester Attendance",df.groupby("semester")["present"].mean().mul(100).sort_index().rename(lambda x:f"Sem {x}"),["#60a5fa","#34d399","#fbbf24","#fb7185"],"bar"),
                    ("Course Attendance",df.groupby("subject_name")["present"].mean().mul(100).sort_values(),"#a78bfa","barh"),
                    ("Monthly Trend",df.groupby("month")["present"].mean().mul(100),"#34d399","line"),
                ]
                for title,series,colors,kind in charts:
                    if series.empty: continue
                    fig,ax=plt.subplots(figsize=(11.69,6.5)); fig.patch.set_facecolor(fc); ax.set_facecolor(ac)
                    if kind=="bar":
                        bars=ax.bar(range(len(series)),series.values,color=colors if isinstance(colors,list) else [colors]*len(series),width=0.6)
                        ax.set_xticks(range(len(series))); ax.set_xticklabels(series.index,color=mc,fontsize=9,rotation=12,ha="right")
                        ax.set_ylabel("Attendance %",color=mc); ax.axhline(75,color="#ef4444",lw=1,ls="--",alpha=0.7,label="75% line"); ax.legend(facecolor=ac,labelcolor=mc,fontsize=9)
                        for bar,val in zip(bars,series.values): ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+0.4,f"{val:.1f}%",ha="center",va="bottom",color=tc,fontsize=8)
                    elif kind=="barh":
                        ax.barh(range(len(series)),series.values,color=colors,height=0.7); ax.set_yticks(range(len(series))); ax.set_yticklabels(series.index,color=mc,fontsize=7); ax.set_xlabel("Attendance %",color=mc); ax.axvline(75,color="#ef4444",lw=1,ls="--",alpha=0.7)
                    else:
                        ax.fill_between(range(len(series)),series.values,color="#14b8a6",alpha=0.25)
                        ax.plot(range(len(series)),series.values,color="#2dd4bf",lw=2,marker="o",ms=5)
                        ax.set_xticks(range(len(series))); ax.set_xticklabels(series.index,color=mc,fontsize=9,rotation=30,ha="right"); ax.set_ylabel("Attendance %",color=mc); ax.axhline(75,color="#ef4444",lw=1,ls="--",alpha=0.5)
                    ax.set_title(title,color=tc,fontsize=14,pad=10); ax.tick_params(colors=mc)
                    if kind!="barh": ax.set_ylim(0,105)
                    for sp in ax.spines.values(): sp.set_color("#334155")
                    fig.tight_layout(pad=2); pdf.savefig(fig,facecolor=fc); plt.close(fig)
            messagebox.showinfo("PDF Exported",f"Analytics report saved to:\n{path}")
        except ImportError:
            messagebox.showerror("Missing Libraries","matplotlib, pandas, and reportlab are required.\nRun: pip install matplotlib pandas reportlab")
        except Exception as exc:
            messagebox.showerror("Analytics PDF Failed", str(exc))
