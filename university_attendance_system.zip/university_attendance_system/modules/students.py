"""Student management — CRUD with validation, live-camera face enrollment, and QR generation."""

from __future__ import annotations

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


class StudentsFrame(tk.Frame):
    """Professional CRUD screen for university student records."""

    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.theme = theme
        self.user = user
        self._is_admin = True
        if user:
            try:
                role = user["role"]          # works for both dict and sqlite3.Row
            except (KeyError, TypeError):
                role = ""
            self._is_admin = (role == "Admin")
        self.selected_id = None
        self.build()
        self.load()

    def build(self) -> None:
        is_admin = getattr(self, '_is_admin', True)
        header = tk.Frame(self, bg=self.theme["bg"])
        header.pack(fill="x")
        tk.Label(header, text="Student Management", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 24, "bold")).pack(side="left")
        if is_admin:
            tk.Button(header, text="+ Add Student", bg=self.theme["primary"], fg="white", relief="flat", padx=18, pady=9, command=self.add_popup).pack(side="right", padx=(8, 0))
            tk.Button(header, text="Edit Selected", bg=self.theme["accent"], fg="white", relief="flat", padx=16, pady=9, command=self.edit_popup).pack(side="right", padx=(8, 0))
            tk.Button(header, text="Delete", bg=self.theme["danger"], fg="white", relief="flat", padx=16, pady=9, command=self.delete).pack(side="right")
        else:
            tk.Label(header, text="View Only", bg=self.theme["bg"], fg=self.theme["warning"], font=("Segoe UI", 10)).pack(side="right", padx=10)
        # Register Face button visible to all roles
        tk.Button(header, text="Register Face",
                  bg="#0891b2", fg="white", relief="flat",
                  padx=14, pady=9, font=("Segoe UI", 10, "bold"),
                  command=self.open_face_register_for_selected).pack(side="right", padx=(0, 8))

        filters = tk.Frame(self, bg=self.theme["card"], padx=12, pady=10)
        filters.pack(fill="x", pady=12)
        self.search = tk.StringVar()
        self.dept_filter = ttk.Combobox(filters, state="readonly", width=28, values=["All Programs"] + [r["name"] for r in self.db.query("SELECT name FROM departments ORDER BY name")])
        self.sem_filter = ttk.Combobox(filters, state="readonly", width=12, values=["All", "2", "4", "6", "8"])
        self.dept_filter.set("All Programs")
        self.sem_filter.set("All")
        tk.Entry(filters, textvariable=self.search, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat").pack(side="left", fill="x", expand=True, ipady=8)
        self.dept_filter.pack(side="left", padx=6)
        self.sem_filter.pack(side="left", padx=6)
        tk.Button(filters, text="Search", bg=self.theme["primary"], fg="white", relief="flat", padx=16, command=self.load).pack(side="left", padx=4)
        tk.Button(filters, text="Clear", bg=self.theme["panel"], fg=self.theme["text"], relief="flat", padx=16, command=self.clear_filters).pack(side="left", padx=4)

        table_frame = tk.Frame(self, bg=self.theme["card"], padx=10, pady=10)
        table_frame.pack(fill="both", expand=True)
        cols = ("id", "name", "father", "program", "semester", "session", "roll", "section", "phone", "email", "attend%", "face", "qr")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        widths = {"id": 130, "name": 150, "father": 130, "program": 180, "semester": 80, "session": 100, "roll": 60, "section": 70, "phone": 110, "email": 190, "attend%": 80, "face": 60, "qr": 60}
        for col in cols:
            self.tree.heading(col, text=col.replace("attend%", "Attend%").replace("roll", "Roll No").title())
            self.tree.column(col, width=widths.get(col, 100), anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.select)
        if is_admin:
            self.tree.bind("<Double-1>", lambda _e: self.edit_popup())

    def clear_filters(self) -> None:
        self.search.set("")
        self.dept_filter.set("All Programs")
        self.sem_filter.set("All")
        self.load()

    def load(self) -> None:
        self.tree.delete(*self.tree.get_children())
        like = f"%{self.search.get().strip()}%"
        params = [like, like, like, like]
        where = "WHERE (s.student_id LIKE ? OR s.name LIKE ? OR s.email LIKE ? OR s.phone LIKE ?)"
        if self.dept_filter.get() and self.dept_filter.get() not in ("All Programs", ""):
            where += " AND d.name = ?"
            params.append(self.dept_filter.get())
        if self.sem_filter.get() and self.sem_filter.get() != "All":
            where += " AND s.semester = ?"
            params.append(int(self.sem_filter.get()))
        rows = self.db.query(
            f"""
            SELECT s.*, d.name dept_name,
            EXISTS(SELECT 1 FROM face_data f WHERE f.owner_type='Student' AND f.owner_id=s.student_id) face_ready
            FROM students s JOIN departments d ON d.id = s.department_id
            {where}
            ORDER BY s.semester, s.section, s.roll_number LIMIT 1500
            """,
            params,
        )
        for row in rows:
            prog = row["program"] or row["dept_name"] or ""
            attend_pct = f"{row['attendance_percentage'] or 0:.1f}%"
            self.tree.insert(
                "",
                "end",
                values=(
                    row["student_id"],
                    row["name"],
                    row["father_name"] or "",
                    prog,
                    row["semester"],
                    row["session"] or "",
                    row["roll_number"] or "",
                    row["section"],
                    row["phone"] or "",
                    row["email"] or "",
                    attend_pct,
                    "Yes" if row["face_ready"] else "No",
                    "Yes" if row["qr_code_path"] else "No",
                ),
            )

    def select(self, _event=None) -> None:
        item = self.tree.focus()
        self.selected_id = self.tree.item(item)["values"][0] if item else None

    def add_popup(self) -> None:
        self.open_form("Add Student")

    def edit_popup(self) -> None:
        if not self.selected_id:
            messagebox.showwarning("Select Student", "Select a student row to edit.")
            return
        row = self.db.query("SELECT * FROM students WHERE student_id=?", (self.selected_id,))
        if not row:
            messagebox.showerror("Not Found", "Selected student was not found.")
            return
        self.open_form("Edit Student", dict(row[0]))

    def open_form(self, title: str, student: dict | None = None) -> None:
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=self.theme["bg"])
        win.geometry("620x680")
        win.minsize(560, 620)
        win.transient(self.winfo_toplevel())
        win.grab_set()
        canvas = tk.Canvas(win, bg=self.theme["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        content = tk.Frame(canvas, bg=self.theme["card"], padx=22, pady=18)
        content.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=content, anchor="nw", width=590)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        tk.Label(content, text=title, bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 20, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        vars_ = {
            "student_id": tk.StringVar(value=(student or {}).get("student_id", "")),
            "name": tk.StringVar(value=(student or {}).get("name", "")),
            "father_name": tk.StringVar(value=(student or {}).get("father_name", "")),
            "phone": tk.StringVar(value=(student or {}).get("phone", "")),
            "email": tk.StringVar(value=(student or {}).get("email", "")),
            "address": tk.StringVar(value=(student or {}).get("address", "")),
            "section": tk.StringVar(value=(student or {}).get("section", "A")),
            "session": tk.StringVar(value=(student or {}).get("session", "")),
            "roll_number": tk.StringVar(value=str((student or {}).get("roll_number", "") or "")),
        }
        departments = [f"{r['id']} - {r['name']}" for r in self.db.query("SELECT * FROM departments ORDER BY name")]
        dept = ttk.Combobox(content, state="readonly", values=departments)
        semester = ttk.Combobox(content, state="readonly", values=["2", "4", "6", "8"])
        if student:
            dept_name = self.db.scalar("SELECT name FROM departments WHERE id=?", (student["department_id"],))
            dept.set(f"{student['department_id']} - {dept_name}")
            semester.set(str(student["semester"]))
        elif departments:
            dept.set(departments[0])
            semester.set("2")

        def on_dept_change(_e=None):
            d = dept.get().split(" - ", 1)
            prog = d[1] if len(d) > 1 else ""
            # auto-fill session based on semester
            sem_sessions = {"2": "2024-2028", "4": "2023-2027", "6": "2022-2026", "8": "2021-2025"}
            if not vars_["session"].get():
                vars_["session"].set(sem_sessions.get(semester.get(), "2024-2028"))
        dept.bind("<<ComboboxSelected>>", on_dept_change)
        semester.bind("<<ComboboxSelected>>", on_dept_change)

        def field(row: int, label: str, key: str, readonly: bool = False) -> None:
            tk.Label(content, text=label, bg=self.theme["card"], fg=self.theme["muted"]).grid(row=row, column=0, sticky="w", pady=(8, 2))
            entry = tk.Entry(content, textvariable=vars_[key], bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat")
            if readonly:
                entry.configure(state="readonly")
            entry.grid(row=row + 1, column=0, columnspan=2, sticky="ew", ipady=7)

        tk.Label(content, text="Student ID", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=1, column=0, sticky="w", pady=(8, 2))
        sid_row = tk.Frame(content, bg=self.theme["card"])
        sid_row.grid(row=2, column=0, columnspan=2, sticky="ew")
        sid_entry = tk.Entry(sid_row, textvariable=vars_["student_id"], bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat")
        if student:
            sid_entry.configure(state="readonly")
        sid_entry.pack(side="left", fill="x", expand=True, ipady=7)
        tk.Button(sid_row, text="Generate", bg=self.theme["panel"], fg=self.theme["text"], relief="flat", command=lambda: vars_["student_id"].set(self.next_id_for_dept(dept))).pack(side="left", padx=(8, 0))
        field(3, "Full Name", "name")
        field(5, "Father Name", "father_name")
        tk.Label(content, text="Program", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=7, column=0, sticky="w", pady=(8, 2))
        dept.grid(row=8, column=0, columnspan=2, sticky="ew")
        tk.Label(content, text="Semester (2/4/6/8)", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=9, column=0, sticky="w", pady=(8, 2))
        semester.grid(row=10, column=0, columnspan=2, sticky="ew")
        field(11, "Section (A/B)", "section")
        field(13, "Academic Session (e.g. 2024-2028)", "session")
        field(15, "Roll Number in Class", "roll_number")
        field(17, "Phone", "phone")
        field(19, "Email", "email")
        field(21, "Address", "address")

        def save() -> None:
            if not vars_["student_id"].get().strip():
                vars_["student_id"].set(self.next_id_for_dept(dept))
            dept_sel  = dept.get()
            dept_id   = int(dept_sel.split(" - ")[0]) if dept_sel else ""
            prog_name = dept_sel.split(" - ", 1)[1] if " - " in dept_sel else ""
            qr_path   = self.generate_student_qr(vars_["student_id"].get().strip().upper())
            data = {
                "student_id":   vars_["student_id"].get(),
                "name":         vars_["name"].get(),
                "father_name":  vars_["father_name"].get(),
                "department_id": dept_id,
                "program":      prog_name,
                "semester":     semester.get(),
                "session":      vars_["session"].get(),
                "roll_number":  vars_["roll_number"].get(),
                "section":      vars_["section"].get(),
                "phone":        vars_["phone"].get(),
                "email":        vars_["email"].get(),
                "address":      vars_["address"].get(),
                "qr_code_path": qr_path,
            }
            ok, msg = self.db.add_student(data, update=bool(student))
            if not ok:
                messagebox.showerror("Student Save Failed", msg, parent=win)
                return
            saved_id   = vars_["student_id"].get().strip().upper()
            saved_name = vars_["name"].get().strip()
            win.destroy()
            self.load()
            # For NEW students only: prompt to register Face ID immediately
            if not student:
                self._prompt_face_register(saved_id, saved_name)

        tk.Button(content, text="Save Student",
                  bg=self.theme["primary"], fg="white", relief="flat", pady=10,
                  command=save).grid(row=26, column=0, columnspan=2, sticky="ew", pady=(8, 4))
        tk.Label(content,
                 text="📷 Face ID will be registered automatically after saving a new student.",
                 bg=self.theme["card"], fg=self.theme["muted"],
                 font=("Segoe UI", 8), wraplength=340,
                 justify="left").grid(row=27, column=0, columnspan=2, sticky="w", pady=(4, 0))
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=0)

    # ── Face Registration for selected existing student ────────────────────────
    def open_face_register_for_selected(self) -> None:
        """Open face enrollment for the currently selected student (any role can use this)."""
        if not self.selected_id:
            messagebox.showinfo(
                "Select a Student",
                "Click on a student row in the table first, then click Register Face."
            )
            return
        row = self.db.query(
            "SELECT student_id, name FROM students WHERE student_id = ?",
            (self.selected_id,),
        )
        if not row:
            messagebox.showerror("Not Found", "Student record not found.")
            return
        student_id   = row[0]["student_id"]
        student_name = row[0]["name"]
        # Check if already registered
        has_face = self.db.scalar(
            "SELECT COUNT(*) FROM face_data WHERE owner_type='Student' AND owner_id=?",
            (student_id,),
        ) or 0
        if has_face:
            if not messagebox.askyesno(
                "Re-register Face ID?",
                f"{student_name} already has a Face ID registered.\n\n"
                "Do you want to re-register (this will replace the existing data)?"
            ):
                return
        self._open_face_register_window(student_id, student_name)

    def next_id_for_dept(self, dept_combo: ttk.Combobox) -> str:
        if not dept_combo.get():
            return ""
        dept_id = int(dept_combo.get().split(" - ")[0])
        dept_code = self.db.scalar("SELECT code FROM departments WHERE id = ?", (dept_id,))
        return self.db.next_student_id(dept_code)
    # ── Face Registration (triggered automatically after new student save) ─────
    def _prompt_face_register(self, student_id: str, student_name: str) -> None:
        """Prompt user to register face right after a new student is saved."""
        ans = messagebox.askyesno(
            "📷 Register Face ID?",
            f"Student  '{student_name}'  added successfully!\n\n"
            "Register their Face ID now?\n"
            "(Camera opens for a guided 5-angle capture — takes ~30 seconds)",
        )
        if ans:
            self._open_face_register_window(student_id, student_name)


    def _open_face_register_window(self, student_id: str, student_name: str) -> None:
        """Guided multi-angle face enrollment - called after saving a new student."""
        from modules.face_system import FaceEngine, ensure_cv

        cv2_test, _ = ensure_cv()
        if cv2_test is None:
            messagebox.showerror(
                "OpenCV Missing",
                "Face registration requires opencv-python.\n\nRun:  pip install opencv-python\nThen restart."
            )
            return

        STAGES = [
            ("Look Straight",      "#38bdf8", "STRAIGHT", "Face the camera directly"),
            ("Turn Slightly Left",  "#a78bfa", "LEFT",     "Turn your head a little to the left"),
            ("Turn Slightly Right", "#34d399", "RIGHT",    "Turn your head a little to the right"),
            ("Tilt Slightly Up",    "#fbbf24", "UP",       "Look slightly upward"),
            ("Tilt Slightly Down",  "#f472b6", "DOWN",     "Lower your gaze slightly"),
        ]
        SPG   = 6
        TOTAL = len(STAGES) * SPG

        th  = self.theme
        win = tk.Toplevel(self)
        win.title("Face ID Enrollment - " + student_name)
        win.geometry("840x580")
        win.configure(bg="#0f172a")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()

        hdr = tk.Frame(win, bg="#0891b2", padx=18, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Face ID Enrollment",
                 font=("Segoe UI", 15, "bold"), bg="#0891b2", fg="white").pack(side="left")
        tk.Label(hdr, text="Student: " + student_name + "  |  ID: " + student_id,
                 font=("Segoe UI", 10), bg="#0891b2", fg="#e0f2fe").pack(side="left", padx=16)

        body = tk.Frame(win, bg="#0f172a")
        body.pack(fill="both", expand=True)

        left_f = tk.Frame(body, bg="#0f172a")
        left_f.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        cam_lbl = tk.Label(left_f, bg="#0f172a", text="Opening camera...",
                           fg="#94a3b8", font=("Segoe UI", 12))
        cam_lbl.pack()
        icon_lbl = tk.Label(left_f, text="", font=("Segoe UI", 36), bg="#0f172a", fg="white")
        icon_lbl.pack(pady=(4, 0))
        hint_lbl = tk.Label(left_f, text="", font=("Segoe UI", 13, "bold"),
                            bg="#0f172a", fg="#38bdf8", wraplength=500)
        hint_lbl.pack()

        right_f = tk.Frame(body, bg="#1e293b", width=220)
        right_f.pack(side="right", fill="y", padx=(0, 10), pady=10)
        right_f.pack_propagate(False)
        tk.Label(right_f, text=student_name,
                 font=("Segoe UI", 10, "bold"), bg="#1e293b",
                 fg="white", wraplength=200).pack(pady=(12, 2), padx=8)
        tk.Label(right_f, text="Face ID Enrollment",
                 font=("Segoe UI", 9), bg="#1e293b", fg="#94a3b8").pack()

        bar_cv = tk.Canvas(right_f, width=185, height=16, bg="#1e293b", highlightthickness=0)
        bar_cv.pack(pady=6, padx=8)
        bar_lbl = tk.Label(right_f, text="0 / 30 samples",
                           font=("Segoe UI", 9), bg="#1e293b", fg="#38bdf8")
        bar_lbl.pack()

        def _bar(done):
            bar_cv.delete("all")
            bar_cv.create_rectangle(0, 3, 185, 13, fill="#334155", outline="")
            w = int(185 * done / TOTAL)
            if w:
                bar_cv.create_rectangle(0, 3, w, 13,
                                        fill="#34d399" if done < TOTAL else "#fbbf24",
                                        outline="")
            bar_lbl.config(text=str(done) + " / " + str(TOTAL) + " samples")

        _bar(0)
        stage_rows = []
        for sn, sc_col, si_lbl, _ in STAGES:
            r = tk.Frame(right_f, bg="#1e293b")
            r.pack(fill="x", padx=8, pady=1)
            lb = tk.Label(r, text="o " + si_lbl + " " + sn, font=("Segoe UI", 9),
                          bg="#1e293b", fg="#475569", anchor="w")
            lb.pack(fill="x")
            stage_rows.append((lb, sn, sc_col))

        st_lbl = tk.Label(right_f, text="Ready",
                          font=("Segoe UI", 8), bg="#1e293b",
                          fg="#64748b", wraplength=210, justify="left")
        st_lbl.pack(padx=8, pady=(8, 0))

        tk.Button(right_f, text="Skip / Close",
                  bg="#374151", fg="white", relief="flat",
                  padx=10, pady=5,
                  command=lambda: _stop(True)).pack(pady=(14, 0), padx=10)

        cap_ref = [None]
        cv2_ref = [None]
        eng_ref = [None]
        job_ref = [None]
        samples = []
        si = [0]
        sc = [0]
        fr = [0]
        done_flag = [False]
        win._open = True

        def _stop(destroy=False):
            win._open = False
            if job_ref[0]:
                try:
                    win.after_cancel(job_ref[0])
                except Exception:
                    pass
            if cap_ref[0]:
                try:
                    cap_ref[0].release()
                except Exception:
                    pass
                cap_ref[0] = None
            if destroy and win.winfo_exists():
                win.grab_release()
                win.destroy()

        def _open_cam():
            cv2_local, _ = ensure_cv()
            if not cv2_local:
                return False
            cv2_ref[0] = cv2_local
            cam_idx = int(
                self.db.scalar("SELECT value FROM settings WHERE key='camera_index'") or 0
            )
            thr = float(
                self.db.scalar("SELECT value FROM settings WHERE key='face_threshold'") or 72
            )
            indexes  = [cam_idx] if cam_idx == 0 else [cam_idx, 0, 1]
            backends = [cv2_local.CAP_ANY]
            if hasattr(cv2_local, "CAP_DSHOW"):
                backends.insert(0, cv2_local.CAP_DSHOW)
            if hasattr(cv2_local, "CAP_MSMF"):
                backends.append(cv2_local.CAP_MSMF)
            for backend in backends:
                for idx in indexes:
                    try:
                        c = cv2_local.VideoCapture(idx, backend)
                        if c.isOpened():
                            c.set(cv2_local.CAP_PROP_FRAME_WIDTH, 640)
                            c.set(cv2_local.CAP_PROP_FRAME_HEIGHT, 480)
                            ok, frame = c.read()
                            if ok and frame is not None:
                                cap_ref[0] = c
                                eng_ref[0] = FaceEngine(camera_index=idx, threshold=thr)
                                return True
                        try:
                            c.release()
                        except Exception:
                            pass
                    except Exception:
                        pass
            return False

        def _capture():
            if not win._open or not win.winfo_exists() or done_flag[0]:
                return
            if cap_ref[0] is None:
                job_ref[0] = win.after(200, _capture)
                return
            ok, frame = cap_ref[0].read()
            if not ok:
                job_ref[0] = win.after(200, _capture)
                return
            cv2_l = cv2_ref[0]
            eng   = eng_ref[0]
            gray  = cv2_l.cvtColor(frame, cv2_l.COLOR_BGR2GRAY)
            # Equalized for detection; original for ROI so normalize_face
            # can apply CLAHE on just the face region (stable across sessions).
            gray_eq = cv2_l.equalizeHist(gray)
            faces   = eng.detect_faces(gray_eq)
            sg    = STAGES[si[0]]
            sg_name, sg_col, sg_icon, sg_hint = sg
            icon_lbl.config(text=sg_icon)
            hint_lbl.config(text=sg_hint)
            if len(faces) > 0:
                (x, y, w, h) = sorted(faces, key=lambda r: r[2] * r[3], reverse=True)[0]
                roi = gray[y:y + h, x:x + w]   # crop from ORIGINAL (not equalized)
                if fr[0] % 4 == 0 and sc[0] < SPG:
                    samples.append(eng.normalize_face(roi))
                    sc[0] += 1
                    _bar(len(samples))
                    if sc[0] >= SPG:
                        lb_row, _, lbl_col = stage_rows[si[0]]
                        lb_row.config(text="Done: " + sg_name, fg=lbl_col)
                        si[0] += 1
                        sc[0] = 0
                        if si[0] >= len(STAGES):
                            _save_face()
                            return
                        st_lbl.config(text="Stage " + str(si[0] + 1) + "/" + str(len(STAGES)))
                hx = sg_col.lstrip("#")
                bgr = (int(hx[4:6], 16), int(hx[2:4], 16), int(hx[0:2], 16))
                cv2_l.rectangle(frame, (x, y), (x + w, y + h), bgr, 3)
                cv2_l.putText(frame, sg_name + " " + str(sc[0]) + "/" + str(SPG),
                              (x, max(22, y - 10)),
                              cv2_l.FONT_HERSHEY_SIMPLEX, 0.65, bgr, 2)
            else:
                cv2_l.putText(frame, "No face - move closer",
                              (20, 40), cv2_l.FONT_HERSHEY_SIMPLEX, 0.7, (100, 100, 255), 2)
            fr[0] += 1
            try:
                from PIL import Image as _PIL2, ImageTk as _ITK
                rgb = cv2_l.cvtColor(frame, cv2_l.COLOR_BGR2RGB)
                ph  = _ITK.PhotoImage(_PIL2.fromarray(rgb).resize((470, 300)))
                cam_lbl.config(image=ph, text="")
                cam_lbl._img = ph
            except Exception:
                pass
            job_ref[0] = win.after(35, _capture)

        def _save_face():
            done_flag[0] = True
            sql = (
                "INSERT INTO face_data(owner_type, owner_id, feature_json, image_path) "
                "VALUES ('Student', ?, ?, '') "
                "ON CONFLICT(owner_type, owner_id) "
                "DO UPDATE SET feature_json=excluded.feature_json, image_path=''"
            )
            self.db.execute(sql, (student_id, eng_ref[0].encode_face_samples(samples)))
            _bar(TOTAL)
            st_lbl.config(text="Done! " + str(len(samples)) + " samples saved.", fg="#34d399")
            cam_lbl.config(image="", text="Face ID Enrolled\n" + student_name,
                           fg="#34d399", font=("Segoe UI", 16, "bold"))
            icon_lbl.config(text="OK")
            hint_lbl.config(text="Face ID registered successfully!", fg="#34d399")
            _stop(destroy=False)
            win.after(2000, lambda: _stop(True) if win.winfo_exists() else None)

        if not _open_cam():
            cam_lbl.config(text="No camera found.\nCheck Settings -> Camera Index.",
                           fg="#fb7185")
        else:
            st_lbl.config(text="Stage 1/" + str(len(STAGES)) + ": Look Straight")
            job_ref[0] = win.after(100, _capture)

        win.protocol("WM_DELETE_WINDOW", lambda: _stop(True))


    def delete(self) -> None:
        if not self.selected_id:
            messagebox.showwarning("Select Student", "Select a student row to delete.")
            return
        if not messagebox.askyesno("Confirm Delete", f"Delete student {self.selected_id}?"):
            return
        try:
            self.db.execute("DELETE FROM face_data WHERE owner_type='Student' AND owner_id=?", (self.selected_id,))
            self.db.execute("DELETE FROM attendance WHERE student_id=?", (self.selected_id,))
            self.db.execute("DELETE FROM users WHERE linked_id=? AND role='Student'", (self.selected_id,))
            self.db.execute("DELETE FROM students WHERE student_id=?", (self.selected_id,))
            messagebox.showinfo("Deleted", "Student deleted successfully.")
            self.selected_id = None
            self.load()
        except Exception as exc:
            messagebox.showerror("Delete Failed", str(exc))

    def generate_student_qr(self, student_id: str) -> str:
        qr_dir = Path(__file__).resolve().parents[1] / "assets" / "qr_codes" / "students"
        qr_dir.mkdir(parents=True, exist_ok=True)
        out = qr_dir / f"{student_id}.png"
        try:
            import qrcode
            img = qrcode.make(f"STUDENT::{student_id}")
            img.save(out)
            return str(out)
        except Exception:
            return ""
