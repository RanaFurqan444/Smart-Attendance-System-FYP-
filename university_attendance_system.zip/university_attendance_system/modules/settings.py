"""Settings module — button-driven sections including Security Center and User Management."""

from __future__ import annotations

import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


class SettingsFrame(tk.Frame):
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db    = db
        self.user  = user
        self.theme = theme
        self.vars  = {}
        self.build()

    def setting(self, key, default=""):
        return self.db.scalar("SELECT value FROM settings WHERE key=?", (key,)) or default

    def save_setting(self, key, value):
        self.db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (key, value))

    # ── Layout ────────────────────────────────────────────────────────────────
    def build(self):
        th = self.theme
        tk.Label(self, text="Settings",
                 bg=th["bg"], fg=th["text"],
                 font=("Segoe UI", 20, "bold")).pack(anchor="w")
        tk.Label(self, text="Click any section below to open it.",
                 bg=th["bg"], fg=th["muted"]).pack(anchor="w", pady=(0, 10))

        # Content pane (right side, fills on section click)
        outer = tk.Frame(self, bg=th["bg"])
        outer.pack(fill="both", expand=True)

        # Left: section menu
        menu = tk.Frame(outer, bg=th["panel"], width=220)
        menu.pack(side="left", fill="y", padx=(0, 12))
        menu.pack_propagate(False)

        # Right: content area
        self.content = tk.Frame(outer, bg=th["card"], padx=16, pady=14)
        self.content.pack(side="left", fill="both", expand=True)

        # Default content
        tk.Label(self.content,
                 text="← Select a section from the menu",
                 bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 12)).pack(anchor="w", pady=30)

        sections = [
            ("🎨  Branding & Theme",        self._show_branding),
            ("👤  Admin Account",            self._show_admin_account),
            ("👩‍🏫  Teacher Management",      self._show_teacher_mgmt),
            ("📷  Camera & Recognition",     self._show_recognition),
            ("🗄️  Database & Data Tools",    self._show_db_tools),
            ("🔒  Security Center",          self._show_security_center),
            ("👥  All Users",                self._show_all_users),
        ]

        tk.Label(menu, text="Settings Menu",
                 bg=th["panel"], fg=th["text"],
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(18, 8))
        tk.Frame(menu, bg=th["card"], height=1).pack(fill="x", padx=12, pady=(0, 8))

        self._menu_btns = []
        for label, cmd in sections:
            btn = tk.Button(
                menu, text=label, anchor="w",
                bg=th["panel"], fg=th["text"],
                activebackground=th["card"],
                relief="flat", padx=16, pady=11,
                font=("Segoe UI", 10),
                command=lambda c=cmd, b=None: self._nav(c),
            )
            btn.pack(fill="x")
            self._menu_btns.append(btn)

    def _nav(self, cmd):
        for w in self.content.winfo_children():
            w.destroy()
        cmd()

    # ── Section: Branding ─────────────────────────────────────────────────────
    def _show_branding(self):
        th = self.theme
        self._section_header("🎨 Branding & Theme")
        for key, label, default in [
            ("university_name", "University Name", "University Attendance System"),
            ("theme", "Theme (dark / light)", "dark"),
            ("logo_path", "Logo File Path", ""),
        ]:
            self.vars[key] = tk.StringVar(value=self.setting(key, default))
            tk.Label(self.content, text=label, bg=th["card"], fg=th["muted"]).pack(anchor="w", pady=(6, 2))
            row = tk.Frame(self.content, bg=th["card"])
            row.pack(fill="x")
            tk.Entry(row, textvariable=self.vars[key],
                     bg=th["panel"], fg=th["text"],
                     insertbackground=th["text"], relief="flat").pack(
                side="left", fill="x", expand=True, ipady=6)
            if key == "logo_path":
                tk.Button(row, text="Browse", bg=th["accent"], fg="white",
                          relief="flat", padx=10,
                          command=lambda: (
                              path := filedialog.askopenfilename(
                                  filetypes=[("Images", "*.png *.jpg *.ico")]),
                              self.vars["logo_path"].set(path) if path else None,
                          )).pack(side="left", padx=(6, 0))
        tk.Button(self.content, text="💾 Save Branding",
                  bg=th["primary"], fg="white", relief="flat", pady=8,
                  command=self._save_branding).pack(fill="x", pady=(14, 0))

    def _save_branding(self):
        for key in ["university_name", "theme", "logo_path"]:
            self.save_setting(key, self.vars[key].get().strip())
        messagebox.showinfo("Saved", "Branding settings saved. Restart to apply theme.")

    # ── Section: Admin Account ────────────────────────────────────────────────
    def _show_admin_account(self):
        th = self.theme
        self._section_header("👤 Admin Account")
        for key, label, show in [
            ("admin_full_name",      "Display Name",     None),
            ("admin_new_password",   "New Password",     "*"),
            ("admin_confirm_password","Confirm Password", "*"),
        ]:
            self.vars[key] = tk.StringVar(
                value="" if "password" in key else self.setting("admin_full_name", "System Administrator")
            )
            tk.Label(self.content, text=label, bg=th["card"], fg=th["muted"]).pack(anchor="w", pady=(6, 2))
            tk.Entry(self.content, textvariable=self.vars[key], show=show,
                     bg=th["panel"], fg=th["text"],
                     insertbackground=th["text"], relief="flat").pack(fill="x", ipady=6)
        tk.Button(self.content, text="💾 Save Admin Account",
                  bg=th["primary"], fg="white", relief="flat", pady=8,
                  command=self._save_admin_account).pack(fill="x", pady=(14, 0))

    def _save_admin_account(self):
        name = self.vars["admin_full_name"].get().strip()
        pw   = self.vars["admin_new_password"].get()
        cpw  = self.vars["admin_confirm_password"].get()
        if name:
            self.save_setting("admin_full_name", name)
            self.db.execute("UPDATE users SET full_name=? WHERE username='admin'", (name,))
        if pw:
            if pw != cpw:
                messagebox.showerror("Error", "Passwords do not match.")
                return
            if len(pw) < 6:
                messagebox.showerror("Error", "Password must be at least 6 characters.")
                return
            self.db.execute("UPDATE users SET password_hash=? WHERE username='admin'",
                            (self.db.hash_password(pw),))
            self.vars["admin_new_password"].set("")
            self.vars["admin_confirm_password"].set("")
        messagebox.showinfo("Saved", "Admin account updated.")

    # ── Section: Teacher Management ───────────────────────────────────────────
    def _show_teacher_mgmt(self):
        th = self.theme
        self._section_header("👩‍🏫 Teacher Account Management")
        for key, label, default in [
            ("new_teacher_user", "New Teacher Username", ""),
            ("new_teacher_pass", "Password",             "teacher123"),
        ]:
            self.vars[key] = tk.StringVar(value=default)
            tk.Label(self.content, text=label, bg=th["card"], fg=th["muted"]).pack(anchor="w", pady=(6, 2))
            tk.Entry(self.content, textvariable=self.vars[key],
                     bg=th["panel"], fg=th["text"],
                     insertbackground=th["text"], relief="flat").pack(fill="x", ipady=6)
        row = tk.Frame(self.content, bg=th["card"])
        row.pack(fill="x", pady=(10, 0))
        tk.Button(row, text="➕ Add Teacher Login",
                  bg=th["accent"], fg="white", relief="flat", pady=8,
                  command=self._add_teacher_login).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Button(row, text="🗑 Remove Teacher Login",
                  bg=th["danger"], fg="white", relief="flat", pady=8,
                  command=self._remove_teacher_login).pack(side="left", fill="x", expand=True)

        tk.Label(self.content, text="Current Teacher Logins",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(16, 4))
        tree = ttk.Treeview(self.content, columns=("user", "name", "role"),
                            show="headings", height=8)
        for col, w in [("user", 130), ("name", 180), ("role", 90)]:
            tree.heading(col, text=col.title())
            tree.column(col, width=w)
        tree.pack(fill="x")
        rows = self.db.query("SELECT username, full_name, role FROM users WHERE role='Teacher' ORDER BY full_name")
        for r in rows:
            tree.insert("", "end", values=(r["username"], r["full_name"] or "", r["role"]))

    def _add_teacher_login(self):
        uname = self.vars["new_teacher_user"].get().strip()
        pw    = self.vars["new_teacher_pass"].get().strip()
        if not uname:
            messagebox.showerror("Error", "Username is required.")
            return
        if self.db.scalar("SELECT COUNT(*) FROM users WHERE username=?", (uname,)):
            messagebox.showerror("Error", f"Username '{uname}' already exists.")
            return
        self.db.execute(
            "INSERT INTO users(username,password_hash,role,full_name) VALUES (?,?,'Teacher',?)",
            (uname, self.db.hash_password(pw or "teacher123"), f"Teacher {uname}"),
        )
        messagebox.showinfo("Added", f"Teacher login '{uname}' created.")
        self.vars["new_teacher_user"].set("")
        self._show_teacher_mgmt()

    def _remove_teacher_login(self):
        uname = self.vars["new_teacher_user"].get().strip()
        if not uname:
            messagebox.showerror("Error", "Enter the username to remove.")
            return
        if uname == "admin":
            messagebox.showerror("Error", "Cannot remove admin account.")
            return
        rows = self.db.query("SELECT id, full_name FROM users WHERE username=? AND role='Teacher'", (uname,))
        if not rows:
            messagebox.showerror("Not Found", f"Teacher login '{uname}' not found.")
            return
        if messagebox.askyesno("Confirm", f"Remove teacher login '{uname}'?"):
            self.db.execute("DELETE FROM users WHERE username=?", (uname,))
            messagebox.showinfo("Removed", f"Teacher login '{uname}' removed.")
            self.vars["new_teacher_user"].set("")
            self._show_teacher_mgmt()

    # ── Section: Camera & Recognition ────────────────────────────────────────
    def _show_recognition(self):
        th = self.theme
        self._section_header("📷 Camera, QR & Face Settings")
        for key, label, default in [
            ("camera_index",                "Camera Index (0, 1, 2…)", "0"),
            ("qr_expiry_seconds",           "QR Expiry (seconds)",      "30"),
            ("face_threshold",              "Face Match Threshold (%)", "72"),
            ("passive_liveness_threshold",  "Liveness Threshold (%)",   "80"),
        ]:
            self.vars[key] = tk.StringVar(value=self.setting(key, default))
            tk.Label(self.content, text=label, bg=th["card"], fg=th["muted"]).pack(anchor="w", pady=(6, 2))
            tk.Entry(self.content, textvariable=self.vars[key],
                     bg=th["panel"], fg=th["text"],
                     insertbackground=th["text"], relief="flat").pack(fill="x", ipady=6)
        tk.Button(self.content, text="💾 Save Recognition Settings",
                  bg=th["primary"], fg="white", relief="flat", pady=8,
                  command=self._save_recognition).pack(fill="x", pady=(14, 0))

    def _save_recognition(self):
        try:
            int(self.vars["camera_index"].get())
            expiry = int(self.vars["qr_expiry_seconds"].get())
            thr    = float(self.vars["face_threshold"].get())
            if expiry < 5 or thr < 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("Validation", "All fields must be valid numbers.")
            return
        for key in ["camera_index", "qr_expiry_seconds", "face_threshold", "passive_liveness_threshold"]:
            self.save_setting(key, self.vars[key].get().strip())
        messagebox.showinfo("Saved", "Recognition settings saved.")

    # ── Section: Database & Data Tools ────────────────────────────────────────
    def _show_db_tools(self):
        th = self.theme
        self._section_header("🗄️ Database & Data Tools")
        tools = [
            ("📦 Backup SQLite Database",    self._backup,          th["accent"]),
            ("♻️  Restore SQLite Database",   self._restore,         th["warning"]),
            ("📤 Export Students CSV",        self._export_csv,      "#0891b2"),
            ("📥 Import Students from CSV",   self._import_csv,      "#7c3aed"),
            ("📦 Export ALL Data (ZIP)",      self._export_all_zip,  "#0d9488"),
            ("📥 Import ALL Data (ZIP)",      self._import_all_zip,  "#6366f1"),
        ]
        for text, cmd, color in tools:
            tk.Button(self.content, text=text, bg=color, fg="white",
                      relief="flat", pady=9, anchor="w", padx=14,
                      command=cmd).pack(fill="x", pady=3)

    def _backup(self):
        path = filedialog.asksaveasfilename(defaultextension=".db",
                                            filetypes=[("SQLite Database", "*.db")])
        if path:
            shutil.copy2(self.db.db_path, path)
            messagebox.showinfo("Backup Complete", path)

    def _restore(self):
        path = filedialog.askopenfilename(filetypes=[("SQLite Database", "*.db")])
        if path and messagebox.askyesno("Restore", "Replace active database? Restart required."):
            shutil.copy2(path, self.db.db_path)
            messagebox.showinfo("Restored", "Restart the app to apply.")

    def _export_csv(self):
        import csv
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        rows = self.db.query(
            "SELECT s.student_id,s.name,s.father_name,d.name program,s.semester,"
            "s.session,s.roll_number,s.section,s.phone,s.email,s.attendance_percentage "
            "FROM students s JOIN departments d ON d.id=s.department_id ORDER BY s.name"
        )
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Student ID", "Name", "Father Name", "Program", "Semester",
                             "Session", "Roll No", "Section", "Phone", "Email", "Attendance %"])
            for r in rows:
                writer.writerow([r[k] for k in r.keys()])
        messagebox.showinfo("Exported", f"Saved {len(rows)} students to:\n{path}")

    def _import_csv(self):
        import csv
        path = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if not path:
            return
        imported = skipped = 0
        depts = {r["name"]: r["id"] for r in self.db.query("SELECT id, name FROM departments")}
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                prog = row.get("Program", "").strip()
                dept_id = depts.get(prog)
                if not dept_id:
                    skipped += 1
                    continue
                try:
                    sem = int(row.get("Semester", 0))
                except ValueError:
                    skipped += 1
                    continue
                if sem not in (2, 4, 6, 8):
                    skipped += 1
                    continue
                ok, _ = self.db.add_student({
                    "student_id":    row.get("Student ID", "").strip(),
                    "name":          row.get("Name", "").strip(),
                    "father_name":   row.get("Father Name", "").strip(),
                    "department_id": dept_id,
                    "program":       prog,
                    "semester":      sem,
                    "session":       row.get("Session", "").strip(),
                    "roll_number":   row.get("Roll No", "").strip(),
                    "section":       row.get("Section", "A").strip() or "A",
                    "phone":         row.get("Phone", "").strip(),
                    "email":         row.get("Email", "").strip(),
                })
                if ok:
                    imported += 1
                else:
                    skipped += 1
        messagebox.showinfo("Import Complete",
                            f"Imported: {imported}  |  Skipped: {skipped}")

    def _export_all_zip(self):
        import csv, zipfile, io
        path = filedialog.asksaveasfilename(defaultextension=".zip",
                                            initialfile="university_data_export.zip",
                                            filetypes=[("ZIP", "*.zip")])
        if not path:
            return
        try:
            exports = {
                "students.csv": (
                    ["Student ID", "Name", "Father Name", "Program", "Semester",
                     "Session", "Roll No", "Section", "Phone", "Email", "Attendance %"],
                    self.db.query(
                        "SELECT s.student_id,s.name,s.father_name,d.name program,s.semester,"
                        "s.session,s.roll_number,s.section,s.phone,s.email,s.attendance_percentage "
                        "FROM students s JOIN departments d ON d.id=s.department_id ORDER BY s.name"
                    )
                ),
                "teachers.csv": (
                    ["Teacher ID", "Name", "Program", "Course Code", "Designation", "Phone", "Email"],
                    self.db.query(
                        "SELECT t.teacher_id,t.name,d.name program,t.course_code,"
                        "t.designation,t.phone,t.email "
                        "FROM teachers t LEFT JOIN departments d ON d.id=t.department_id ORDER BY t.name"
                    )
                ),
                "courses.csv": (
                    ["Course ID", "Subject", "Program", "Semester", "Section", "Credit Hours", "Teacher"],
                    self.db.query(
                        "SELECT c.course_id,c.subject_name,d.name program,c.semester,"
                        "c.section,c.credit_hours,t.name teacher "
                        "FROM courses c LEFT JOIN departments d ON d.id=c.department_id "
                        "LEFT JOIN teachers t ON t.teacher_id=c.teacher_id ORDER BY d.name,c.semester"
                    )
                ),
                "attendance.csv": (
                    ["Student ID", "Name", "Program", "Semester", "Section", "Course",
                     "Date", "Time", "Status", "Method"],
                    self.db.query(
                        "SELECT a.student_id,s.name,d.name program,s.semester,s.section,"
                        "c.subject_name course,a.date,a.time,a.status,a.method "
                        "FROM attendance a JOIN students s ON s.student_id=a.student_id "
                        "JOIN departments d ON d.id=s.department_id "
                        "JOIN courses c ON c.course_id=a.course_id "
                        "ORDER BY a.date DESC,a.time DESC"
                    )
                ),
            }
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                for filename, (headers, rows) in exports.items():
                    buf = io.StringIO()
                    csv.writer(buf).writerow(headers)
                    for r in rows:
                        csv.writer(buf).writerow([r[k] for k in r.keys()])
                    zf.writestr(filename, buf.getvalue())
            counts = {n: len(r) for n, (_, r) in exports.items()}
            messagebox.showinfo("Exported",
                                f"Saved to: {path}\n\n" +
                                "\n".join(f"  {n}: {c} rows" for n, c in counts.items()))
        except Exception as exc:
            messagebox.showerror("Export Failed", str(exc))

    def _import_all_zip(self):
        import csv, zipfile, io
        path = filedialog.askopenfilename(filetypes=[("ZIP", "*.zip"), ("All", "*.*")])
        if not path:
            return
        try:
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                imp_s = imp_a = skipped = 0
                depts = {r["name"]: r["id"] for r in self.db.query("SELECT id, name FROM departments")}
                if "students.csv" in names:
                    for row in csv.DictReader(io.StringIO(zf.read("students.csv").decode("utf-8"))):
                        prog = row.get("Program", "").strip()
                        dept_id = depts.get(prog)
                        if not dept_id:
                            skipped += 1
                            continue
                        try:
                            sem = int(row.get("Semester", 0))
                        except ValueError:
                            skipped += 1
                            continue
                        if sem not in (2, 4, 6, 8):
                            skipped += 1
                            continue
                        ok, _ = self.db.add_student({
                            "student_id":    row.get("Student ID", "").strip(),
                            "name":          row.get("Name", "").strip(),
                            "father_name":   row.get("Father Name", "").strip(),
                            "department_id": dept_id, "program": prog,
                            "semester": sem,
                            "session":       row.get("Session", "").strip(),
                            "roll_number":   row.get("Roll No", "").strip(),
                            "section":       row.get("Section", "A").strip() or "A",
                            "phone":         row.get("Phone", "").strip(),
                            "email":         row.get("Email", "").strip(),
                        })
                        imp_s += 1 if ok else 0
                        skipped += 0 if ok else 1
                if "attendance.csv" in names:
                    for row in csv.DictReader(io.StringIO(zf.read("attendance.csv").decode("utf-8"))):
                        sid  = row.get("Student ID", "").strip().upper()
                        subj = row.get("Course", "").strip()
                        cr   = self.db.query("SELECT course_id FROM courses WHERE subject_name=? LIMIT 1", (subj,))
                        cid  = cr[0]["course_id"] if cr else ""
                        if not sid or not cid:
                            skipped += 1
                            continue
                        ok, _ = self.db.mark_attendance(sid, cid, row.get("Status", "Present"), row.get("Method", "Manual"))
                        imp_a += 1 if ok else 0
                        skipped += 0 if ok else 1
            messagebox.showinfo("Import Complete",
                                f"Students: {imp_s}  |  Attendance: {imp_a}  |  Skipped: {skipped}")
        except Exception as exc:
            messagebox.showerror("Import Failed", str(exc))

    # ── Section: Security Center ──────────────────────────────────────────────
    def _show_security_center(self):
        th = self.theme
        self._section_header("🔒 Security Center")

        # Stats row
        stats_row = tk.Frame(self.content, bg=th["card"])
        stats_row.pack(fill="x", pady=(0, 10))
        def _safe_count(tbl):
            try:
                return self.db.scalar(f"SELECT COUNT(*) FROM {tbl}") or 0
            except Exception:
                return 0
        stats = [
            ("Liveness Logs",   _safe_count("liveness_logs"),   "#60a5fa"),
            ("Spoofing Logs",   _safe_count("spoofing_logs"),   "#fb7185"),
            ("Security Events", _safe_count("security_events"), "#fbbf24"),
            ("Face Attempts",   _safe_count("face_attempts"),   "#34d399"),
        ]
        for label, val, col in stats:
            c = tk.Frame(stats_row, bg=th["panel"], padx=10, pady=8)
            c.pack(side="left", fill="x", expand=True, padx=3)
            tk.Label(c, text=label, bg=th["panel"], fg=th["muted"],
                     font=("Segoe UI", 8)).pack(anchor="w")
            tk.Label(c, text=str(val), bg=th["panel"], fg=col,
                     font=("Segoe UI", 15, "bold")).pack(anchor="w")

        # Tabs
        nb = ttk.Notebook(self.content)
        nb.pack(fill="both", expand=True)
        for title, sql, cols in [
            ("Security Events",
             "SELECT created_at, event_type, student_id, course_id, failure_reason FROM security_events ORDER BY created_at DESC LIMIT 100",
             ("Time", "Event", "Student", "Course", "Reason")),
            ("Spoofing Logs",
             "SELECT created_at, student_id, attack_type, real_conf, fake_conf FROM spoofing_logs ORDER BY created_at DESC LIMIT 100",
             ("Time", "Student", "Attack Type", "Real%", "Fake%")),
            ("Liveness Logs",
             "SELECT created_at, student_id, course_id, real_confidence, fake_confidence, final_decision FROM liveness_logs ORDER BY created_at DESC LIMIT 100",
             ("Time", "Student", "Course", "Real%", "Fake%", "Decision")),
        ]:
            tab = tk.Frame(nb, bg=th["card"], padx=8, pady=8)
            nb.add(tab, text=title)
            tree = ttk.Treeview(tab, columns=cols, show="headings", height=10)
            for col in cols:
                tree.heading(col, text=col)
                tree.column(col, width=max(80, 140 if col in ("Time", "Reason") else 100))
            ysb = ttk.Scrollbar(tab, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=ysb.set)
            tree.pack(side="left", fill="both", expand=True)
            ysb.pack(side="right", fill="y")
            try:
                rows = self.db.query(sql)
                for r in rows:
                    tree.insert("", "end", values=[str(v or "")[:40] for v in r.values()])
            except Exception:
                pass

        # Thresholds sub-section
        tk.Label(self.content, text="Anti-Spoofing Thresholds",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(12, 4))
        for key, label in [("passive_liveness_threshold", "Liveness Threshold (%)"),
                           ("face_threshold",              "Face Match Threshold (%)")]:
            self.vars[key] = tk.StringVar(value=self.setting(key, "80"))
            row = tk.Frame(self.content, bg=th["card"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=label, bg=th["card"], fg=th["muted"], width=28, anchor="w").pack(side="left")
            tk.Entry(row, textvariable=self.vars[key],
                     bg=th["panel"], fg=th["text"],
                     insertbackground=th["text"], relief="flat", width=10).pack(side="left", ipady=5)
        tk.Button(self.content, text="💾 Save Thresholds",
                  bg=th["primary"], fg="white", relief="flat", pady=6,
                  command=lambda: (
                      self.save_setting("passive_liveness_threshold",
                                        self.vars["passive_liveness_threshold"].get()),
                      self.save_setting("face_threshold", self.vars["face_threshold"].get()),
                      messagebox.showinfo("Saved", "Security thresholds updated."),
                  )).pack(anchor="w", pady=(6, 0))

    # ── Section: All Users ────────────────────────────────────────────────────
    def _show_all_users(self):
        th = self.theme
        self._section_header("👥 All Users")

        cols = ("Username", "Full Name", "Role", "Linked ID")
        tree = ttk.Treeview(self.content, columns=cols, show="headings", height=18)
        for col, w in [("Username", 130), ("Full Name", 200), ("Role", 90), ("Linked ID", 150)]:
            tree.heading(col, text=col)
            tree.column(col, width=w)
        ysb = ttk.Scrollbar(self.content, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ysb.set)
        tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        tree.tag_configure("admin",   foreground="#f59e0b")
        tree.tag_configure("teacher", foreground="#38bdf8")

        rows = self.db.query(
            "SELECT username, full_name, role, linked_id FROM users ORDER BY role, full_name"
        )
        for r in rows:
            tag = "admin" if r["role"] == "Admin" else "teacher"
            tree.insert("", "end",
                        values=(r["username"], r["full_name"] or "", r["role"], r["linked_id"] or ""),
                        tags=(tag,))
        tk.Label(self.content,
                 text=f"Total users: {len(rows)}  |  "
                      f"Admin: {sum(1 for r in rows if r['role']=='Admin')}  |  "
                      f"Teachers: {sum(1 for r in rows if r['role']=='Teacher')}",
                 bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 9)).pack(side="bottom", anchor="w", pady=(4, 0))

    # ── Helper ────────────────────────────────────────────────────────────────
    def _section_header(self, title: str):
        th = self.theme
        tk.Label(self.content, text=title,
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(0, 10))
        tk.Frame(self.content, bg=th["primary"], height=2).pack(fill="x", pady=(0, 12))
