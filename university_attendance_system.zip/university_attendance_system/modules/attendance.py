"""
University Attendance System — attendance.py
Face Registration, Face Attendance, QR Code, Manual, Report.
"""
from __future__ import annotations

import csv
import datetime
import json
import socket
import time as _time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from modules.face_system import FaceEngine, LivenessDetector, decode_qr_from_image, ensure_cv


class AttendanceFrame(tk.Frame):
    # ─────────────────────────────────────────────────────────────────────────
    # INIT
    # ─────────────────────────────────────────────────────────────────────────
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db          = db
        self.user        = user
        self.theme       = theme
        self.cap         = None
        self.cv2         = None
        self.camera_job  = None
        self.engine      = None
        self.qr_tick_job = None          # must exist for _stop_qr
        self._alive      = True
        self.bind("<Destroy>", lambda _e: self._on_destroy())
        self.build()

    def _on_destroy(self):
        self._alive = False
        self.stop_camera()
        self._stop_qr()

    # ─────────────────────────────────────────────────────────────────────────
    # BUILD UI
    # ─────────────────────────────────────────────────────────────────────────
    def build(self):
        th = self.theme

        # Title
        tk.Label(self, text="University Attendance System",
                 bg=th["bg"], fg=th["text"],
                 font=("Segoe UI", 20, "bold")).pack(anchor="w")
        tk.Label(self, text="Select a course and date, then choose an attendance method below.",
                 bg=th["bg"], fg=th["muted"]).pack(anchor="w")

        # ── Course + Date selector ────────────────────────────────────────────
        sel = tk.Frame(self, bg=th["card"], padx=14, pady=10)
        sel.pack(fill="x", pady=(10, 4))

        tk.Label(sel, text="Course:", bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 10, "bold")).pack(side="left")

        courses = [
            f"{r['course_id']} — {r['subject_name']}  (Sem {r['semester']} {r['section']})"
            for r in self.db.query(
                "SELECT course_id, subject_name, semester, section "
                "FROM courses ORDER BY semester, course_id"
            )
        ]
        self.course_var = tk.StringVar()
        self.course_cb  = ttk.Combobox(sel, textvariable=self.course_var,
                                        values=courses, state="readonly", width=50)
        self.course_cb.pack(side="left", padx=(6, 20))
        if courses:
            self.course_cb.current(0)

        tk.Label(sel, text="Date:", bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        self.date_var = tk.StringVar(value=datetime.date.today().isoformat())
        tk.Entry(sel, textvariable=self.date_var,
                 bg=th["panel"], fg=th["text"], insertbackground=th["text"],
                 relief="flat", width=13, font=("Segoe UI", 10)).pack(
            side="left", padx=6, ipady=4)

        # ── Method cards ──────────────────────────────────────────────────────
        CARDS = [
            ("Face\nAttendance",  "#7c3aed", "Auto-detect faces\n& mark attendance", self._open_face_attendance),
            ("Register\nFace",    "#0891b2", "Enroll student\nface via live camera", self._open_face_register),
            ("QR Code\nAttendance","#8b5cf6", "Session QR code\nfor whole class",    self._open_qr_session),
            ("Manual\nAttendance","#10b981", "Double-click rows\nPresent / Absent",  self._open_manual),
            ("Attendance\nReport", "#0ea5e9", "Monthly summary\n& CSV export",       self._open_report),
        ]
        cards_row = tk.Frame(self, bg=th["bg"])
        cards_row.pack(fill="x", pady=6)
        for i, (title, color, desc, cmd) in enumerate(CARDS):
            c = tk.Frame(cards_row, bg=th["card"], padx=10, pady=10)
            c.grid(row=0, column=i, sticky="nsew", padx=4)
            cards_row.grid_columnconfigure(i, weight=1)
            tk.Label(c, text=title, font=("Segoe UI", 10, "bold"),
                     bg=th["card"], fg="white", justify="center").pack(pady=(0, 4))
            tk.Button(c, text="Open", bg=color, fg="white",
                      font=("Segoe UI", 9, "bold"), relief="flat",
                      padx=12, pady=5, command=cmd).pack()
            tk.Label(c, text=desc, bg=th["card"], fg=th["muted"],
                     font=("Segoe UI", 7), justify="center", wraplength=110).pack(pady=(4, 0))

        # ── Stats bar ─────────────────────────────────────────────────────────
        self.stats_bar = tk.Frame(self, bg=th["bg"])
        self.stats_bar.pack(fill="x", pady=(4, 0))
        self._refresh_stats()

        # ── Work area ─────────────────────────────────────────────────────────
        self.work_area = tk.Frame(self, bg=th["card"], padx=14, pady=10)
        self.work_area.pack(fill="both", expand=True, pady=(6, 0))
        tk.Label(self.work_area,
                 text="Select a method above to begin.",
                 bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 12)).pack(anchor="w", pady=20)

    # ─────────────────────────────────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────────────────────────────────
    def _refresh_stats(self):
        for w in self.stats_bar.winfo_children():
            w.destroy()
        th = self.theme
        try:
            stats = [
                ("Today",  self.db.scalar("SELECT COUNT(*) FROM attendance WHERE date=date('now','localtime') AND status='Present'") or 0, "#60a5fa"),
                ("Face",   self.db.scalar("SELECT COUNT(*) FROM attendance WHERE method='Face' AND status='Present'") or 0,   "#34d399"),
                ("QR",     self.db.scalar("SELECT COUNT(*) FROM attendance WHERE method='QR' AND status='Present'") or 0,     "#fbbf24"),
                ("Manual", self.db.scalar("SELECT COUNT(*) FROM attendance WHERE method='Manual' AND status='Present'") or 0, "#a78bfa"),
            ]
        except Exception:
            stats = [("Today", 0, "#60a5fa"), ("Face", 0, "#34d399"), ("QR", 0, "#fbbf24"), ("Manual", 0, "#a78bfa")]
        for label, val, col in stats:
            c = tk.Frame(self.stats_bar, bg=th["card"], padx=12, pady=8)
            c.pack(side="left", fill="x", expand=True, padx=4)
            tk.Label(c, text=label, bg=th["card"], fg=th["muted"],
                     font=("Segoe UI", 8, "bold")).pack(anchor="w")
            tk.Label(c, text=str(val), bg=th["card"], fg=col,
                     font=("Segoe UI", 16, "bold")).pack(anchor="w")

    def _selected_course_id(self):
        v = self.course_var.get()
        if not v:
            messagebox.showerror("Select Course", "Please select a course first.")
            return None
        return v.split(" — ")[0].strip()

    def _selected_date(self):
        d = self.date_var.get().strip()
        try:
            datetime.datetime.strptime(d, "%Y-%m-%d")
            return d
        except ValueError:
            messagebox.showerror("Invalid Date", "Date must be YYYY-MM-DD.")
            return None

    def _course_label(self):
        v = self.course_var.get()
        return v.split(" — ", 1)[1].strip() if " — " in v else v

    def _get_students(self, cid):
        return self.db.query(
            "SELECT s.student_id, s.name, s.roll_number, s.section, s.semester, d.name program "
            "FROM courses c "
            "JOIN students s ON s.semester=c.semester AND s.section=c.section "
            "JOIN departments d ON d.id=s.department_id "
            "WHERE c.course_id=? "
            "ORDER BY s.roll_number, s.name",
            (cid,),
        )

    def _clear_work(self):
        for w in self.work_area.winfo_children():
            w.destroy()

    def _get_local_ip(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except OSError:
            return "127.0.0.1"

    # ── Camera management ─────────────────────────────────────────────────────
    def open_camera(self) -> bool:
        """Open webcam — no blocking warmup. Frame loop handles bad frames."""
        self.stop_camera()
        cv2_m, _ = ensure_cv()
        if cv2_m is None:
            messagebox.showerror("OpenCV Missing",
                                 "Run:  pip install opencv-python\nThen restart.")
            return False
        self.cv2 = cv2_m
        cam_idx = int(
            self.db.scalar("SELECT value FROM settings WHERE key='camera_index'") or 0
        )
        # Try camera indexes in order: configured, 0, 1
        for idx in ([cam_idx] if cam_idx == 0 else [cam_idx, 0, 1]):
            for backend in ([cv2_m.CAP_DSHOW, cv2_m.CAP_ANY]
                            if hasattr(cv2_m, "CAP_DSHOW")
                            else [cv2_m.CAP_ANY]):
                try:
                    cap = cv2_m.VideoCapture(idx, backend)
                    if cap.isOpened():
                        cap.set(cv2_m.CAP_PROP_FRAME_WIDTH,  640)
                        cap.set(cv2_m.CAP_PROP_FRAME_HEIGHT, 480)
                        self.cap = cap
                        return True        # let _frame handle warmup
                    try:
                        cap.release()
                    except Exception:
                        pass
                except Exception:
                    pass
        return False


    def stop_camera(self):
        if self.camera_job:
            try:
                self.after_cancel(self.camera_job)
            except Exception:
                pass
            self.camera_job = None
        if self.cap is not None:
            try:
                self.cap.release()
            except Exception:
                pass
            self.cap = None

    def _stop_qr(self):
        """Stop the QR ticker (safe to call even if never started)."""
        if self.qr_tick_job is not None:
            try:
                self.after_cancel(self.qr_tick_job)
            except Exception:
                pass
            self.qr_tick_job = None

    def get_engine(self) -> FaceEngine:
        if self.engine is None:
            cam = int(self.db.scalar("SELECT value FROM settings WHERE key='camera_index'") or 0)
            thr = float(self.db.scalar("SELECT value FROM settings WHERE key='face_threshold'") or 72)
            self.engine = FaceEngine(camera_index=cam, threshold=thr)
        return self.engine

    def _render(self, label, frame, w=580, h=380):
        try:
            from PIL import Image, ImageTk
            rgb = self.cv2.cvtColor(frame, self.cv2.COLOR_BGR2RGB)
            ph  = ImageTk.PhotoImage(Image.fromarray(rgb).resize((w, h)))
            label.config(image=ph, text="")
            label._img = ph
        except Exception:
            pass

    # ═════════════════════════════════════════════════════════════════════════
    # 1.  FACE REGISTRATION
    # ═════════════════════════════════════════════════════════════════════════
    def _open_face_register(self):
        self._stop_qr()
        self.stop_camera()

        cid = self._selected_course_id()
        if not cid:
            return
        students = self._get_students(cid)
        if not students:
            messagebox.showinfo("No Students", "No students found for this course.")
            return

        th  = self.theme
        win = tk.Toplevel(self)
        win.title("Face ID Registration")
        win.geometry("960x660")
        win.configure(bg="#0f172a")
        win.resizable(True, True)
        win.transient(self)
        win.grab_set()

        # Header
        hdr = tk.Frame(win, bg="#0891b2", padx=18, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Face ID Registration",
                 font=("Segoe UI", 16, "bold"), bg="#0891b2", fg="white").pack(side="left")
        tk.Label(hdr,
                 text=self._course_label() + "  |  30 samples  5 angles  live camera only",
                 font=("Segoe UI", 9), bg="#0891b2", fg="#e0f2fe").pack(side="left", padx=14)
        tk.Button(hdr, text="Close", bg="#374151", fg="white",
                  relief="flat", padx=12, pady=4,
                  command=lambda: _close()).pack(side="right")

        body = tk.Frame(win, bg="#0f172a")
        body.pack(fill="both", expand=True)

        # ── LEFT: student finder ──────────────────────────────────────────────
        lf = tk.Frame(body, bg="#1e293b", width=310)
        lf.pack(side="left", fill="y")
        lf.pack_propagate(False)

        tk.Label(lf, text="Step 1  —  Find Student",
                 font=("Segoe UI", 12, "bold"), bg="#1e293b", fg="white").pack(
            anchor="w", padx=14, pady=(14, 4))
        tk.Frame(lf, bg="#0891b2", height=2).pack(fill="x", padx=12, pady=(0, 10))

        # Semester
        tk.Label(lf, text="Semester", bg="#1e293b", fg="#94a3b8",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14)
        sem_v = tk.StringVar(value="All")
        sems  = sorted({str(s["semester"]) for s in students})
        ttk.Combobox(lf, textvariable=sem_v,
                     values=["All"] + sems, state="readonly",
                     width=26).pack(padx=14, pady=(2, 8), fill="x")

        # Roll number
        tk.Label(lf, text="Roll Number", bg="#1e293b", fg="#94a3b8",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14)
        roll_v = tk.StringVar()
        tk.Entry(lf, textvariable=roll_v, bg="#111827", fg="#e5e7eb",
                 insertbackground="#e5e7eb", relief="flat",
                 font=("Segoe UI", 11)).pack(padx=14, pady=(2, 8), fill="x", ipady=6)

        # Name
        tk.Label(lf, text="Name (type to search)", bg="#1e293b", fg="#94a3b8",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14)
        name_v = tk.StringVar()
        tk.Entry(lf, textvariable=name_v, bg="#111827", fg="#e5e7eb",
                 insertbackground="#e5e7eb", relief="flat",
                 font=("Segoe UI", 11)).pack(padx=14, pady=(2, 8), fill="x", ipady=6)

        tk.Button(lf, text="Search", bg="#2563eb", fg="white",
                  relief="flat", font=("Segoe UI", 10, "bold"), pady=8,
                  command=lambda: _search()).pack(padx=14, fill="x")

        # Student list
        tk.Label(lf, text="Students (click to select)",
                 bg="#1e293b", fg="#94a3b8",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(10, 2))
        list_wrap = tk.Frame(lf, bg="#1e293b")
        list_wrap.pack(fill="both", expand=True, padx=12, pady=(0, 6))
        lb     = tk.Listbox(list_wrap, bg="#111827", fg="#e5e7eb",
                            selectbackground="#2563eb", font=("Segoe UI", 9),
                            relief="flat", activestyle="none", height=10)
        lb_sb  = ttk.Scrollbar(list_wrap, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=lb_sb.set)
        lb_sb.pack(side="right", fill="y")
        lb.pack(fill="both", expand=True)

        info_v = tk.StringVar(value="No student selected.")
        tk.Label(lf, textvariable=info_v, bg="#1e293b", fg="#38bdf8",
                 font=("Segoe UI", 8), wraplength=280, justify="left").pack(
            padx=14, pady=(0, 6))

        cam_btn = tk.Button(lf,
                            text="Step 2: Start Camera",
                            bg="#10b981", fg="white", relief="flat",
                            font=("Segoe UI", 11, "bold"), pady=10,
                            state="disabled",
                            command=lambda: _start_camera())
        cam_btn.pack(padx=12, pady=(2, 12), fill="x")

        # ── RIGHT: camera + progress ──────────────────────────────────────────
        rf = tk.Frame(body, bg="#0f172a")
        rf.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        cam_lbl = tk.Label(rf,
                           text="Select a student on the left,\nthen click 'Start Camera'.",
                           bg="#0f172a", fg="#94a3b8",
                           font=("Segoe UI", 13), justify="center")
        cam_lbl.pack(expand=True, fill="both")

        stage_lbl = tk.Label(rf, text="", font=("Segoe UI", 13, "bold"),
                             bg="#0f172a", fg="#38bdf8", wraplength=520)
        stage_lbl.pack()

        # Progress bar
        bar_cv  = tk.Canvas(rf, height=16, bg="#0f172a", highlightthickness=0)
        bar_cv.pack(fill="x", padx=20, pady=4)
        bar_txt = tk.Label(rf, text="", font=("Segoe UI", 9),
                           bg="#0f172a", fg="#38bdf8")
        bar_txt.pack()

        STAGES = [
            ("Look Straight",      "#38bdf8", "Look directly at the camera"),
            ("Turn Slightly Left",  "#a78bfa", "Turn your head slightly to the left"),
            ("Turn Slightly Right", "#34d399", "Turn your head slightly to the right"),
            ("Tilt Slightly Up",    "#fbbf24", "Look slightly upward"),
            ("Tilt Slightly Down",  "#f472b6", "Lower your gaze slightly"),
        ]
        SPG   = 6
        TOTAL = len(STAGES) * SPG   # 30 samples

        dots_row = tk.Frame(rf, bg="#0f172a")
        dots_row.pack(pady=4)
        dot_labels = []
        for sg_name, sg_col, _ in STAGES:
            d = tk.Label(dots_row, text=sg_name,
                         font=("Segoe UI", 8), bg="#0f172a",
                         fg="#334155", padx=4)
            d.pack(side="left")
            dot_labels.append((d, sg_col))

        st_lbl = tk.Label(rf, text="", font=("Segoe UI", 9),
                          bg="#0f172a", fg="#64748b")
        st_lbl.pack(pady=2)

        def _draw_bar(done):
            bar_cv.delete("all")
            w = bar_cv.winfo_width() or 500
            bar_cv.create_rectangle(0, 2, w, 14, fill="#1e293b", outline="")
            fw = int(w * done / TOTAL)
            if fw > 0:
                col = "#34d399" if done < TOTAL else "#fbbf24"
                bar_cv.create_rectangle(0, 2, fw, 14, fill=col, outline="")
            bar_txt.config(text=f"{done} / {TOTAL} samples")

        # State
        win._open = True
        win._job  = None
        selected  = {"sid": None, "name": None}
        samps     = []
        stage_state = {"i": 0, "c": 0, "f": 0, "done": False}
        shown     = list(students)

        def _populate(lst):
            lb.delete(0, "end")
            for s in lst:
                has = bool(self.db.scalar(
                    "SELECT COUNT(*) FROM face_data "
                    "WHERE owner_type='Student' AND owner_id=?",
                    (s["student_id"],),
                ))
                tag = " [Face OK]" if has else ""
                lb.insert("end",
                          f"Roll {s['roll_number'] or '-'}  {s['name']}{tag}")
        _populate(shown)

        def _search():
            sem  = sem_v.get()
            roll = roll_v.get().strip()
            nm   = name_v.get().strip().lower()
            res  = [s for s in students
                    if (sem == "All" or str(s["semester"]) == sem)
                    and (not roll or str(s["roll_number"] or "") == roll)
                    and (not nm   or nm in s["name"].lower())]
            shown.clear(); shown.extend(res)
            _populate(res)
            info_v.set(f"{len(res)} student(s) found." if res else "No match.")

        def _on_select(_event=None):
            idx = lb.curselection()
            if not idx:
                return
            s = shown[idx[0]]
            selected["sid"]  = s["student_id"]
            selected["name"] = s["name"]
            has = bool(self.db.scalar(
                "SELECT COUNT(*) FROM face_data "
                "WHERE owner_type='Student' AND owner_id=?",
                (s["student_id"],),
            ))
            info_v.set(
                f"{s['name']}\nID: {s['student_id']}  "
                f"Sem {s['semester']} {s['section']}\n"
                + ("Face ID already registered." if has else "No face data yet.")
            )
            cam_btn.config(state="normal")
            samps.clear()
            stage_state.update({"i": 0, "c": 0, "f": 0, "done": False})
            for d, _ in dot_labels:
                d.config(fg="#334155")
            _draw_bar(0)
            cam_lbl.config(image="",
                           text=f"Click 'Start Camera' to enroll\n{s['name']}",
                           fg="#38bdf8", font=("Segoe UI", 13))
            stage_lbl.config(text="")
            bar_txt.config(text="")
            st_lbl.config(text="")

        lb.bind("<<ListboxSelect>>", _on_select)

        def _close():
            win._open = False
            self.stop_camera()
            if win._job:
                try:
                    win.after_cancel(win._job)
                except Exception:
                    pass
            if win.winfo_exists():
                win.grab_release()
                win.destroy()

        def _start_camera():
            if not selected["sid"]:
                messagebox.showwarning("Select Student",
                                       "Click a student in the list first.",
                                       parent=win)
                return
            samps.clear()
            stage_state.update({"i": 0, "c": 0, "f": 0, "done": False})
            for d, _ in dot_labels:
                d.config(fg="#334155")
            _draw_bar(0)
            cam_lbl.config(image="", text="Opening camera…",
                           fg="#94a3b8", font=("Segoe UI", 12))
            cam_btn.config(state="disabled", text="Camera running…")
            st_lbl.config(text="")
            if not self.open_camera():
                cam_btn.config(state="normal",
                               text="Step 2: Start Camera")
                cam_lbl.config(text="Camera not found.\nCheck Settings → Camera Index.",
                               fg="#fb7185")
                return
            st_lbl.config(text="Stage 1/5: Look Straight", fg="#38bdf8")
            win._job = win.after(30, _capture)

        def _capture():
            if not win._open or not win.winfo_exists() or stage_state["done"]:
                return
            if self.cap is None:
                win._job = win.after(200, _capture)
                return
            ok, frame = self.cap.read()
            if not ok or frame is None:
                win._job = win.after(100, _capture)
                return

            engine = self.get_engine()
            cv2_l  = self.cv2
            gray   = cv2_l.cvtColor(frame, cv2_l.COLOR_BGR2GRAY)
            # Use equalized version for face detection (Haar cascade works better),
            # but keep the original for ROI extraction. normalize_face then applies
            # CLAHE on just the face region, which is stable across different
            # backgrounds and lighting — unlike a second global equalizeHist.
            gray_eq = cv2_l.equalizeHist(gray)
            faces   = engine.detect_faces(gray_eq)   # returns list of (x,y,w,h)

            si    = stage_state["i"]
            sg_name, sg_col, sg_hint = STAGES[si]
            stage_lbl.config(text=sg_hint, fg=sg_col)

            if len(faces) > 0:
                x, y, w, h = sorted(faces,
                                    key=lambda r: r[2] * r[3],
                                    reverse=True)[0]
                roi = gray[y:y + h, x:x + w]   # crop from ORIGINAL (not equalized)

                stage_state["f"] += 1
                if stage_state["f"] % 4 == 0 and stage_state["c"] < SPG:
                    # Store a normalised face crop for the LBPH recognizer.
                    samps.append(engine.normalize_face(roi))
                    stage_state["c"] += 1
                    _draw_bar(len(samps))

                    if stage_state["c"] >= SPG:
                        dot_labels[si][0].config(
                            text=f"✓ {sg_name}", fg=sg_col)
                        stage_state["i"] += 1
                        stage_state["c"]  = 0
                        if stage_state["i"] >= len(STAGES):
                            _save_face()
                            return
                        nxt = STAGES[stage_state["i"]]
                        st_lbl.config(
                            text=f"Stage {stage_state['i']+1}/5: {nxt[0]}",
                            fg=nxt[1])

                hx  = sg_col.lstrip("#")
                bgr = (int(hx[4:6], 16), int(hx[2:4], 16), int(hx[0:2], 16))
                cv2_l.rectangle(frame, (x, y), (x + w, y + h), bgr, 3)
                cv2_l.putText(frame,
                              f"{sg_name}  {stage_state['c']}/{SPG}",
                              (x, max(22, y - 10)),
                              cv2_l.FONT_HERSHEY_SIMPLEX, 0.65, bgr, 2)
            else:
                cv2_l.putText(frame, "No face — move closer to camera",
                              (18, 36), cv2_l.FONT_HERSHEY_SIMPLEX,
                              0.7, (80, 80, 220), 2)

            self._render(cam_lbl, frame, 580, 380)
            win._job = win.after(30, _capture)

        def _save_face():
            stage_state["done"] = True
            self.stop_camera()
            engine = self.get_engine()
            self.db.execute(
                "INSERT INTO face_data(owner_type, owner_id, feature_json, image_path) "
                "VALUES ('Student', ?, ?, '') "
                "ON CONFLICT(owner_type, owner_id) "
                "DO UPDATE SET feature_json=excluded.feature_json, image_path=''",
                (selected["sid"], engine.encode_face_samples(samps)),
            )
            _draw_bar(TOTAL)
            cam_lbl.config(image="",
                           text=f"Face ID Enrolled!\n{selected['name']}",
                           fg="#34d399", font=("Segoe UI", 16, "bold"))
            stage_lbl.config(text=f"{len(samps)} samples saved.", fg="#34d399")
            st_lbl.config(text="")
            cam_btn.config(state="normal", text="Step 2: Start Camera")
            _populate(shown)     # refresh list to show [Face OK] tag
            messagebox.showinfo("Face ID Saved",
                                f"Face ID registered for {selected['name']}.\n"
                                "They can now be identified in Face Attendance.",
                                parent=win)

        win.protocol("WM_DELETE_WINDOW", _close)

    # ═════════════════════════════════════════════════════════════════════════
    # 2.  FACE ATTENDANCE  (auto-detect, phone face-lock style)
    # ═════════════════════════════════════════════════════════════════════════
    def _open_face_attendance(self):
        """
        Face Attendance with explicit Start/Stop camera button.
        Loads all registered faces for the course and auto-marks
        attendance when a face is confidently matched.
        """
        self._stop_qr()
        self.stop_camera()

        cid  = self._selected_course_id()
        date = self._selected_date()
        if not cid or not date:
            return

        cv2_test, _ = ensure_cv()
        if cv2_test is None:
            messagebox.showerror("OpenCV Missing",
                                 "Run:  pip install opencv-python\nThen restart.")
            return

        students = self._get_students(cid)
        if not students:
            messagebox.showinfo("No Students", "No students in this course.")
            return

        engine = self.get_engine()
        all_known = {}
        for stu in students:
            row = self.db.query(
                "SELECT feature_json FROM face_data "
                "WHERE owner_type='Student' AND owner_id=?",
                (stu["student_id"],),
            )
            if row:
                try:
                    payload = FaceEngine.decode_face_payload(row[0]["feature_json"])
                    if payload.get("crops"):
                        all_known[stu["student_id"]] = payload
                except Exception:
                    pass

        if not all_known:
            messagebox.showerror(
                "No Face Data",
                "No students in this class have a registered Face ID.\n\n"
                "Note: face enrolment was upgraded — anyone enrolled on an "
                "older version must Register Face again.\n\n"
                "Go to Attendance → Register Face and enroll students first.",
            )
            return

        # Train the LBPH recognizer once from all enrolled crops.
        recognizer, label_to_sid = engine.build_recognizer(all_known)
        if recognizer is None:
            messagebox.showerror(
                "Face Recognition Unavailable",
                "The face recognizer could not be initialised.\n\n"
                "Make sure 'opencv-contrib-python' is installed:\n"
                "    pip install opencv-contrib-python\n"
                "then restart the application.",
            )
            return

        already = set()
        for stu in students:
            if self.db.scalar(
                "SELECT status FROM attendance "
                "WHERE student_id=? AND course_id=? AND date=?",
                (stu["student_id"], cid, date),
            ) == "Present":
                already.add(stu["student_id"])

        th  = self.theme
        win = tk.Toplevel(self)
        win.title("Face Attendance - " + self._course_label() + " - " + date)
        win.geometry("980x660")
        win.configure(bg="#0f172a")
        win.transient(self)

        # Header
        hdr = tk.Frame(win, bg="#7c3aed", padx=18, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Face ID Attendance",
                 font=("Segoe UI", 15, "bold"), bg="#7c3aed", fg="white").pack(side="left")
        tk.Label(hdr,
                 text=self._course_label() + "  |  " + date +
                      "  |  " + str(len(all_known)) + " face(s) loaded",
                 font=("Segoe UI", 9), bg="#7c3aed", fg="#ddd6fe").pack(side="left", padx=14)

        body = tk.Frame(win, bg="#0f172a")
        body.pack(fill="both", expand=True)

        # LEFT: camera area
        lf = tk.Frame(body, bg="#0f172a")
        lf.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        cam_lbl = tk.Label(
            lf,
            text="Click 'Start Camera' to begin face scanning.",
            bg="#0f172a", fg="#94a3b8",
            font=("Segoe UI", 13), justify="center",
        )
        cam_lbl.pack(expand=True, fill="both")

        result_v = tk.StringVar(value="")
        result_lbl = tk.Label(lf, textvariable=result_v,
                              font=("Segoe UI", 14, "bold"),
                              bg="#0f172a", fg="#a78bfa", wraplength=580)
        result_lbl.pack(pady=6)

        info_v = tk.StringVar(value="")
        tk.Label(lf, textvariable=info_v, font=("Segoe UI", 9),
                 bg="#0f172a", fg="#475569").pack()

        # Camera control buttons
        btn_row = tk.Frame(lf, bg="#0f172a")
        btn_row.pack(pady=8)

        start_btn = tk.Button(btn_row, text="Start Camera",
                              bg="#10b981", fg="white", relief="flat",
                              font=("Segoe UI", 12, "bold"), padx=20, pady=9)
        start_btn.pack(side="left", padx=6)

        stop_btn = tk.Button(btn_row, text="Stop Camera",
                             bg="#dc2626", fg="white", relief="flat",
                             font=("Segoe UI", 12, "bold"), padx=20, pady=9,
                             state="disabled")
        stop_btn.pack(side="left", padx=6)

        # RIGHT: student list
        rf = tk.Frame(body, bg="#1e293b", width=270)
        rf.pack(side="right", fill="y", padx=(0, 10), pady=10)
        rf.pack_propagate(False)

        tk.Label(rf, text="Class Attendance",
                 font=("Segoe UI", 11, "bold"), bg="#1e293b", fg="white").pack(pady=(10, 2))
        prog_lbl = tk.Label(rf,
                            text="Marked: " + str(len(already)) + "/" + str(len(students)),
                            font=("Segoe UI", 10, "bold"), bg="#1e293b", fg="#38bdf8")
        prog_lbl.pack()
        tk.Frame(rf, bg="#7c3aed", height=2).pack(fill="x", padx=8, pady=(4, 6))

        lst_cv = tk.Canvas(rf, bg="#1e293b", highlightthickness=0)
        lst_sb = ttk.Scrollbar(rf, orient="vertical", command=lst_cv.yview)
        lst_cv.configure(yscrollcommand=lst_sb.set)
        lst_sb.pack(side="right", fill="y")
        lst_cv.pack(fill="both", expand=True, padx=4)
        inner = tk.Frame(lst_cv, bg="#1e293b")
        wid   = lst_cv.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: lst_cv.configure(scrollregion=lst_cv.bbox("all")))
        lst_cv.bind("<Configure>",
                    lambda e: lst_cv.itemconfigure(wid, width=e.width))

        row_lbls = {}
        for stu in students:
            marked   = stu["student_id"] in already
            has_face = stu["student_id"] in all_known
            icon = "v" if marked else ("?" if has_face else "x")
            rw = tk.Frame(inner, bg="#1e293b")
            rw.pack(fill="x", pady=1, padx=4)
            lb = tk.Label(rw,
                          text=icon + "  " + stu["name"],
                          font=("Segoe UI", 9), bg="#1e293b",
                          fg="#22c55e" if marked else ("#94a3b8" if has_face else "#475569"),
                          anchor="w")
            lb.pack(fill="x")
            row_lbls[stu["student_id"]] = lb

        def _mark_row(sid, name):
            already.add(sid)
            if sid in row_lbls:
                row_lbls[sid].config(text="v  " + name, fg="#22c55e")
            prog_lbl.config(text="Marked: " + str(len(already)) + "/" + str(len(students)))

        # State
        win._running  = False
        win._job      = None
        confirm       = {}
        last_marked   = {}
        bad_frames    = [0]

        def _do_stop():
            win._running = False
            if win._job:
                try:
                    win.after_cancel(win._job)
                except Exception:
                    pass
                win._job = None
            self.stop_camera()
            start_btn.config(state="normal")
            stop_btn.config(state="disabled")
            cam_lbl.config(image="", text="Camera stopped. Click Start to resume.",
                           fg="#94a3b8", font=("Segoe UI", 12))
            info_v.set("")

        def _do_start():
            start_btn.config(state="disabled")
            cam_lbl.config(image="", text="Opening camera, please wait...",
                           fg="#fbbf24", font=("Segoe UI", 12))
            win.update()   # force UI refresh before blocking call

            opened = self.open_camera()
            if not opened:
                cam_lbl.config(
                    image="",
                    text="Camera not found.\n\n"
                         "• Make sure camera is plugged in\n"
                         "• Close Teams/Zoom if open\n"
                         "• Try Settings  Camera Index  0 or 1",
                    fg="#fb7185", font=("Segoe UI", 11),
                )
                start_btn.config(state="normal")
                return

            bad_frames[0] = 0
            confirm.clear()
            win._running = True
            stop_btn.config(state="normal")
            result_v.set("Scanning for faces...")
            cam_lbl.config(image="", text="", fg="#94a3b8")
            win._job = win.after(50, _frame)

        start_btn.config(command=_do_start)
        stop_btn.config(command=_do_stop)

        def _frame():
            if not win._running or not win.winfo_exists():
                return

            if self.cap is None:
                _do_stop()
                return

            ok, frame = self.cap.read()

            # Handle bad/empty frames gracefully (common during camera warmup)
            if not ok or frame is None or frame.size == 0:
                bad_frames[0] += 1
                if bad_frames[0] > 30:   # give up after 30 consecutive bad frames
                    _do_stop()
                    cam_lbl.config(
                        image="",
                        text="Camera stopped producing frames.\n"
                             "Try Stop then Start again.",
                        fg="#fb7185", font=("Segoe UI", 11),
                    )
                    return
                win._job = win.after(100, _frame)
                return

            bad_frames[0] = 0   # reset on good frame
            cv2_l = self.cv2
            gray  = cv2_l.cvtColor(frame, cv2_l.COLOR_BGR2GRAY)
            # Equalized version for detection only; ROIs come from original.
            gray_eq = cv2_l.equalizeHist(gray)

            # Detect faces on the equalized frame (Haar works better on it).
            raw   = engine.face_cascade.detectMultiScale(
                gray_eq, scaleFactor=1.05, minNeighbors=4, minSize=(50, 50)
            )
            faces = [tuple(map(int, f)) for f in raw] if (
                raw is not None and len(raw) > 0) else []
            now   = _time.time()

            for (x, y, w, h) in sorted(faces, key=lambda r: r[2]*r[3], reverse=True)[:6]:
                roi = gray[y:y+h, x:x+w]   # crop from ORIGINAL (not equalized)

                # LBPH recognition: recognize() returns (sid, distance, conf).
                # sid is None when the distance exceeds LBPH_MAX_DISTANCE,
                # i.e. no enrolled face is close enough — prevents marking an
                # unenrolled or wrong face.
                best_sid, lbph_dist, best_conf = engine.recognize(
                    roi, recognizer, label_to_sid
                )

                if best_sid is not None:
                    # Require the SAME student to be predicted across 2
                    # consecutive frames before marking. A single bad frame
                    # cannot mark attendance, but 2 is responsive.
                    confirm[best_sid] = confirm.get(best_sid, 0) + 1
                    # Decay other students' streaks so only a stable match wins.
                    for other in list(confirm.keys()):
                        if other != best_sid:
                            confirm[other] = max(0, confirm[other] - 1)

                    col  = (20, 200, 80)
                    name = next(
                        (s["name"] for s in students if s["student_id"] == best_sid),
                        best_sid,
                    )
                    cv2_l.rectangle(frame, (x, y), (x+w, y+h), col, 3)
                    cv2_l.putText(
                        frame,
                        name + "  " + str(int(best_conf)) + "%",
                        (x, max(22, y-10)),
                        cv2_l.FONT_HERSHEY_SIMPLEX, 0.65, col, 2,
                    )
                    if (confirm[best_sid] >= 2
                            and best_sid not in already
                            and now - last_marked.get(best_sid, 0) > 3.0):
                        ok2, _ = self.db.mark_attendance(
                            best_sid, cid, "Present", "Face", confidence=best_conf
                        )
                        if ok2:
                            last_marked[best_sid] = now
                            _mark_row(best_sid, name)
                            result_v.set("Marked:  " + name +
                                         "  (" + str(int(best_conf)) + "%)")
                            result_lbl.config(fg="#22c55e")
                            self._refresh_stats()
                            cv2_l.rectangle(frame, (0, 0), (639, 479), col, 8)
                else:
                    cv2_l.rectangle(frame, (x, y), (x+w, y+h), (120, 120, 120), 2)
                    lbl_txt = ("? " + str(int(best_conf)) + "%"
                               if best_conf > 0 else "Unknown")
                    cv2_l.putText(frame, lbl_txt, (x, max(22, y-10)),
                                  cv2_l.FONT_HERSHEY_SIMPLEX, 0.6, (150, 150, 150), 2)

            cv2_l.putText(
                frame,
                "Faces: " + str(len(faces)) +
                "  Marked: " + str(len(already)) + "/" + str(len(students)),
                (12, 30), cv2_l.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2,
            )
            info_v.set(
                "Marked: " + str(len(already)) + "/" + str(len(students)) +
                "  |  Faces visible: " + str(len(faces))
            )

            try:
                from PIL import Image, ImageTk
                rgb = cv2_l.cvtColor(frame, cv2_l.COLOR_BGR2RGB)
                ph  = ImageTk.PhotoImage(Image.fromarray(rgb).resize((580, 380)))
                cam_lbl.config(image=ph, text="")
                cam_lbl._img = ph
            except Exception:
                pass

            if len(already) >= len(students) and students:
                result_v.set("All " + str(len(students)) + " students marked!")
                result_lbl.config(fg="#fbbf24")
                _do_stop()
                return

            win._job = win.after(30, _frame)

        win.protocol("WM_DELETE_WINDOW", lambda: (_do_stop(), win.destroy()))


    def _open_qr_session(self):
        self._stop_qr()
        self.stop_camera()

        cid  = self._selected_course_id()
        date = self._selected_date()
        if not cid or not date:
            return

        try:
            import qrcode as _qrc
            from PIL import Image as _PIL, ImageTk
        except ImportError:
            messagebox.showerror(
                "Missing Libraries",
                "Run:\n  pip install qrcode[pil] pillow\nThen restart.",
            )
            return

        students = self._get_students(cid)
        if not students:
            messagebox.showinfo("No Students", "No students found for this course.")
            return

        th     = self.theme
        ip     = self._get_local_ip()
        expiry = int(self.db.scalar("SELECT value FROM settings WHERE key='qr_expiry_seconds'") or 30)

        win = tk.Toplevel(self)
        win.title(f"QR Attendance — {self._course_label()}")
        win.geometry("820x680")
        win.configure(bg="#0f172a")
        win.resizable(True, True)
        win.transient(self)

        # Header
        hdr = tk.Frame(win, bg="#8b5cf6", padx=18, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="QR Code Attendance",
                 font=("Segoe UI", 16, "bold"), bg="#8b5cf6", fg="white").pack(side="left")
        tk.Label(hdr,
                 text=f"{self._course_label()}  |  {date}",
                 font=("Segoe UI", 9), bg="#8b5cf6", fg="#ddd6fe").pack(side="left", padx=14)
        tk.Button(hdr, text="Close", bg="#374151", fg="white",
                  relief="flat", padx=12, pady=4,
                  command=lambda: _close()).pack(side="right")

        body = tk.Frame(win, bg="#0f172a")
        body.pack(fill="both", expand=True)

        # LEFT: QR display
        qr_col = tk.Frame(body, bg="#0f172a")
        qr_col.pack(side="left", fill="both", expand=True, padx=16, pady=12)

        tk.Label(qr_col, text=f"Show this QR on screen — students scan with phone",
                 font=("Segoe UI", 10), bg="#0f172a", fg="#94a3b8").pack(anchor="w", pady=(0, 8))

        # QR image box
        qr_box = tk.Frame(qr_col, bg="white", padx=6, pady=6)
        qr_box.pack()
        qr_lbl = tk.Label(qr_box, bg="white",
                          text="Generating QR code…",
                          fg="#1e293b", font=("Segoe UI", 12),
                          width=40, height=18)
        qr_lbl.pack()
        qr_lbl._imgs = []

        # Countdown bar
        cbar_cv = tk.Canvas(qr_col, height=12, bg="#0f172a", highlightthickness=0)
        cbar_cv.pack(fill="x", pady=(10, 2))

        timer_v = tk.StringVar(value="")
        tk.Label(qr_col, textvariable=timer_v,
                 font=("Segoe UI", 16, "bold"), bg="#0f172a", fg="#fbbf24").pack()

        tk.Label(qr_col, text=f"Mobile URL (same WiFi):",
                 font=("Segoe UI", 9), bg="#0f172a", fg="#94a3b8").pack(pady=(10, 0))
        tk.Label(qr_col, text=f"http://{ip}:5000",
                 font=("Segoe UI", 13, "bold"), bg="#0f172a", fg="#38bdf8").pack()

        def _draw_cbar(rem):
            cbar_cv.delete("all")
            w = cbar_cv.winfo_width() or 360
            cbar_cv.create_rectangle(0, 0, w, 12, fill="#1e293b", outline="")
            fw = int(w * rem / expiry)
            if fw > 0:
                col = "#34d399" if rem > expiry * 0.5 else (
                      "#fbbf24" if rem > expiry * 0.25 else "#fb7185")
                cbar_cv.create_rectangle(0, 0, fw, 12, fill=col, outline="")

        # RIGHT: scan list
        sc_col = tk.Frame(body, bg="#1e293b", width=250)
        sc_col.pack(side="right", fill="y", padx=(0, 12), pady=12)
        sc_col.pack_propagate(False)

        tk.Label(sc_col, text="Attendance Status",
                 font=("Segoe UI", 11, "bold"), bg="#1e293b", fg="white").pack(
            pady=(10, 2), padx=10)
        prog_lbl = tk.Label(sc_col, text=f"0 / {len(students)}",
                            font=("Segoe UI", 11, "bold"), bg="#1e293b", fg="#38bdf8")
        prog_lbl.pack()
        tk.Frame(sc_col, bg="#8b5cf6", height=2).pack(fill="x", padx=10, pady=(4, 6))

        att_lb = tk.Listbox(sc_col, bg="#0f172a", fg="#94a3b8",
                            selectbackground="#334155",
                            font=("Segoe UI", 9), relief="flat",
                            height=22, activestyle="none")
        att_sb = ttk.Scrollbar(sc_col, orient="vertical", command=att_lb.yview)
        att_lb.configure(yscrollcommand=att_sb.set)
        att_sb.pack(side="right", fill="y")
        att_lb.pack(fill="both", expand=True, padx=4, pady=4)

        # Pre-populate with already-marked students
        present_set = set()
        for stu in students:
            if self.db.scalar(
                "SELECT status FROM attendance "
                "WHERE student_id=? AND course_id=? AND date=?",
                (stu["student_id"], cid, date),
            ) == "Present":
                present_set.add(stu["student_id"])
        att_lb.delete(0, "end")
        for stu in students:
            att_lb.insert("end", f"{'v' if stu['student_id'] in present_set else 'o'}  {stu['name']}")
            if stu["student_id"] in present_set:
                att_lb.itemconfig(att_lb.size() - 1, fg="#22c55e")
        prog_lbl.config(text=f"{len(present_set)} / {len(students)}")

        def _refresh_list():
            if not win._running or not win.winfo_exists():
                return
            try:
                changed = False
                for i, stu in enumerate(students):
                    sid = stu["student_id"]
                    if sid in present_set:
                        continue
                    if self.db.scalar(
                        "SELECT status FROM attendance "
                        "WHERE student_id=? AND course_id=? AND date=?",
                        (sid, cid, date),
                    ) == "Present":
                        present_set.add(sid)
                        att_lb.delete(i)
                        att_lb.insert(i, f"v  {stu['name']}")
                        att_lb.itemconfig(i, fg="#22c55e")
                        changed = True
                if changed:
                    prog_lbl.config(text=f"{len(present_set)} / {len(students)}")
            except Exception:
                pass
            win.after(2000, _refresh_list)

        # QR generation
        win._running = True

        def _gen_qr():
            if not win._running or not win.winfo_exists():
                return
            try:
                teacher_id = (
                    self.user.get("linked_id") if isinstance(self.user, dict)
                    else self.user["linked_id"]
                ) or "ADMIN"
                token, _ = self.db.create_qr_session(cid, teacher_id, expiry)

                qr_obj = _qrc.QRCode(
                    error_correction=_qrc.constants.ERROR_CORRECT_M,
                    box_size=8,
                    border=4,
                )
                qr_obj.add_data(token)
                qr_obj.make(fit=True)
                img  = qr_obj.make_image(fill_color="black", back_color="white")
                size = 380
                big  = img.resize((size, size), _PIL.LANCZOS)
                ph   = ImageTk.PhotoImage(big)
                qr_lbl._imgs = [ph]
                qr_lbl.config(image=ph, text="", width=0, height=0)
            except Exception as exc:
                qr_lbl.config(image="", text=f"QR Error: {exc}",
                              fg="#fb7185", width=40, height=18)

        def _tick():
            if not win._running or not win.winfo_exists():
                return
            rem = expiry - (int(_time.time()) % expiry)
            timer_v.set(f"Refreshes in  {rem}s")
            _draw_cbar(rem)
            if rem == expiry:
                _gen_qr()
            self.qr_tick_job = self.after(1000, _tick)

        def _close():
            win._running = False
            self._stop_qr()
            if win.winfo_exists():
                win.destroy()

        win.protocol("WM_DELETE_WINDOW", _close)
        _gen_qr()
        _tick()
        _refresh_list()

    # ═════════════════════════════════════════════════════════════════════════
    # 4.  MANUAL ATTENDANCE
    # ═════════════════════════════════════════════════════════════════════════
    def _open_manual(self):
        self._stop_qr()
        self.stop_camera()

        cid  = self._selected_course_id()
        date = self._selected_date()
        if not cid or not date:
            return

        self._clear_work()
        th       = self.theme
        students = self._get_students(cid)

        if not students:
            tk.Label(self.work_area, text="No students found for this course.",
                     bg=th["card"], fg=th["muted"]).pack(pady=20)
            return

        tk.Label(self.work_area,
                 text=f"Manual Attendance — {self._course_label()} — {date}",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0, 4))
        tk.Label(self.work_area,
                 text="Double-click any row to toggle Present / Absent.",
                 bg=th["card"], fg=th["muted"],
                 font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 6))

        frm = tk.Frame(self.work_area, bg=th["card"])
        frm.pack(fill="both", expand=True)

        cols = ("#", "Roll", "Name", "Program", "Status")
        tree = ttk.Treeview(frm, columns=cols, show="headings", height=16)
        for col, w in [("#", 40), ("Roll", 65), ("Name", 185),
                       ("Program", 175), ("Status", 110)]:
            tree.heading(col, text=col)
            tree.column(col, width=w,
                        anchor="center" if col not in ("Name", "Program") else "w")
        ysb = ttk.Scrollbar(frm, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ysb.set)
        tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        tree.tag_configure("present", foreground="#34d399")
        tree.tag_configure("absent",  foreground="#fb7185")

        status_map = {}
        for idx, stu in enumerate(students, 1):
            existing = self.db.scalar(
                "SELECT status FROM attendance "
                "WHERE student_id=? AND course_id=? AND date=?",
                (stu["student_id"], cid, date),
            ) or "Absent"
            status_map[stu["student_id"]] = existing
            icon = "v" if existing == "Present" else "x"
            tag  = "present" if existing == "Present" else "absent"
            tree.insert("", "end",
                        values=(idx, stu["roll_number"] or "", stu["name"],
                                stu["program"], f"{icon} {existing}"),
                        tags=(stu["student_id"], tag))

        def toggle(event):
            sel = tree.selection()
            if not sel:
                return
            iid = sel[0]
            sid = tree.item(iid, "tags")[0]
            cur = status_map[sid]
            nxt = "Absent" if cur == "Present" else "Present"
            status_map[sid] = nxt
            icon = "v" if nxt == "Present" else "x"
            tag  = "present" if nxt == "Present" else "absent"
            tree.set(iid, "Status", f"{icon} {nxt}")
            tree.item(iid, tags=(sid, tag))

        tree.bind("<Double-1>", toggle)

        def all_present():
            for iid in tree.get_children():
                sid = tree.item(iid, "tags")[0]
                status_map[sid] = "Present"
                tree.set(iid, "Status", "v Present")
                tree.item(iid, tags=(sid, "present"))

        def all_absent():
            for iid in tree.get_children():
                sid = tree.item(iid, "tags")[0]
                status_map[sid] = "Absent"
                tree.set(iid, "Status", "x Absent")
                tree.item(iid, tags=(sid, "absent"))

        def save_att():
            saved = 0
            for stu in students:
                sid    = stu["student_id"]
                status = status_map[sid]
                # Pass the UI-selected date so past/future manual attendance
                # saves to the correct date rather than always using today.
                ok, _ = self.db.mark_attendance(
                    sid, cid, status, "Manual", date=date
                )
                if ok:
                    saved += 1
            self._refresh_stats()
            messagebox.showinfo(
                "Saved",
                f"Attendance saved for {saved}/{len(students)} students\n"
                f"on {date}.",
            )

        btn_row = tk.Frame(self.work_area, bg=th["card"])
        btn_row.pack(fill="x", pady=(8, 0))
        tk.Button(btn_row, text="All Present", bg="#10b981", fg="white",
                  relief="flat", padx=14, pady=7,
                  command=all_present).pack(side="left", padx=(0, 6))
        tk.Button(btn_row, text="All Absent", bg=th["danger"], fg="white",
                  relief="flat", padx=14, pady=7,
                  command=all_absent).pack(side="left", padx=6)
        tk.Button(btn_row, text="Save Attendance",
                  bg=th["primary"], fg="white", relief="flat",
                  padx=18, pady=7, font=("Segoe UI", 11, "bold"),
                  command=save_att).pack(side="right")

    # ═════════════════════════════════════════════════════════════════════════
    # 5.  ATTENDANCE REPORT
    # ═════════════════════════════════════════════════════════════════════════
    def _open_report(self):
        self._stop_qr()
        self.stop_camera()

        cid = self._selected_course_id()
        if not cid:
            return

        self._clear_work()
        th = self.theme

        tk.Label(self.work_area,
                 text=f"Attendance Report — {self._course_label()}",
                 bg=th["card"], fg=th["text"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 6))

        ctrl = tk.Frame(self.work_area, bg=th["card"])
        ctrl.pack(fill="x", pady=(0, 6))
        tk.Label(ctrl, text="From:", bg=th["card"], fg=th["muted"]).pack(side="left")
        first_of_month = datetime.date.today().replace(day=1).isoformat()
        today_iso = datetime.date.today().isoformat()
        from_v = tk.StringVar(value=first_of_month)
        to_v   = tk.StringVar(value=today_iso)
        tk.Entry(ctrl, textvariable=from_v, bg=th["panel"], fg=th["text"],
                 insertbackground=th["text"], relief="flat",
                 width=12, ipady=4).pack(side="left", padx=(4, 8))
        tk.Label(ctrl, text="To:", bg=th["card"], fg=th["muted"]).pack(side="left")
        tk.Entry(ctrl, textvariable=to_v, bg=th["panel"], fg=th["text"],
                 insertbackground=th["text"], relief="flat",
                 width=12, ipady=4).pack(side="left", padx=(4, 8))
        tk.Button(ctrl, text="Refresh", bg=th["accent"], fg="white",
                  relief="flat", padx=12, pady=5,
                  command=lambda: _load()).pack(side="left", padx=4)
        tk.Button(ctrl, text="Export CSV", bg=th["primary"], fg="white",
                  relief="flat", padx=12, pady=5,
                  command=lambda: _export()).pack(side="left", padx=4)

        sum_lbl = tk.Label(self.work_area, text="", bg=th["card"], fg=th["muted"],
                           font=("Segoe UI", 9))
        sum_lbl.pack(anchor="w", pady=(0, 4))

        tbl = tk.Frame(self.work_area, bg=th["card"])
        tbl.pack(fill="both", expand=True)
        cols = ("Roll", "Name", "Present", "Absent", "Total", "Percent")
        tree = ttk.Treeview(tbl, columns=cols, show="headings", height=14)
        for col, w in [("Roll", 65), ("Name", 200), ("Present", 80),
                       ("Absent", 80), ("Total", 70), ("Percent", 110)]:
            tree.heading(col, text=col)
            tree.column(col, width=w, anchor="w" if col == "Name" else "center")
        ysb = ttk.Scrollbar(tbl, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ysb.set)
        tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        tree.tag_configure("risk", foreground="#fb7185")
        tree.tag_configure("warn", foreground="#fbbf24")
        tree.tag_configure("good", foreground="#34d399")

        def _load():
            tree.delete(*tree.get_children())
            d_from = from_v.get().strip()
            d_to   = to_v.get().strip()

            students = self._get_students(cid)
            if not students:
                course_row = self.db.query(
                    "SELECT semester, section FROM courses WHERE course_id=?", (cid,))
                if course_row:
                    sem, sec = course_row[0]["semester"], course_row[0]["section"]
                    students = self.db.query(
                        "SELECT s.student_id, s.name, s.roll_number, s.section, s.semester, "
                        "d.name program FROM students s "
                        "LEFT JOIN departments d ON d.id=s.department_id "
                        "WHERE s.semester=? AND s.section=? ORDER BY s.roll_number, s.name",
                        (sem, sec),
                    )

            if not students:
                sum_lbl.config(text="No students found for this course.")
                return

            at_risk = 0
            for stu in students:
                sid = stu["student_id"]
                params = [sid, cid]
                date_clause = ""
                if d_from and len(d_from) == 10:
                    date_clause += " AND date >= ?"
                    params.append(d_from)
                if d_to and len(d_to) == 10:
                    date_clause += " AND date <= ?"
                    params.append(d_to)
                rows = self.db.query(
                    f"SELECT status FROM attendance "
                    f"WHERE student_id=? AND course_id=?{date_clause}",
                    params,
                )
                present = sum(1 for r in rows if r["status"] == "Present")
                absent  = len(rows) - present
                total   = len(rows)
                pct     = round(present / total * 100, 1) if total else 0.0
                if pct < 75:
                    at_risk += 1
                tag = "risk" if pct < 75 else ("warn" if pct < 85 else "good")
                tree.insert("", "end",
                            values=(stu["roll_number"] or "-", stu["name"],
                                    present, absent, total, f"{pct:.1f}%"),
                            tags=(tag,))
            sum_lbl.config(
                text=f"{d_from} → {d_to}  |  Students: {len(students)}  |  At Risk (<75%): {at_risk}"
            )

        def _export():
            path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                initialfile=f"report_{cid}_{from_v.get()}_to_{to_v.get()}.csv",
                filetypes=[("CSV", "*.csv")],
            )
            if not path:
                return
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    w.writerow(["Roll", "Name", "Present", "Absent", "Total", "Percent"])
                    for iid in tree.get_children():
                        w.writerow(tree.item(iid, "values"))
                messagebox.showinfo("Exported", f"Saved to:\n{path}")
            except Exception as exc:
                messagebox.showerror("Export Failed", str(exc))

        _load()


    @staticmethod
    def tree_row(tree, iid):
        return list(tree.item(iid, "values"))
