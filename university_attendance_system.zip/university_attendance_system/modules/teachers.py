"""Teacher and course management modules."""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk


class TeachersFrame(tk.Frame):
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.theme = theme
        self.selected_id = None
        self.vars = {k: tk.StringVar() for k in ["Teacher ID", "Name", "Course Code", "Phone", "Email", "Designation"]}
        self.build()
        self.load()

    def build(self):
        tk.Label(self, text="Teacher Management", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 24, "bold")).pack(anchor="w")
        box = tk.Frame(self, bg=self.theme["bg"])
        box.pack(fill="both", expand=True, pady=12)
        form = tk.Frame(box, bg=self.theme["card"], padx=16, pady=14)
        form.pack(side="left", fill="y", padx=(0, 10))
        for key, var in self.vars.items():
            tk.Label(form, text=key, bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w")
            tk.Entry(form, textvariable=var, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat").pack(fill="x", ipady=6, pady=(2, 8))
        self.dept = ttk.Combobox(form, state="readonly", values=[f"{r['id']} - {r['name']}" for r in self.db.query("SELECT * FROM departments")])
        tk.Label(form, text="Program", bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w")
        self.dept.pack(fill="x", pady=(2, 8))
        tk.Label(form, text="Search Teachers", bg=self.theme["card"], fg=self.theme["muted"]).pack(anchor="w", pady=(10, 2))
        self.search_var = tk.StringVar()
        tk.Entry(form, textvariable=self.search_var, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat").pack(fill="x", ipady=6)
        tk.Button(form, text="Search", bg=self.theme["primary"], fg="white", relief="flat", command=self.search).pack(fill="x", pady=4)
        tk.Button(form, text="Save Teacher", bg=self.theme["accent"], fg="white", relief="flat", command=self.save).pack(fill="x", pady=4)
        tk.Button(form, text="Delete Selected", bg=self.theme["danger"], fg="white", relief="flat", command=self.delete).pack(fill="x", pady=4)
        right = tk.Frame(box, bg=self.theme["card"], padx=12, pady=12)
        right.pack(side="left", fill="both", expand=True)
        cols = ("id", "name", "program", "course_code", "phone", "email", "designation")
        self.tree = ttk.Treeview(right, columns=cols, show="headings")
        widths = {"id": 110, "name": 160, "program": 190, "course_code": 100, "phone": 120, "email": 200, "designation": 150}
        for col in cols:
            self.tree.heading(col, text=col.replace("_", " ").title())
            self.tree.column(col, width=widths.get(col, 120))
        ybar = ttk.Scrollbar(right, orient="vertical", command=self.tree.yview)
        xbar = ttk.Scrollbar(right, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        right.grid_rowconfigure(0, weight=1)
        right.grid_columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.select)

        # Right-click context menu for quick delete / edit
        ctx = tk.Menu(self.tree, tearoff=0, bg="#1e293b", fg="#f1f5f9",
                      activebackground="#334155", activeforeground="#f1f5f9",
                      relief="flat", borderwidth=0)
        ctx.add_command(label="✏️  Edit (load to form)", command=lambda: self.select())
        ctx.add_separator()
        ctx.add_command(label="🗑️  Delete this teacher", command=self.delete,
                        foreground="#fb7185", activeforeground="#fb7185")
        self._ctx = ctx

        def _show_ctx(event):
            item = self.tree.identify_row(event.y)
            if item:
                self.tree.selection_set(item)
                self.select()
                ctx.post(event.x_root, event.y_root)

        self.tree.bind("<Button-3>", _show_ctx)        # Windows / Linux right-click
        self.tree.bind("<Button-2>", _show_ctx)        # macOS two-finger click

    def search(self):
        self.load(self.search_var.get().strip())

    def load(self, search=""):
        self.tree.delete(*self.tree.get_children())
        like = f"%{search}%"
        rows = self.db.query(
            "SELECT t.*, d.name dept_name FROM teachers t LEFT JOIN departments d ON d.id=t.department_id "
            "WHERE t.name LIKE ? OR t.teacher_id LIKE ? OR t.email LIKE ? OR t.course_code LIKE ? ORDER BY t.name",
            (like, like, like, like)
        )
        for r in rows:
            self.tree.insert("", "end", values=(
                r["teacher_id"], r["name"],
                r["program"] or r["dept_name"] or "",
                r["course_code"] or "",
                r["phone"] or "", r["email"] or "", r["designation"] or ""
            ))

    def select(self, _e=None):
        item = self.tree.focus()
        if not item:
            return
        tid = self.tree.item(item)["values"][0]
        row = self.db.query("SELECT * FROM teachers WHERE teacher_id=?", (tid,))[0]
        self.selected_id = tid
        self.vars["Teacher ID"].set(row["teacher_id"])
        self.vars["Name"].set(row["name"])
        self.vars["Course Code"].set(row["course_code"] or "")
        self.vars["Phone"].set(row["phone"] or "")
        self.vars["Email"].set(row["email"] or "")
        self.vars["Designation"].set(row["designation"] or "")
        if row["department_id"]:
            self.dept.set(f"{row['department_id']} - {self.db.scalar('SELECT name FROM departments WHERE id=?', (row['department_id'],))}")

    def save(self):
        tid = self.vars["Teacher ID"].get().strip() or self.selected_id
        if not tid or not self.vars["Name"].get().strip() or not self.dept.get():
            messagebox.showerror("Validation", "Teacher ID, name, and program are required.")
            return
        dept_id = int(self.dept.get().split(" - ")[0])
        prog_name = self.dept.get().split(" - ", 1)[1] if " - " in self.dept.get() else ""
        self.db.execute(
            """INSERT INTO teachers(teacher_id, name, department_id, course_code, program, phone, email, designation)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(teacher_id) DO UPDATE SET name=excluded.name, department_id=excluded.department_id,
            course_code=excluded.course_code, program=excluded.program,
            phone=excluded.phone, email=excluded.email, designation=excluded.designation""",
            (tid, self.vars["Name"].get(), dept_id, self.vars["Course Code"].get(),
             prog_name, self.vars["Phone"].get(), self.vars["Email"].get(), self.vars["Designation"].get()),
        )
        self.load()
        messagebox.showinfo("Saved", "Teacher saved.")

    def delete(self):
        if not self.selected_id:
            messagebox.showinfo("Delete Teacher",
                                "Select a teacher from the list first.")
            return
        name = self.vars["Name"].get() or self.selected_id
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Delete teacher '{name}' and all of their data?\n\n"
            "This removes their QR sessions, timetable entries and login "
            "account, and unlinks their courses. This cannot be undone.",
        ):
            return
        removed = self.db.delete_teacher(self.selected_id)
        self.selected_id = None
        for v in self.vars.values():
            v.set("")
        self.load()
        messagebox.showinfo(
            "Teacher Deleted",
            "Removed teacher '{}'.\n\n"
            "QR sessions: {}\nTimetable rows: {}\n"
            "Courses unlinked: {}\nLogin accounts: {}".format(
                name, removed["qr_sessions"], removed["timetable"],
                removed["courses_unlinked"], removed["user_accounts"],
            ),
        )

class CoursesFrame(tk.Frame):
    def __init__(self, parent, db, user, theme):
        super().__init__(parent, bg=theme["bg"])
        self.db = db
        self.theme = theme
        self.vars = {k: tk.StringVar() for k in ["Course ID", "Subject Name", "Section", "Credit Hours"]}
        self.build()
        self.load()

    def build(self):
        tk.Label(self, text="Course Management", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 24, "bold")).pack(anchor="w")
        form = tk.Frame(self, bg=self.theme["card"], padx=14, pady=12)
        form.pack(fill="x", pady=10)
        for i, (key, var) in enumerate(self.vars.items()):
            tk.Label(form, text=key, bg=self.theme["card"], fg=self.theme["muted"]).grid(row=0, column=i, sticky="w", padx=4)
            tk.Entry(form, textvariable=var, bg=self.theme["panel"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat").grid(row=1, column=i, sticky="ew", padx=4, ipady=6)
            form.grid_columnconfigure(i, weight=1)
        self.dept = ttk.Combobox(form, state="readonly", values=[f"{r['id']} - {r['name']}" for r in self.db.query("SELECT * FROM departments")])
        self.semester = ttk.Combobox(form, state="readonly", values=[2, 4, 6, 8])
        self.teacher = ttk.Combobox(form, state="readonly", values=[f"{r['teacher_id']} - {r['name']}" for r in self.db.query("SELECT * FROM teachers")])
        for i, (label, widget) in enumerate([("Department", self.dept), ("Semester", self.semester), ("Teacher", self.teacher)]):
            tk.Label(form, text=label, bg=self.theme["card"], fg=self.theme["muted"]).grid(row=2, column=i, sticky="w", padx=4, pady=(8, 0))
            widget.grid(row=3, column=i, sticky="ew", padx=4)
        tk.Button(form, text="Save Course", bg=self.theme["primary"], fg="white", relief="flat", command=self.save).grid(row=3, column=3, sticky="ew", padx=4)
        self.tree = ttk.Treeview(self, columns=("id", "subject", "department", "semester", "section", "credits", "teacher"), show="headings")
        for col in ("id", "subject", "department", "semester", "section", "credits", "teacher"):
            self.tree.heading(col, text=col.title())
        self.tree.pack(fill="both", expand=True, pady=10)

    def load(self):
        self.tree.delete(*self.tree.get_children())
        rows = self.db.query(
            """
            SELECT c.*, d.name department, t.name teacher FROM courses c
            LEFT JOIN departments d ON d.id=c.department_id
            LEFT JOIN teachers t ON t.teacher_id=c.teacher_id
            ORDER BY c.course_id
            """
        )
        for r in rows:
            self.tree.insert("", "end", values=(r["course_id"], r["subject_name"], r["department"], r["semester"], r["section"], r["credit_hours"], r["teacher"]))

    def save(self):
        if not all([self.vars["Course ID"].get(), self.vars["Subject Name"].get(), self.vars["Section"].get(), self.vars["Credit Hours"].get(), self.dept.get(), self.semester.get()]):
            messagebox.showerror("Validation", "All course fields except teacher are required.")
            return
        teacher_id = self.teacher.get().split(" - ")[0] if self.teacher.get() else None
        self.db.execute(
            """
            INSERT INTO courses(course_id, subject_name, department_id, semester, section, credit_hours, teacher_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(course_id) DO UPDATE SET subject_name=excluded.subject_name, department_id=excluded.department_id,
            semester=excluded.semester, section=excluded.section, credit_hours=excluded.credit_hours, teacher_id=excluded.teacher_id
            """,
            (self.vars["Course ID"].get().strip(), self.vars["Subject Name"].get().strip(), int(self.dept.get().split(" - ")[0]), int(self.semester.get()), self.vars["Section"].get().upper(), int(self.vars["Credit Hours"].get()), teacher_id),
        )
        self.load()
        messagebox.showinfo("Saved", "Course saved.")
