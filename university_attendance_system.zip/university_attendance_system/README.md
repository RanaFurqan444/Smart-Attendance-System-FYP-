# CS Department Attendance Management System
### Upgraded v2 — Professional BS-Programs Edition

A modular Python 3.10+ Tkinter desktop application for the Computer Science Department.

## What's New in v2

| Area | Change |
|---|---|
| Programs | BS Computer Science, BS Data Science, BS IT, BS AI, BS Cyber Security |
| Students | 1000 realistic students, semesters 2/4/6/8 only |
| Teachers | 50 teachers with Course Code + Program fields |
| Attendance | 6 months (180 days) of realistic history |
| Login | Admin + Teacher only — no Student desktop login |
| Dashboard | Live date/time clock + 75% threshold line on chart |
| Analytics | Heatmap removed · Pie chart replaced · Weekly + Forecasting tabs added · AI Insights data-driven |
| Students | Teacher role = view-only (no Add/Edit/Delete) · Program/Session/Roll Number columns |
| Teachers | Course Code + Program fields, search box, scrollable table |
| Reports | Filter by program/semester/section/session + date range · Defaulter PDF · Analytics PDF with charts |
| Settings | Admin name/password change · Add/Remove teacher login · CSV Import/Export |

## Demo Accounts

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Teacher | `teacher` | `teacher123` |

Admin has access to all modules. Teacher has view-only Students + Attendance + Analytics + Reports.

## Run

```bash
cd university_attendance_system
pip install -r requirements.txt
python main.py
```

On first launch the database auto-generates:
- 5 BS programs (CS/DS/IT/AI/CY)
- 18 courses across programs, semesters 2/4/6/8
- 50 teachers with course assignments
- 1000 students (semesters 2/4/6/8, sessions 2021-2025 → 2024-2028)
- 6 months of attendance history (≈180 school days)

## Mobile QR Server (separate terminal)

```bash
python app.py
```

Opens `http://<laptop-ip>:5000` for students on the same WiFi to scan attendance QR codes.
QR codes rotate every 30 seconds.

How scanning works:
- The QR encodes a short URL like `http://<laptop-ip>:5000/?sid=<session>`. Because only the
  short session id is encoded (not the long signed token), the QR is low-density and scans easily
  with a phone's built-in camera.
- Scanning opens the attendance page with the session already filled in. The student just enters
  their Student ID once (it is remembered) and attendance is marked automatically.
- The teacher screen also shows the scan URL and the raw QR token (for manual entry if needed).
- Laptop and phone must be on the same WiFi/LAN.

## Face Recognition

Face recognition uses OpenCV's trained LBPH recognizer, which ships with `opencv-contrib-python`
(no model download needed). After updating, **every student must Register Face again** — the
stored format changed from feature vectors to normalised face images, so older enrolments will not
be recognised. Enroll in good, even lighting with the face filling the frame for best accuracy.

## Architecture

```
university_attendance_system/
├── main.py              ← app shell, sidebar routing, session
├── app.py               ← Flask mobile QR server
├── modules/
│   ├── database_manager.py  ← schema, seed data, auth, QR signing
│   ├── login.py             ← Admin/Teacher login, remember-me
│   ├── dashboard.py         ← live clock, KPI cards, program chart
│   ├── students.py          ← CRUD (Admin) / view-only (Teacher)
│   ├── teachers.py          ← teacher + course management
│   ├── attendance.py        ← face, QR, hybrid, manual attendance
│   ├── face_system.py       ← face recognition + anti-spoofing
│   ├── analytics.py         ← 11 analytics tabs incl. forecasting
│   ├── reports.py           ← filtered CSV/Excel/PDF + analytics PDF
│   ├── settings.py          ← admin account, teacher mgmt, CSV I/O
│   └── security_center.py   ← spoofing logs, liveness logs
├── database/university.db   ← auto-created SQLite
├── assets/qr_codes/         ← generated QR images
└── requirements.txt
```

## CSV Import Format (Settings → Import Students from CSV)

| Column | Example |
|---|---|
| Student ID | CS-2026-0001 |
| Name | Ali Khan |
| Father Name | Ahmad Khan |
| Program | BS Computer Science |
| Semester | 4 |
| Session | 2023-2027 |
| Roll No | 12 |
| Section | A |
| Phone | 03001234567 |
| Email | ali@student.cs.edu.pk |
