# Module-by-Module Guide

## 1. Project Architecture

Placement: `university_attendance_system/`

Dependencies: Python standard library, Tkinter, SQLite.

Run:

```bash
cd university_attendance_system
python main.py
```

Integration: `main.py` creates one `DatabaseManager`, stores the logged-in user session, and injects both into every module frame.

## 2. Database Schema

Placement: `modules/database_manager.py`, database file at `database/university.db`.

Dependencies: `sqlite3`, `hashlib`, `hmac`, `secrets`, `json`.

Run: The schema is created automatically on first `python main.py`. You can also instantiate `DatabaseManager()` from Python.

Integration: All modules call `db.query`, `db.execute`, `db.scalar`, `db.mark_attendance`, `db.create_qr_session`, and `db.validate_qr_session`.

## 3. Main Application Shell

Placement: `main.py`.

Dependencies: `tkinter`, `ttk`, local modules.

Run: `python main.py`.

Integration: Hosts the sidebar, role-based navigation, logout, and frame routing.

## 4. Login System

Placement: `modules/login.py`.

Dependencies: `tkinter`, `json`, `DatabaseManager`.

Run: Open the app and use `admin/admin123`, `teacher1/teacher123`, or `cs-2026-0001/student123`.

Integration: On success, it passes the SQLite user row to `main.py`, which opens the dashboard shell.

## 5. Dashboard

Placement: `modules/dashboard.py`.

Dependencies: `tkinter`, `ttk`, SQLite queries.

Run: Login and select `Dashboard`.

Integration: Reads totals, live QR classes, department analytics, and defaulters directly from SQLite.

## 6. Student Module

Placement: `modules/students.py`.

Dependencies: `tkinter`, `ttk`, `filedialog`, `DatabaseManager`.

Run: Login as Admin or Teacher, select `Students`, then use `+ Add Student`, `Edit Selected`, or `Delete`.

Integration: Stores students in `students`, links them to `departments`, auto-generates student QR images under `assets/qr_codes/students`, and exposes student IDs used by QR, face, attendance, analytics, and reports.

## 7. Teacher Module

Placement: `modules/teachers.py`, class `TeachersFrame`.

Dependencies: `tkinter`, `ttk`, `DatabaseManager`.

Run: Login as Admin and select `Teachers`.

Integration: Teachers are stored in `teachers` and assigned to courses through the course management section.

## 8. Course Module

Placement: `modules/teachers.py`, class `CoursesFrame`.

Dependencies: `tkinter`, `ttk`, `DatabaseManager`.

Run: Login as Admin and select `Courses`.

Integration: Courses connect departments, semesters, sections, credit hours, and teachers. QR, face, manual attendance, reports, and analytics all use `course_id`.

## 9. QR System

Placement: production attendance flow is in `modules/attendance.py`; legacy helper screen remains in `modules/qr_system.py` but is not exposed in navigation.

Dependencies: `qrcode`, `Pillow`, optional OpenCV/pyzbar for image scan fallback.

Run: Login as Teacher/Admin, select `Attendance`, choose a course/student, and click `Generate QR`, `QR Camera`, or `Start Session`.

Integration: Uses `DatabaseManager.create_qr_session` for HMAC-signed encrypted token envelopes and `validate_qr_session` for expiry, duplicate, semester, and section checks. Valid scans write to `attendance`.

Mobile server: `app.py` runs Flask on `0.0.0.0:5000`. Students open `http://<laptop-ip>:5000`, register their device, scan the laptop QR, and the server calls `mark_mobile_qr_attendance`.

## 10. Face Recognition

Placement: reusable engine in `modules/face_system.py`; attendance UI in `modules/attendance.py`.

Dependencies: `opencv-python`, `numpy`, optional `pyzbar`.

Run: Login, open `Attendance`, select a student, click `Register Face Live`, then select a course and use `Face Attendance` or `Start Session`.

Integration: Stores numeric vectors in `face_data`, uses an embedded Tkinter camera window for live recognition, logs attempts in `face_attempts`, and writes successful matches to `attendance`.

## 11. Attendance System

Placement: `modules/attendance.py`.

Dependencies: `tkinter`, `ttk`, `DatabaseManager`.

Run: Login as Admin/Teacher and select `Attendance`.

Integration: Manual attendance uses the same `attendance` table and duplicate-prevention rule as QR and face attendance.

## 12. Analytics

Placement: `modules/analytics.py`.

Dependencies: `tkinter`, `ttk`; optional Pandas/Matplotlib can be added for richer charts.

Run: Login and select `Analytics`.

Integration: Reads attendance percentages and applies risk rules: below 75% is High Risk, below 85% is Medium Risk.

## 13. Reports

Placement: `modules/reports.py`.

Dependencies: CSV uses standard library, Excel uses `pandas` plus `openpyxl`, PDF uses `reportlab`.

Run: Login and select `Reports`.

Integration: Exports students, teachers, and attendance from the same SQLite tables used by the UI.

## 14. Admin Settings

Placement: `modules/settings.py`.

Dependencies: `tkinter`, `shutil`, SQLite settings table.

Run: Login as Admin and select `Settings`.

Integration: Saves camera index, QR expiry, face threshold, theme, university name, logo path, and backup/restore settings used by Login, Dashboard, and Attendance.

## 15. Security Center

Placement: `modules/security_center.py`.

Dependencies: `tkinter`, `ttk`, optional `pandas` and `matplotlib` for charts.

Run: Login as Admin and select `Security Center`.

Integration: Reads `spoofing_logs`, `liveness_logs`, and `security_events`, exports CSV reports, and controls the passive liveness threshold.

## 14. Sample Data Generator

Placement: `modules/database_manager.py`, methods `ensure_demo_data`, `generate_students`, and `generate_attendance_sample`.

Dependencies: Python standard library and SQLite.

Run: Automatic on first database creation.

Integration: Seeds demo accounts, 8 departments, 8 courses, 8 teachers, 500 students, and attendance history.
