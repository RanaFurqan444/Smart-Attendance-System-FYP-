"""Single-command entry point for the Smart University Attendance Management System."""

from __future__ import annotations

from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from modules.analytics import AnalyticsFrame
from modules.attendance import AttendanceFrame
from modules.dashboard import DashboardFrame
from modules.database_manager import DatabaseManager
from modules.login import LoginFrame
from modules.reports import ReportsFrame
from modules.settings import SettingsFrame
from modules.students import StudentsFrame
from modules.teachers import CoursesFrame, TeachersFrame


THEME = {
    "bg": "#0f172a",
    "panel": "#111827",
    "card": "#1f2937",
    "muted": "#94a3b8",
    "text": "#e5e7eb",
    "primary": "#2563eb",
    "accent": "#14b8a6",
    "danger": "#dc2626",
    "warning": "#f59e0b",
}


class UniversityAttendanceApp:
    """Root Tk application and module router."""

    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("University Attendance System")
        self.root.geometry("1280x780")
        self.root.minsize(1080, 680)
        self.root.configure(bg=THEME["bg"])
        self.db = DatabaseManager()
        self.current_user = None
        self.content = None
        self.sidebar = None
        self.style = ttk.Style()
        self.configure_style()
        self.show_login()

    def configure_style(self) -> None:
        self.style.theme_use("clam")
        self.style.configure("Treeview", background=THEME["card"], foreground=THEME["text"], fieldbackground=THEME["card"], rowheight=28)
        self.style.configure("Treeview.Heading", background=THEME["panel"], foreground=THEME["text"], font=("Segoe UI", 10, "bold"))
        self.style.map("Treeview", background=[("selected", THEME["primary"])])

    def clear(self) -> None:
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_login(self) -> None:
        self.clear()
        LoginFrame(self.root, self.db, self.on_login, THEME).pack(fill="both", expand=True)

    def on_login(self, user) -> None:
        self.current_user = user
        self.show_shell()

    def show_shell(self) -> None:
        self.clear()
        self.sidebar = tk.Frame(self.root, bg=THEME["panel"], width=245)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar, text="University\nAttendance System", bg=THEME["panel"], fg=THEME["text"], font=("Segoe UI", 18, "bold"), justify="left").pack(anchor="w", padx=20, pady=(24, 8))
        tk.Label(self.sidebar, text=f"{self.current_user['role']} | {self.current_user['full_name']}", bg=THEME["panel"], fg=THEME["muted"], wraplength=200, justify="left").pack(anchor="w", padx=20, pady=(0, 22))
        self.content = tk.Frame(self.root, bg=THEME["bg"])
        self.content.pack(side="left", fill="both", expand=True)

        items = [
            ("Dashboard", "dashboard", DashboardFrame),
            ("Students", "students", StudentsFrame),
            ("Teachers", "teachers", TeachersFrame),
            ("Courses", "courses", CoursesFrame),
            ("Attendance", "attendance", AttendanceFrame),
            ("Analytics", "analytics", AnalyticsFrame),
            ("Reports", "reports", ReportsFrame),
            ("Settings", "settings", SettingsFrame),
        ]
        role = self.current_user["role"]
        allowed = {
            "Admin": {key for _, key, _ in items},
            "Teacher": {"dashboard", "attendance", "students", "reports"},
        }.get(role, set())
        for label, key, frame_cls in items:
            if key in allowed:
                tk.Button(self.sidebar, text=label, anchor="w", bg=THEME["panel"], fg=THEME["text"], activebackground=THEME["card"], activeforeground=THEME["text"], relief="flat", padx=20, pady=12, font=("Segoe UI", 11), command=lambda c=frame_cls: self.show_module(c)).pack(fill="x")
        tk.Button(self.sidebar, text="Logout", anchor="w", bg=THEME["danger"], fg="white", relief="flat", padx=20, pady=12, font=("Segoe UI", 11, "bold"), command=self.logout).pack(side="bottom", fill="x", pady=16, padx=18)
        self.show_module(DashboardFrame)

    def logout(self) -> None:
        remember_path = Path(__file__).resolve().parent / "database" / "remember.json"
        if remember_path.exists():
            try:
                remember_path.unlink()
            except OSError:
                pass
        if self.current_user:
            self.db.execute("UPDATE users SET remember_token = NULL WHERE id = ?", (self.current_user["id"],))
        self.current_user = None
        self.show_login()

    def show_module(self, frame_cls) -> None:
        if self.content is None:
            return
        for widget in self.content.winfo_children():
            widget.destroy()
        try:
            # Inject logout callback so dashboard (and any frame) can expose it
            user = dict(self.current_user) if self.current_user else {}
            user["_logout"] = self.logout
            frame_cls(self.content, self.db, user, THEME).pack(fill="both", expand=True, padx=18, pady=18)
        except Exception as exc:
            messagebox.showerror("Module Error", str(exc))

    def run(self) -> None:
        self.root.mainloop()


if __name__ == "__main__":
    UniversityAttendanceApp().run()
