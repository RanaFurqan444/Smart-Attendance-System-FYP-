"""
University Attendance System — Mobile QR Web Server
════════════════════════════════════════════════════
Run:   python app.py
Then:  Students open  http://<IP shown below>:5000  on their phone
       (phone must be on the SAME WiFi as this computer)

Camera works via the phone's native camera app — NO HTTPS needed.
"""
from __future__ import annotations
import os
import platform
import socket
import subprocess
import sys
from flask import Flask, jsonify, request, render_template_string
from modules.database_manager import DatabaseManager

app = Flask(__name__)
db  = DatabaseManager()

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
PORT = 5000

def get_local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def open_windows_firewall(port: int) -> str:
    """Add a Windows Firewall inbound rule for this port. Returns status text."""
    if platform.system() != "Windows":
        return "not-windows"
    try:
        rule_name = f"UniversityAttendance-{port}"
        # Remove old rule first (ignore errors)
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule_name}"],
            capture_output=True, timeout=10,
        )
        result = subprocess.run(
            [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                "protocol=TCP",
                f"localport={port}",
                "dir=in",
                "action=allow",
                "profile=any",
            ],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return "ok"
        return f"failed: {result.stderr.strip()}"
    except Exception as exc:
        return f"error: {exc}"


# ─────────────────────────────────────────────────────────────────────────────
# Mobile page
# ─────────────────────────────────────────────────────────────────────────────
MOBILE_PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Attendance Check-In</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0f172a;--card:#1e293b;--bdr:#334155;
  --txt:#f1f5f9;--mut:#94a3b8;
  --pri:#2563eb;--grn:#10b981;--red:#ef4444;--amb:#f59e0b;
}
body{background:var(--bg);color:var(--txt);
     font-family:system-ui,-apple-system,sans-serif;
     min-height:100vh;padding-bottom:48px}
.page{max-width:480px;margin:0 auto;padding:14px}
/* header */
.hdr{background:linear-gradient(135deg,#1d4ed8,#7c3aed);
     padding:18px 16px;margin-bottom:16px}
.hdr h1{font-size:19px;font-weight:800;color:#fff}
.hdr p{font-size:12px;color:#bfdbfe;margin-top:3px}
/* card */
.card{background:var(--card);border:1px solid var(--bdr);
      border-radius:14px;padding:18px;margin-bottom:14px}
.card-h{font-size:15px;font-weight:700;margin-bottom:10px}
/* form */
label{display:block;font-size:11px;font-weight:600;color:var(--mut);
      margin:10px 0 4px;text-transform:uppercase;letter-spacing:.5px}
input[type=text]{width:100%;padding:12px 14px;border:1.5px solid var(--bdr);
  border-radius:10px;background:#0f172a;color:var(--txt);
  font-size:16px;outline:none;-webkit-appearance:none}
input[type=text]:focus{border-color:var(--pri);
  box-shadow:0 0 0 3px rgba(37,99,235,.2)}
/* toggle */
.tog-row{display:flex;align-items:center;gap:12px;padding:12px 0}
.tog{position:relative;width:44px;height:24px;flex-shrink:0}
.tog input{opacity:0;width:0;height:0}
.tog .sl{position:absolute;inset:0;background:#374151;
  border-radius:24px;cursor:pointer;transition:.2s}
.tog .sl:before{content:'';position:absolute;width:18px;height:18px;
  bottom:3px;left:3px;background:#fff;border-radius:50%;transition:.2s}
.tog input:checked+.sl{background:var(--pri)}
.tog input:checked+.sl:before{transform:translateX(20px)}
/* buttons */
.btn{display:block;width:100%;border:0;border-radius:12px;padding:14px;
     font-weight:700;font-size:15px;cursor:pointer;transition:opacity .15s;
     text-align:center;-webkit-tap-highlight-color:transparent}
.btn:active{opacity:.75}
.btn-p{background:var(--pri);color:#fff;margin-top:10px}
.btn-g{background:var(--grn);color:#fff}
.btn-s{background:#1e3a5f;color:#93c5fd;font-size:13px;padding:11px;margin-top:6px}
/* notification */
.notif{border-radius:12px;padding:18px;margin-top:12px;
       display:none;text-align:center}
.notif.ok {background:#022c22;border:1.5px solid #065f46;color:#34d399}
.notif.err{background:#2d0a0a;border:1.5px solid #991b1b;color:#fca5a5}
.notif.inf{background:#0c1a2e;border:1.5px solid #1d4ed8;color:#93c5fd}
.notif .ni{font-size:40px;margin-bottom:8px}
.notif .nt{font-size:17px;font-weight:700;margin-bottom:4px}
.notif .ns{font-size:13px;opacity:.85;line-height:1.45}
/* attendance rows */
.ar{display:flex;justify-content:space-between;align-items:center;
    padding:10px 0;border-bottom:1px solid var(--bdr)}
.ar:last-child{border-bottom:0}
.badge{padding:4px 11px;border-radius:20px;font-size:11px;font-weight:700}
.P{background:#022c22;color:#34d399}
.A{background:#2d0a0a;color:#fca5a5}
.empty{color:var(--mut);font-size:13px;text-align:center;padding:20px}
/* avatar */
.chip{display:flex;align-items:center;gap:12px;margin-bottom:10px}
.av{width:46px;height:46px;border-radius:50%;background:var(--pri);
    display:flex;align-items:center;justify-content:center;
    font-size:22px;font-weight:800;color:#fff;flex-shrink:0}
/* tip box */
.tip{background:#1a1000;border:1px solid #854d0e;border-radius:10px;
     padding:12px;font-size:12px;color:#fde68a;line-height:1.6;margin-top:10px}
</style>
</head>
<body>
<div class="hdr">
  <h1 id="uni-nm">&#127979; University Attendance</h1>
  <p>QR Check-In &mdash; scan your teacher&apos;s QR to mark attendance</p>
</div>

<!-- ════ SCREEN 1: Register ══════════════════════════════════════════════════ -->
<div class="page" id="scr-reg">
  <div class="card">
    <div class="card-h">&#128100; Register to Check In</div>
    <p style="font-size:13px;color:var(--mut);margin-bottom:4px">
      Enter your details once. We&apos;ll remember you for next time.
    </p>
    <label>Full Name</label>
    <input type="text" id="reg-name" placeholder="e.g. Ali Raza" autocomplete="name">
    <label>Roll Number / Student ID</label>
    <input type="text" id="reg-roll" placeholder="e.g. CS-2026-0001"
           autocomplete="off" oninput="this.value=this.value.toUpperCase()">
    <div class="tog-row">
      <label class="tog">
        <input type="checkbox" id="reg-rem" checked>
        <span class="sl"></span>
      </label>
      <span style="font-size:14px">Remember me on this device</span>
    </div>
    <button class="btn btn-p" onclick="doRegister()">&#10003; Save &amp; Continue</button>
  </div>
</div>

<!-- ════ SCREEN 2: Home ══════════════════════════════════════════════════════ -->
<div class="page" id="scr-home" style="display:none">

  <!-- User chip -->
  <div class="card">
    <div class="chip">
      <div class="av" id="av-init">?</div>
      <div>
        <div id="dn" style="font-weight:700;font-size:15px">—</div>
        <div id="dr" style="font-size:12px;color:var(--mut)">—</div>
      </div>
    </div>
    <button onclick="logout()"
      style="background:none;border:1px solid var(--bdr);color:var(--mut);
             border-radius:8px;padding:6px 14px;cursor:pointer;font-size:12px">
      &#9998; Change Info
    </button>
  </div>

  <!-- QR Scanner -->
  <div class="card">
    <div class="card-h">&#128247; Scan Attendance QR</div>
    <p style="font-size:13px;color:var(--mut);margin-bottom:12px">
      Your teacher shows a QR on screen.
      Tap the button, photograph it, and attendance is marked automatically.
    </p>

    <!--
      PRIMARY SCAN METHOD: file input with camera capture.
      Works on HTTP (no HTTPS needed), opens the native camera app,
      and works on all Android and iOS phones.
    -->
    <button class="btn btn-g" id="scan-btn"
            onclick="document.getElementById('cam-inp').click()">
      &#128247;&nbsp; Open Camera &amp; Scan QR
    </button>
    <input type="file" id="cam-inp" accept="image/*" capture="environment"
           style="display:none" onchange="onPhoto(this)">

    <div id="notif" class="notif"></div>
  </div>

  <!-- Today's attendance -->
  <div class="card">
    <div class="card-h">&#128197; Today&apos;s Attendance</div>
    <div id="today-list"><div class="empty">Loading…</div></div>
    <button onclick="loadToday()"
      style="margin-top:10px;width:100%;background:none;border:1px solid var(--bdr);
             color:var(--mut);border-radius:8px;padding:8px;cursor:pointer;font-size:13px">
      &#8635; Refresh
    </button>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
<script>
/* ── Storage ──────────────────────────────────────────────────────────────── */
const KN='uas_n5', KR='uas_r5';
function gn(){ return localStorage.getItem(KN)||sessionStorage.getItem(KN)||''; }
function gr(){ return localStorage.getItem(KR)||sessionStorage.getItem(KR)||''; }

/* ── Boot ─────────────────────────────────────────────────────────────────── */
window.addEventListener('DOMContentLoaded', () => {
  // Load university name
  fetch('/meta').then(r=>r.json())
    .then(d=>{ if(d.uni) document.getElementById('uni-nm').textContent='\u{1F3EB} '+d.uni; })
    .catch(()=>{});

  // Handle QR link from native camera scan  (?sid=... in URL)
  const p=new URLSearchParams(location.search);
  const urlSid=p.get('sid'), urlTok=p.get('token');
  if(urlSid||urlTok) window._qref={sid:urlSid,token:urlTok};

  const name=gn(), roll=gr();
  if(name&&roll) showHome(name,roll);
  else showReg();
});

/* ── Registration ─────────────────────────────────────────────────────────── */
function showReg(){
  document.getElementById('scr-reg').style.display='';
  document.getElementById('scr-home').style.display='none';
}
function doRegister(){
  const name=document.getElementById('reg-name').value.trim();
  const roll=document.getElementById('reg-roll').value.trim().toUpperCase();
  if(!name){ alert('Enter your full name.'); return; }
  if(!roll){ alert('Enter your Roll Number / Student ID.'); return; }
  if(document.getElementById('reg-rem').checked){
    localStorage.setItem(KN,name); localStorage.setItem(KR,roll);
  } else {
    sessionStorage.setItem(KN,name); sessionStorage.setItem(KR,roll);
    localStorage.removeItem(KN); localStorage.removeItem(KR);
  }
  showHome(name,roll);
}
function logout(){
  [KN,KR].forEach(k=>localStorage.removeItem(k));
  document.getElementById('reg-name').value='';
  document.getElementById('reg-roll').value='';
  showReg();
}
function showHome(name,roll){
  document.getElementById('scr-reg').style.display='none';
  document.getElementById('scr-home').style.display='';
  document.getElementById('av-init').textContent=name[0].toUpperCase();
  document.getElementById('dn').textContent=name;
  document.getElementById('dr').textContent=roll;
  loadToday();
  if(window._qref){
    const r=window._qref; window._qref=null;
    showNotif('inf','&#128247;','QR Detected','Marking attendance…');
    setTimeout(()=>submitRef(r),500);
  }
}

/* ── Today's attendance ───────────────────────────────────────────────────── */
function loadToday(){
  const roll=gr(); if(!roll) return;
  document.getElementById('today-list').innerHTML='<div class="empty">Loading…</div>';
  fetch('/status/'+encodeURIComponent(roll))
    .then(r=>r.json()).then(data=>{
      const el=document.getElementById('today-list');
      if(!data.today_records||!data.today_records.length){
        el.innerHTML='<div class="empty">No attendance recorded today yet.</div>'; return;
      }
      el.innerHTML=data.today_records.map(r=>`
        <div class="ar">
          <div>
            <div style="font-size:14px;font-weight:600">${r.subject_name||r.course_id}</div>
            <div style="font-size:11px;color:var(--mut)">${r.method}&nbsp;&middot;&nbsp;${(r.time||'').slice(0,5)}</div>
          </div>
          <span class="badge ${r.status[0]}">${r.status}</span>
        </div>`).join('');
    }).catch(()=>{
      document.getElementById('today-list').innerHTML=
        '<div class="empty">Could not load — check WiFi connection.</div>';
    });
}

/* ── Photo scan (native camera via file input) ────────────────────────────── */
function onPhoto(input){
  const file=input.files[0]; if(!file) return;
  showNotif('inf','&#128247;','Reading QR…','Analysing photo…');
  const reader=new FileReader();
  reader.onload=function(e){
    const img=new Image();
    img.onload=function(){
      const cvs=document.createElement('canvas');
      // Scale down very large images to speed up jsQR without losing QR detail
      const MAX=1600;
      let w=img.width, h=img.height;
      if(w>MAX||h>MAX){ const sc=MAX/Math.max(w,h); w=Math.round(w*sc); h=Math.round(h*sc); }
      cvs.width=w; cvs.height=h;
      const ctx=cvs.getContext('2d');
      ctx.drawImage(img,0,0,w,h);
      const imgData=ctx.getImageData(0,0,w,h);
      // Try both normal and inverted (handles dark-background QR codes)
      const code=jsQR(imgData.data,imgData.width,imgData.height,
                      {inversionAttempts:'attemptBoth'});
      if(code&&code.data){
        handleScanned(code.data);
      } else {
        showNotif('err','&#10060;','QR Not Found',
          'Could not read the QR code.\n\nTips:\n'+
          '• Make sure the whole QR is in the photo\n'+
          '• Hold your phone steady and close\n'+
          '• Good lighting helps — avoid glare\n'+
          '• Try again — tap the scan button');
      }
    };
    img.onerror=()=>showNotif('err','&#10060;','Photo Error','Could not open the image.');
    img.src=e.target.result;
  };
  reader.readAsDataURL(file);
  input.value=''; // reset so same QR can be re-scanned
}

/* ── Parse QR payload (URL or bare session id) ────────────────────────────── */
function parseQR(raw){
  raw=(raw||'').trim();
  // Check for a URL with ?sid= or ?token=
  try{
    const u=new URL(raw,location.origin);
    const sid=u.searchParams.get('sid');
    const tok=u.searchParams.get('token');
    if(sid||tok) return {sid,token:tok};
  }catch(e){}
  // Bare short id (session id ≤ 20 chars)
  if(raw.length>0&&raw.length<=20) return {sid:raw,token:null};
  // Long string = signed token
  return {sid:null,token:raw};
}

function handleScanned(raw){
  const ref=parseQR(raw);
  showNotif('inf','&#128247;','QR Detected','Submitting attendance…');
  submitRef(ref);
}

/* ── Submit ───────────────────────────────────────────────────────────────── */
async function submitRef(ref){
  const roll=gr();
  if(!roll){ showNotif('err','&#10060;','Not Registered','Register your name and ID first.'); return; }
  const body={student_id:roll};
  if(ref&&ref.sid)   body.session_id=ref.sid;
  if(ref&&ref.token) body.token=ref.token;
  if(!body.session_id&&!body.token){
    showNotif('err','&#10060;','Invalid QR',
      'This QR does not look like an attendance QR.\n'+
      'Make sure you scan the QR your teacher is showing.'); return;
  }
  try{
    const resp=await fetch('/attend',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(body)
    });
    const data=await resp.json();
    if(data.ok){
      showNotif('ok','&#10004;','Attendance Marked!',
        data.message+(data.course?'\n\uD83D\uDCDA '+data.course:''));
      setTimeout(loadToday,800);
    } else {
      showNotif('err','&#10060;','Not Marked',data.message||'Something went wrong.');
    }
  }catch(e){
    showNotif('err','&#10060;','Network Error',
      'Cannot reach the server.\n\n'+
      'Make sure:\n'+
      '• Your phone is on the SAME WiFi as the teacher\u2019s computer\n'+
      '• The server is running (python app.py)\n'+
      '• You are using the correct URL');
  }
}

/* ── Notification ─────────────────────────────────────────────────────────── */
function showNotif(type,icon,title,sub){
  const n=document.getElementById('notif');
  n.className='notif '+type;
  n.innerHTML=`<div class="ni">${icon}</div>`+
              `<div class="nt">${title}</div>`+
              `<div class="ns">${sub.replace(/\n/g,'<br>')}</div>`;
  n.style.display='block';
  n.scrollIntoView({behavior:'smooth',block:'nearest'});
}
</script>
</body>
</html>"""


# ─────────────────────────────────────────────────────────────────────────────
# Setup / diagnostic page  (GET /setup)
# ─────────────────────────────────────────────────────────────────────────────
SETUP_PAGE = """<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Attendance Server — Setup</title>
<style>
body{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:24px;max-width:680px;margin:0 auto}
h1{font-size:22px;color:#38bdf8;margin-bottom:4px}
h2{font-size:16px;color:#94a3b8;margin:20px 0 8px}
.ok{color:#34d399} .warn{color:#fbbf24} .err{color:#fb7185}
pre{background:#1e293b;padding:14px;border-radius:8px;font-size:13px;overflow-x:auto}
.step{background:#1e293b;border-radius:10px;padding:14px;margin:10px 0}
</style></head><body>
<h1>&#127979; Attendance Server — Connection Diagnostic</h1>
<h2>Server is running &#10003;</h2>
<div class="step">
  <b>Server URL</b><br>
  <code class="ok">%(url)s</code><br><br>
  Students on the same WiFi should open this URL in their phone browser.
</div>
<h2>If students can&apos;t connect:</h2>
<div class="step">
  <b>1. Same WiFi?</b><br>
  The teacher&apos;s computer and student&apos;s phone must be on the <b>same WiFi network</b>.
  Using a hotspot or different network won&apos;t work.
</div>
<div class="step">
  <b>2. Windows Firewall (most common issue)</b><br>
  Open <b>Command Prompt as Administrator</b> and run:<br>
  <pre>netsh advfirewall firewall add rule name="UniversityAttendance" protocol=TCP localport=5000 dir=in action=allow</pre>
  This allows phones on the network to reach the server.
</div>
<div class="step">
  <b>3. School network AP isolation</b><br>
  Some schools block device-to-device communication on WiFi (AP isolation).
  Ask your IT department to disable AP isolation for your network, or
  use a mobile hotspot from the teacher&apos;s phone.
</div>
<div class="step">
  <b>4. Check IP address</b><br>
  The IP shown might be wrong if the computer has multiple network adapters (e.g. VPN + WiFi).
  Try the other IPs below and use whichever one works:<br>
  <code>%(all_ips)s</code>
</div>
<p style="margin-top:24px;color:#64748b;font-size:13px">
  Open <a href="/" style="color:#38bdf8">the main page</a> on a phone to check-in.
</p>
</body></html>"""


# ─────────────────────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template_string(MOBILE_PAGE)


@app.route("/setup")
def setup():
    ip = get_local_ip()
    # Collect all non-loopback IPv4 addresses
    all_ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidate = info[4][0]
            if not candidate.startswith("127."):
                all_ips.append(candidate)
    except Exception:
        pass
    if ip not in all_ips:
        all_ips.insert(0, ip)
    all_ips = list(dict.fromkeys(all_ips))   # deduplicate preserving order
    return SETUP_PAGE % {
        "url": f"http://{ip}:{PORT}",
        "all_ips": "  ".join(f"http://{a}:{PORT}" for a in all_ips),
    }


@app.route("/meta")
def meta():
    try:
        uni = db.scalar("SELECT value FROM settings WHERE key='university_name'") \
              or "University Attendance System"
    except Exception:
        uni = "University Attendance System"
    return jsonify({"uni": uni})


@app.route("/attend", methods=["POST"])
def attend():
    data       = request.get_json(silent=True) or {}
    student_id = str(data.get("student_id", "")).strip().upper()
    session_id = str(data.get("session_id", "")).strip()
    token      = str(data.get("token", "")).strip()

    if not student_id:
        return jsonify({"ok": False,
                        "message": "Enter your Student ID / Roll Number first."}), 400
    if not session_id and not token:
        return jsonify({"ok": False,
                        "message": "No QR data received. Please scan again."}), 400

    stu = db.query("SELECT name FROM students WHERE student_id=?", (student_id,))
    if not stu:
        return jsonify({"ok": False,
                        "message": f"ID '{student_id}' not found. "
                                   "Check your Roll Number carefully."}), 404
    student_name = stu[0]["name"]

    try:
        if session_id:
            ok_qr, msg_qr, course_id = db.validate_qr_by_session_id(session_id, student_id)
        else:
            ok_qr, msg_qr, course_id = db.validate_qr_session(token, student_id)
    except Exception as exc:
        ok_qr, msg_qr, course_id = False, str(exc), None

    if ok_qr and course_id:
        ok2, msg2 = db.mark_attendance(
            student_id, course_id, "Present", "QR",
            token=(token or None), session_id=(session_id or None),
        )
        # Fetch course name
        course_name = course_id
        try:
            cr = db.query("SELECT subject_name FROM courses WHERE course_id=?",
                          (course_id,))
            if cr:
                course_name = cr[0]["subject_name"]
        except Exception:
            pass
        if ok2 or "marked" in msg2.lower():
            return jsonify({"ok": True,
                            "message": f"{student_name} — attendance recorded!",
                            "course": course_name})
        if "already" in msg2.lower() or "exists" in msg2.lower():
            return jsonify({"ok": True,
                            "message": f"{student_name}: already marked for {course_name}.",
                            "course": course_name})
        return jsonify({"ok": False, "message": msg2}), 400

    # Map error messages to friendly text
    m = msg_qr.lower()
    if "expired" in m:
        return jsonify({"ok": False,
                        "message": "QR has expired. Ask your teacher to "
                                   "click 'Generate / Refresh QR' again."}), 400
    if "not found" in m or "not active" in m:
        return jsonify({"ok": False,
                        "message": "QR session not found. Scan the QR "
                                   "your teacher is currently showing."}), 400
    return jsonify({"ok": False, "message": msg_qr}), 400


@app.route("/status/<student_id>")
def student_status(student_id: str):
    try:
        rows = db.query(
            "SELECT a.course_id, "
            "COALESCE(c.subject_name, a.course_name, a.course_id) subject_name, "
            "a.status, a.method, a.time "
            "FROM attendance a "
            "LEFT JOIN courses c ON c.course_id = a.course_id "
            "WHERE a.student_id=? AND a.date=date('now','localtime') "
            "ORDER BY a.time DESC",
            (student_id.strip().upper(),),
        )
        return jsonify({"today_records": [dict(r) for r in rows],
                        "count": len(rows)})
    except Exception as exc:
        return jsonify({"error": str(exc), "today_records": [], "count": 0}), 500


@app.route("/ping")
def ping():
    return jsonify({"status": "ok", "port": PORT})


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    ip = get_local_ip()

    # Auto-open Windows Firewall rule so phones can reach the server
    fw_status = open_windows_firewall(PORT)

    print()
    print("=" * 62)
    print("  University Attendance System — Mobile QR Server")
    print("=" * 62)
    print(f"  ► Students URL :  http://{ip}:{PORT}")
    print(f"    Local URL    :  http://127.0.0.1:{PORT}")
    print(f"    Setup / Help :  http://{ip}:{PORT}/setup")
    print()
    if fw_status == "ok":
        print("  ✓ Windows Firewall rule added — phones can connect")
    elif fw_status == "not-windows":
        print("  ℹ  Not on Windows — no firewall change needed")
    else:
        print(f"  ⚠  Firewall: {fw_status}")
        print("     If phones can't connect, run as Administrator:")
        print(f"     netsh advfirewall firewall add rule "
              f'name="UniversityAttendance" protocol=TCP '
              f"localport={PORT} dir=in action=allow")
    print()
    print("  Phone and teacher's computer must be on the SAME WiFi.")
    print("  Students open the URL above, register, then scan the QR.")
    print("=" * 62)
    print()

    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
